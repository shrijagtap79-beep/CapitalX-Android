package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CandlestickChart
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.CandlestickChart
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.ExpenseEntity
import com.example.data.local.GoalEntity
import com.example.data.local.LendingEntity
import com.example.data.local.WalletEntity
import com.example.data.model.ExpenseCategory
import com.example.data.parser.SampleStatementParser
import com.example.ui.components.AddAutoAddScheduleDialog
import com.example.ui.components.AddAutoRuleDialog
import com.example.ui.components.AddBillDialog
import com.example.ui.components.AddChallengeDialog
import com.example.ui.components.AddEditExpenseSheet
import com.example.ui.components.AddGoalDialog
import com.example.ui.components.AddLendingDialog
import com.example.ui.components.AddMoneyToWalletDialog
import com.example.ui.components.AddRecurringDialog
import com.example.ui.components.AddSubscriptionDialog
import com.example.ui.components.AddWalletDialog
import com.example.ui.components.ContributeGoalDialog
import com.example.ui.components.CustomizeWidgetsDialog
import com.example.ui.components.EditBudgetDialog
import com.example.ui.components.SetRealBalanceDialog
import com.example.ui.components.TransferWalletsDialog
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.HubTab
import com.example.ui.screens.LocalAuthScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PinLockScreen
import com.example.ui.screens.PlanningHubScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.VaultSettingsScreen
import com.example.ui.state.MoneyViewModel
import com.example.ui.theme.CapitalxTheme
import com.example.ui.theme.TradingGlassBackdrop
import java.util.Locale

const val ROUTE_OVERVIEW = "overview"
const val ROUTE_EXPENSES = "expenses"
const val ROUTE_HUB = "hub"
const val ROUTE_REPORTS = "reports"
const val ROUTE_VAULT = "vault"

private const val ACTION_ADD_TRANSACTION = "com.example.ACTION_ADD_TRANSACTION"
private const val ACTION_TODAYS_SPEND = "com.example.ACTION_TODAYS_SPEND"
private const val ACTION_WALLETS = "com.example.ACTION_WALLETS"

private data class TopLevelDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val topLevelDestinations = listOf(
    TopLevelDestination(ROUTE_OVERVIEW, R.string.nav_dashboard, Icons.Rounded.CandlestickChart, Icons.Outlined.CandlestickChart),
    TopLevelDestination(ROUTE_EXPENSES, R.string.nav_transactions, Icons.Rounded.ReceiptLong, Icons.Outlined.ReceiptLong),
    TopLevelDestination(ROUTE_HUB, R.string.nav_plan, Icons.Rounded.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    TopLevelDestination(ROUTE_REPORTS, R.string.nav_reports, Icons.Rounded.Assessment, Icons.Outlined.Assessment),
    TopLevelDestination(ROUTE_VAULT, R.string.nav_settings, Icons.Rounded.Settings, Icons.Outlined.Settings)
)

class MainActivity : ComponentActivity() {

    private val pendingShortcutAction = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        captureShortcutAction(intent)
        setContent {
            val viewModel: MoneyViewModel = viewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            CapitalxTheme(themeMode = state.themeMode) {
                CapitalxApp(
                    viewModel = viewModel,
                    pendingShortcutAction = pendingShortcutAction.value,
                    onShortcutConsumed = { pendingShortcutAction.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureShortcutAction(intent)
    }

    private fun captureShortcutAction(intent: Intent?) {
        val action = intent?.action ?: return
        if (action == ACTION_ADD_TRANSACTION || action == ACTION_TODAYS_SPEND || action == ACTION_WALLETS) {
            pendingShortcutAction.value = action
        }
    }
}

private data class BudgetEditRequest(
    val category: ExpenseCategory,
    val limitCents: Long,
    val rolloverEnabled: Boolean
)

@Composable
fun CapitalxApp(
    viewModel: MoneyViewModel = viewModel(),
    pendingShortcutAction: String? = null,
    onShortcutConsumed: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbarMessages.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    val activeAccount = state.activeAccount
    if (activeAccount == null) {
        TradingGlassBackdrop {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
            ) { innerPadding ->
                LocalAuthScreen(
                    knownUsernames = state.knownUsernames,
                    authError = state.authError,
                    onClearError = viewModel::clearAuthError,
                    onLogin = viewModel::login,
                    onSignUp = viewModel::signUp,
                    onForgotPasswordReset = viewModel::forgotPasswordReset,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
        return
    }

    if (state.isPinLocked) {
        TradingGlassBackdrop {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
            ) { innerPadding ->
                PinLockScreen(
                    account = activeAccount,
                    pinError = state.pinError,
                    onVerifyPin = viewModel::verifyPin,
                    onForgotPinWithPassword = viewModel::verifyPasswordAndResetPin,
                    onLogout = viewModel::logout,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val currentRoute = currentDestination?.route ?: ROUTE_OVERVIEW

    var hubInitialTab by remember { mutableStateOf(HubTab.WALLETS) }

    // Dialog & Sheet states
    var showExpenseSheet by remember { mutableStateOf(false) }
    var editingExpense by remember { mutableStateOf<ExpenseEntity?>(null) }
    var prefillExpenseTemplate by remember { mutableStateOf<ExpenseEntity?>(null) }
    var editingBudget by remember { mutableStateOf<BudgetEditRequest?>(null) }
    var showCustomizeWidgets by remember { mutableStateOf(false) }
    var showAddRuleDialog by remember { mutableStateOf(false) }
    var showAddRecurringDialog by remember { mutableStateOf(false) }
    var showAddWalletDialog by remember { mutableStateOf(false) }
    var addMoneyWallet by remember { mutableStateOf<WalletEntity?>(null) }
    var realBalanceWallet by remember { mutableStateOf<WalletEntity?>(null) }
    var showTransferWalletsDialog by remember { mutableStateOf(false) }
    var showAddAutoAddDialog by remember { mutableStateOf(false) }
    var showAddGoalDialog by remember { mutableStateOf(false) }
    var contributingGoal by remember { mutableStateOf<GoalEntity?>(null) }
    var showAddLendingDialog by remember { mutableStateOf(false) }
    var settlingLending by remember { mutableStateOf<LendingEntity?>(null) }
    var showAddSubscriptionDialog by remember { mutableStateOf(false) }
    var showAddChallengeDialog by remember { mutableStateOf(false) }
    var showAddBillDialog by remember { mutableStateOf(false) }

    val navigateToTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    LaunchedEffect(pendingShortcutAction, activeAccount.id, state.isPinLocked) {
        when (pendingShortcutAction) {
            ACTION_ADD_TRANSACTION -> {
                editingExpense = null
                prefillExpenseTemplate = null
                showExpenseSheet = true
                onShortcutConsumed()
            }
            ACTION_TODAYS_SPEND -> {
                navigateToTab(ROUTE_OVERVIEW)
                onShortcutConsumed()
            }
            ACTION_WALLETS -> {
                hubInitialTab = HubTab.WALLETS
                navigateToTab(ROUTE_HUB)
                onShortcutConsumed()
            }
        }
    }

    TradingGlassBackdrop {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                floatingActionButton = {
                    if (currentRoute == ROUTE_OVERVIEW || currentRoute == ROUTE_EXPENSES) {
                        FloatingActionButton(
                            onClick = {
                                editingExpense = null
                                prefillExpenseTemplate = null
                                showExpenseSheet = true
                            },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.testTag("fab_add_expense")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = "Add transaction"
                            )
                        }
                    }
                },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(windowInsets = WindowInsets.navigationBars) {
                        topLevelDestinations.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                            val label = stringResource(dest.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag("nav_${dest.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        topLevelDestinations.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                            val label = stringResource(dest.labelRes)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag("rail_${dest.route}")
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_OVERVIEW,
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 860.dp)
                    ) {
                        composable(ROUTE_OVERVIEW) {
                            OverviewScreen(
                                state = state,
                                onPreviousMonth = { viewModel.shiftMonth(-1) },
                                onNextMonth = { viewModel.shiftMonth(1) },
                                onJumpCurrentMonth = { viewModel.jumpToCurrentMonth() },
                                onToggleHideAmounts = viewModel::toggleHideAmounts,
                                onLockNow = viewModel::lockAppNow,
                                onCustomizeWidgets = { showCustomizeWidgets = true },
                                onAddExpenseClick = {
                                    editingExpense = null
                                    prefillExpenseTemplate = null
                                    showExpenseSheet = true
                                },
                                onOpenImporter = {
                                    hubInitialTab = HubTab.AUTOMATE
                                    navigateToTab(ROUTE_HUB)
                                },
                                onOpenAllExpenses = { navigateToTab(ROUTE_EXPENSES) },
                                onOpenBudgets = {
                                    hubInitialTab = HubTab.BUDGETS_BILLS
                                    navigateToTab(ROUTE_HUB)
                                },
                                onOpenWalletsTab = {
                                    hubInitialTab = HubTab.WALLETS
                                    navigateToTab(ROUTE_HUB)
                                },
                                onOpenGoalsTab = {
                                    hubInitialTab = HubTab.GOALS_MORE
                                    navigateToTab(ROUTE_HUB)
                                },
                                onOpenSettingsBackup = { navigateToTab(ROUTE_VAULT) },
                                onEditExpense = { exp ->
                                    prefillExpenseTemplate = null
                                    editingExpense = exp
                                    showExpenseSheet = true
                                },
                                onDuplicateExpense = viewModel::duplicateTransaction
                            )
                        }

                        composable(ROUTE_EXPENSES) {
                            ExpensesScreen(
                                state = state,
                                onPreviousMonth = { viewModel.shiftMonth(-1) },
                                onNextMonth = { viewModel.shiftMonth(1) },
                                onJumpCurrentMonth = { viewModel.jumpToCurrentMonth() },
                                onToggleHideAmounts = viewModel::toggleHideAmounts,
                                onLockNow = viewModel::lockAppNow,
                                onSearchQueryChange = viewModel::updateSearchQuery,
                                onToggleType = viewModel::toggleTypeFilter,
                                onToggleCategory = viewModel::toggleCategoryFilter,
                                onTogglePaymentMethod = viewModel::togglePaymentMethodFilter,
                                onToggleWalletFilter = viewModel::toggleWalletFilter,
                                onToggleSettleSplit = viewModel::toggleSettleSplit,
                                onEditExpense = { exp ->
                                    prefillExpenseTemplate = null
                                    editingExpense = exp
                                    showExpenseSheet = true
                                },
                                onDuplicateExpense = viewModel::duplicateTransaction,
                                onQuickFill = { tmpl ->
                                    editingExpense = null
                                    prefillExpenseTemplate = tmpl
                                    showExpenseSheet = true
                                },
                                onAddExpenseClick = {
                                    editingExpense = null
                                    prefillExpenseTemplate = null
                                    showExpenseSheet = true
                                },
                                onOpenImporter = {
                                    hubInitialTab = HubTab.AUTOMATE
                                    navigateToTab(ROUTE_HUB)
                                }
                            )
                        }

                        composable(ROUTE_HUB) {
                            PlanningHubScreen(
                                state = state,
                                initialTab = hubInitialTab,
                                onAddWallet = { showAddWalletDialog = true },
                                onAddMoneyToWallet = { w -> addMoneyWallet = w },
                                onSetRealBalance = { w -> realBalanceWallet = w },
                                onOpenTransferWallets = { showTransferWalletsDialog = true },
                                onDeleteTransfer = viewModel::deleteTransfer,
                                onOpenAddAutoAdd = { showAddAutoAddDialog = true },
                                onToggleAutoAdd = viewModel::toggleAutoAddSchedule,
                                onDeleteAutoAdd = viewModel::deleteAutoAddSchedule,
                                onEditCategoryBudget = { cat, limit, rollover ->
                                    editingBudget = BudgetEditRequest(cat, limit, rollover)
                                },
                                onAddBill = { showAddBillDialog = true },
                                onMarkBillPaid = viewModel::markBillPaid,
                                onDeleteBill = viewModel::deleteBill,
                                onAddSubscription = { showAddSubscriptionDialog = true },
                                onAcceptRepeatSuggestion = viewModel::acceptRepeatChargeSuggestion,
                                onAdvanceSubRenewal = viewModel::advanceSubscription,
                                onToggleSubReminder = viewModel::toggleSubscriptionReminder,
                                onDeleteSub = viewModel::deleteSubscription,
                                onImporterTextChange = viewModel::updateImporterText,
                                onLoadTemplate = viewModel::loadEditableFormatTemplate,
                                onParseSample = viewModel::parseImporterText,
                                onToggleDraftSelected = viewModel::toggleDraftSelected,
                                onCommitImport = viewModel::commitImportedDrafts,
                                onClearImporter = viewModel::clearImporter,
                                onOpenAddRule = { showAddRuleDialog = true },
                                onToggleRule = viewModel::toggleAutoRule,
                                onDeleteRule = viewModel::deleteAutoRule,
                                onReRunRules = viewModel::reRunAutoRules,
                                onOpenAddRecurring = { showAddRecurringDialog = true },
                                onToggleRecurring = viewModel::toggleRecurring,
                                onDeleteRecurring = viewModel::deleteRecurring,
                                onSyncRecurringNow = viewModel::syncRecurringNow,
                                onAddGoal = { showAddGoalDialog = true },
                                onContributeGoal = { g -> contributingGoal = g },
                                onDeleteGoal = viewModel::deleteGoal,
                                onAddLending = { showAddLendingDialog = true },
                                onSettleLending = { l -> settlingLending = l },
                                onDeleteLending = viewModel::deleteLending,
                                onAddChallenge = { showAddChallengeDialog = true },
                                onToggleChallengeDay = viewModel::toggleChallengeDay,
                                onDeleteChallenge = viewModel::deleteChallenge
                            )
                        }

                        composable(ROUTE_REPORTS) {
                            ReportsScreen(
                                state = state,
                                onMessage = viewModel::notifyMessage
                            )
                        }

                        composable(ROUTE_VAULT) {
                            VaultSettingsScreen(
                                state = state,
                                onLogout = viewModel::logout,
                                onChangePassword = viewModel::changeAccountPassword,
                                onToggleHideAmounts = viewModel::toggleHideAmounts,
                                onSetThemeMode = viewModel::setThemeMode,
                                onSetPin = viewModel::setPin,
                                onDisablePin = viewModel::disablePin,
                                onLockNow = viewModel::lockAppNow,
                                onSelectBaseCurrency = viewModel::updateBaseCurrency,
                                onRefreshRates = viewModel::refreshExchangeRates,
                                onSetNotificationsEnabled = viewModel::setNotificationsEnabled,
                                onExportBackupPayload = viewModel::exportBackupPayload,
                                onRestoreBackupPayload = viewModel::restoreBackupPayload,
                                onRestoreAutoRecovery = viewModel::restoreAutoRecovery,
                                onMessage = viewModel::notifyMessage
                            )
                        }
                    }
                }
            }
        }
    }
    }

    if (showExpenseSheet) {
        val current = editingExpense
        AddEditExpenseSheet(
            baseCurrencyCode = state.currencyCode,
            usdRates = state.usdRates,
            selectedYearMonth = state.selectedYearMonth,
            wallets = state.wallets,
            customCategories = state.customCategories,
            goals = state.goals,
            prefillTemplate = prefillExpenseTemplate,
            existingExpense = current,
            existingSplits = current?.let { state.splitsByTransactionId[it.id].orEmpty() }.orEmpty(),
            previewAutoCategory = viewModel::previewAutoCategory,
            onParseSms = viewModel::parseSmsForForm,
            onSaveReceiptUri = viewModel::savePickedReceipt,
            onAddCustomCategory = viewModel::addCustomCategory,
            onToggleSettleSplit = viewModel::toggleSettleSplit,
            onDismiss = {
                showExpenseSheet = false
                editingExpense = null
                prefillExpenseTemplate = null
            },
            onSaveNew = { merchant, origCents, origCode, type, cat, customName, dateMillis, method, walletId, note, receiptUri, splits, repeatMonthly, goalId ->
                viewModel.addTransaction(
                    merchant = merchant,
                    originalAmountCents = origCents,
                    originalCurrencyCode = origCode,
                    transactionType = type,
                    selectedCategory = cat,
                    customCategoryName = customName,
                    dateMillis = dateMillis,
                    paymentMethod = method,
                    walletId = walletId,
                    note = note,
                    receiptUri = receiptUri,
                    splits = splits,
                    repeatMonthly = repeatMonthly,
                    goalId = goalId
                )
                showExpenseSheet = false
                editingExpense = null
                prefillExpenseTemplate = null
            },
            onUpdateExisting = { updated ->
                if (current != null) {
                    viewModel.updateTransaction(current, updated)
                }
                showExpenseSheet = false
                editingExpense = null
                prefillExpenseTemplate = null
            },
            onDelete = { exp ->
                viewModel.deleteTransaction(exp)
                showExpenseSheet = false
                editingExpense = null
                prefillExpenseTemplate = null
            }
        )
    }

    editingBudget?.let { req ->
        EditBudgetDialog(
            category = req.category,
            currentLimitCents = req.limitCents,
            rolloverEnabled = req.rolloverEnabled,
            currencySymbol = state.currencySymbol,
            onDismiss = { editingBudget = null },
            onConfirm = { newLimit, rollover ->
                viewModel.updateCategoryBudget(req.category, newLimit, rollover)
                editingBudget = null
            }
        )
    }

    if (showCustomizeWidgets) {
        CustomizeWidgetsDialog(
            visibleWidgets = state.visibleWidgets,
            onToggleWidget = viewModel::toggleDashboardWidget,
            onDismiss = { showCustomizeWidgets = false }
        )
    }

    if (showAddRuleDialog) {
        AddAutoRuleDialog(
            wallets = state.wallets,
            onDismiss = { showAddRuleDialog = false },
            onConfirm = { keyword, category, targetWalletId ->
                viewModel.addAutoRule(keyword, category, targetWalletId)
                showAddRuleDialog = false
            }
        )
    }

    if (showAddRecurringDialog) {
        AddRecurringDialog(
            currencySymbol = state.currencySymbol,
            wallets = state.wallets,
            onDismiss = { showAddRecurringDialog = false },
            onConfirm = { merchant, amountCents, category, dayOfMonth, walletId, note ->
                viewModel.addRecurringExpense(merchant, amountCents, category, dayOfMonth, walletId, note)
                showAddRecurringDialog = false
            }
        )
    }

    if (showAddWalletDialog) {
        AddWalletDialog(
            currencySymbol = state.currencySymbol,
            onDismiss = { showAddWalletDialog = false },
            onConfirm = { name, type, balanceCents ->
                viewModel.addWallet(name, type, balanceCents)
                showAddWalletDialog = false
            }
        )
    }

    addMoneyWallet?.let { wallet ->
        AddMoneyToWalletDialog(
            wallet = wallet,
            currencySymbol = state.currencySymbol,
            onDismiss = { addMoneyWallet = null },
            onConfirm = { amountCents, logAsIncome ->
                viewModel.addMoneyToWallet(wallet.id, amountCents, logAsIncome)
                addMoneyWallet = null
            }
        )
    }

    realBalanceWallet?.let { wallet ->
        SetRealBalanceDialog(
            wallet = wallet,
            currencySymbol = state.currencySymbol,
            onDismiss = { realBalanceWallet = null },
            onConfirm = { actualCents ->
                viewModel.setWalletRealBalance(wallet.id, actualCents)
                realBalanceWallet = null
            }
        )
    }

    if (showTransferWalletsDialog && state.wallets.size >= 2) {
        TransferWalletsDialog(
            wallets = state.wallets,
            currencySymbol = state.currencySymbol,
            onDismiss = { showTransferWalletsDialog = false },
            onConfirm = { fromId, toId, amountCents, dateMillis, note ->
                viewModel.transferBetweenWallets(fromId, toId, amountCents, dateMillis, note)
                showTransferWalletsDialog = false
            }
        )
    }

    if (showAddAutoAddDialog && state.wallets.isNotEmpty()) {
        AddAutoAddScheduleDialog(
            wallets = state.wallets,
            currencySymbol = state.currencySymbol,
            onDismiss = { showAddAutoAddDialog = false },
            onConfirm = { walletId, amountCents, frequency, startDateKey, note ->
                viewModel.addAutoAddSchedule(walletId, amountCents, frequency, startDateKey, note)
                showAddAutoAddDialog = false
            }
        )
    }

    if (showAddGoalDialog) {
        AddGoalDialog(
            currencySymbol = state.currencySymbol,
            onDismiss = { showAddGoalDialog = false },
            onConfirm = { name, targetCents, targetDateMillis ->
                viewModel.addGoal(name, targetCents, targetDateMillis)
                showAddGoalDialog = false
            }
        )
    }

    contributingGoal?.let { goal ->
        ContributeGoalDialog(
            goalName = goal.name,
            currencySymbol = state.currencySymbol,
            wallets = state.wallets,
            onDismiss = { contributingGoal = null },
            onConfirm = { deltaCents, walletId ->
                viewModel.contributeToGoal(goal.id, deltaCents, walletId)
                contributingGoal = null
            }
        )
    }

    if (showAddLendingDialog) {
        AddLendingDialog(
            currencySymbol = state.currencySymbol,
            onDismiss = { showAddLendingDialog = false },
            onConfirm = { person, dir, amountCents, note ->
                viewModel.addLending(person, dir, amountCents, null, note)
                showAddLendingDialog = false
            }
        )
    }

    settlingLending?.let { rec ->
        val remainingCents = (rec.totalCents - rec.paidCents).coerceAtLeast(0L)
        var paymentInput by remember(rec.id) {
            mutableStateOf(String.format(Locale.US, "%.2f", remainingCents / 100.0))
        }
        AlertDialog(
            onDismissRequest = { settlingLending = null },
            title = { Text("Settle · ${rec.personName}") },
            text = {
                Column {
                    OutlinedTextField(
                        value = paymentInput,
                        onValueChange = { paymentInput = it },
                        label = { Text("Payment amount (${state.currencySymbol})") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                val cents = SampleStatementParser.parseAmountToCents(paymentInput)
                Button(
                    onClick = {
                        cents?.let { viewModel.settleLending(rec, it) }
                        settlingLending = null
                    },
                    enabled = cents != null && cents > 0L
                ) { Text("Record Payment") }
            },
            dismissButton = {
                TextButton(onClick = { settlingLending = null }) { Text("Cancel") }
            }
        )
    }

    if (showAddSubscriptionDialog) {
        AddSubscriptionDialog(
            currencySymbol = state.currencySymbol,
            onDismiss = { showAddSubscriptionDialog = false },
            onConfirm = { name, amountCents, cycle, category, nextRenewalMillis ->
                viewModel.addSubscription(name, amountCents, cycle, category, nextRenewalMillis, true)
                showAddSubscriptionDialog = false
            }
        )
    }

    if (showAddChallengeDialog) {
        AddChallengeDialog(
            currencySymbol = state.currencySymbol,
            goals = state.goals,
            onDismiss = { showAddChallengeDialog = false },
            onConfirm = { title, kind, targetDays, dailySaveCents, startDateKey, goalId ->
                viewModel.addChallenge(title, kind, targetDays, dailySaveCents, startDateKey, goalId)
                showAddChallengeDialog = false
            }
        )
    }

    if (showAddBillDialog) {
        AddBillDialog(
            currencySymbol = state.currencySymbol,
            onDismiss = { showAddBillDialog = false },
            onConfirm = { title, billType, amountCents, dueDay, category ->
                viewModel.addBill(title, billType, amountCents, dueDay, category)
                showAddBillDialog = false
            }
        )
    }
}
