package com.example.data.parser

import com.example.data.local.AutoRuleEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.SubscriptionEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

data class ParsedExpenseDraft(
    val id: Int,
    val rawLine: String,
    val merchant: String,
    val amountCents: Long,
    val currencyCode: String = "USD",
    val transactionType: TransactionType = TransactionType.EXPENSE,
    val paymentMethod: PaymentMethod = PaymentMethod.CARD,
    val dateMillis: Long,
    val yearMonth: String,
    val category: ExpenseCategory,
    val matchedKeyword: String? = null,
    val targetWalletId: Long? = null,
    val note: String = "",
    val isSelected: Boolean = true
)

data class ParsedSmsPreview(
    val merchant: String,
    val amountCents: Long,
    val currencyCode: String,
    val transactionType: TransactionType,
    val paymentMethod: PaymentMethod,
    val category: ExpenseCategory,
    val matchedKeyword: String?
)

data class RepeatChargeSuggestion(
    val merchant: String,
    val averageAmountCents: Long,
    val occurrences: Int,
    val category: ExpenseCategory
)

object DateMonthUtils {
    private val ymFormat = SimpleDateFormat("yyyy-MM", Locale.US)
    private val monthTitleFormat = SimpleDateFormat("MMMM yyyy", Locale.US)
    private val shortDateFormat = SimpleDateFormat("MMM d", Locale.US)
    private val fullDateFormat = SimpleDateFormat("MMM d, yyyy", Locale.US)
    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun currentYearMonth(): String = ymFormat.format(Calendar.getInstance().time)

    fun yearMonthFromMillis(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return ymFormat.format(cal.time)
    }

    fun formatMonthTitle(yearMonth: String): String {
        val cal = parseYearMonth(yearMonth)
        return monthTitleFormat.format(cal.time)
    }

    fun shiftYearMonth(yearMonth: String, deltaMonths: Int): String {
        val cal = parseYearMonth(yearMonth)
        cal.add(Calendar.MONTH, deltaMonths)
        return ymFormat.format(cal.time)
    }

    fun daysInMonth(yearMonth: String): Int {
        val cal = parseYearMonth(yearMonth)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun dayOfMonthFromMillis(millis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return cal.get(Calendar.DAY_OF_MONTH)
    }

    fun millisForDayInMonth(yearMonth: String, dayOfMonth: Int): Long {
        val cal = parseYearMonth(yearMonth)
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth.coerceIn(1, maxDay))
        cal.set(Calendar.HOUR_OF_DAY, 12)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun formatShortDate(millis: Long): String = shortDateFormat.format(millis)
    fun formatFullDate(millis: Long): String = fullDateFormat.format(millis)
    fun formatIsoDate(millis: Long): String = isoDateFormat.format(millis)

    fun parseYearMonth(yearMonth: String): Calendar {
        val parts = yearMonth.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        val month = (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1
        return Calendar.getInstance().apply {
            clear()
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month.coerceIn(0, 11))
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 12)
        }
    }

    fun todayKey(): String = isoDateFormat.format(System.currentTimeMillis())

    fun addDays(millis: Long, days: Int): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = millis
            add(Calendar.DAY_OF_YEAR, days)
        }
        return cal.timeInMillis
    }

    fun addMonths(millis: Long, months: Int): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = millis
            add(Calendar.MONTH, months)
        }
        return cal.timeInMillis
    }

    fun parseIsoDateToMillis(dateKey: String): Long? {
        return try {
            val parts = dateKey.trim().split("-")
            if (parts.size != 3) return null
            val y = parts[0].toIntOrNull() ?: return null
            val m = (parts[1].toIntOrNull() ?: return null) - 1
            val d = parts[2].toIntOrNull() ?: return null
            Calendar.getInstance().apply {
                clear()
                set(Calendar.YEAR, y)
                set(Calendar.MONTH, m.coerceIn(0, 11))
                set(Calendar.DAY_OF_MONTH, d.coerceIn(1, 31))
                set(Calendar.HOUR_OF_DAY, 12)
            }.timeInMillis
        } catch (_: Exception) {
            null
        }
    }

    fun millisForIsoDate(dateKey: String): Long =
        parseIsoDateToMillis(dateKey) ?: System.currentTimeMillis()

    fun advanceDateKey(dateKey: String, frequency: String, anchorDay: Int = 1): String {
        val baseMillis = parseIsoDateToMillis(dateKey) ?: System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = baseMillis }
        when (frequency.uppercase()) {
            "DAILY" -> cal.add(Calendar.DAY_OF_YEAR, 1)
            "WEEKLY" -> cal.add(Calendar.DAY_OF_YEAR, 7)
            else -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.add(Calendar.MONTH, 1)
                val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                cal.set(Calendar.DAY_OF_MONTH, anchorDay.coerceIn(1, maxDay))
            }
        }
        return isoDateFormat.format(cal.time)
    }

    fun daysInChallenge(startDateKey: String, targetDays: Int): List<String> {
        val cleanStart = startDateKey.ifBlank { todayKey() }
        val startMillis = parseIsoDateToMillis(cleanStart) ?: System.currentTimeMillis()
        val count = targetDays.coerceIn(1, 365)
        return (0 until count).map { offset ->
            isoDateFormat.format(addDays(startMillis, offset))
        }
    }

    fun dayOfWeekIndex(millis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return (cal.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY).coerceIn(0, 6)
    }
}

object SampleStatementParser {

    private val datePatterns = listOf(
        SimpleDateFormat("yyyy-MM-dd", Locale.US),
        SimpleDateFormat("MM/dd/yyyy", Locale.US),
        SimpleDateFormat("dd/MM/yyyy", Locale.US),
        SimpleDateFormat("yyyy/MM/dd", Locale.US),
        SimpleDateFormat("dd-MM-yyyy", Locale.US),
        SimpleDateFormat("MMM dd, yyyy", Locale.US),
        SimpleDateFormat("MMM d, yyyy", Locale.US),
        SimpleDateFormat("dd MMM yyyy", Locale.US),
        SimpleDateFormat("MMM dd", Locale.US),
        SimpleDateFormat("MMM d", Locale.US)
    ).onEach { it.isLenient = false }

    private val smsAmountRegex = Regex(
        """(?i)(INR|RS\.?|USD|EUR|GBP|JPY|AED|SGD|CAD|AUD|[$€£₹¥])?\s*(-?\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|-?\d+(?:\.\d{1,2})?)\s*(INR|USD|EUR|GBP|JPY|AED|SGD|CAD|AUD)?"""
    )
    private val smsVerbAtRegex = Regex(
        """(?i)(?:spent|charged|debited|credited|received|paid|sent|purchase(?:\s+of)?|transfer(?:red)?(?:\s+of)?)\s+(?:by\s+|of\s+)?(?:INR|RS\.?|USD|EUR|GBP|JPY|AED|SGD|CAD|AUD|[$€£₹¥])?\s*[\d,]+(?:\.\d{1,2})?\s*(?:INR|USD|EUR|GBP|JPY|AED|SGD|CAD|AUD)?\s+(?:at|to|from|for|on|via)\s+([A-Za-z0-9&'._\- ]{2,48}?)(?:\s+(?:on|via|using|with|ref|bal|avl|upi|neft|imps)\b|[.!?\n]|$)"""
    )
    private val isoDateInlineRegex = Regex("""\b(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\b""")
    private val monthNameInlineRegex = Regex("""\b((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,?\s+\d{4})?)\b""", RegexOption.IGNORE_CASE)

    fun classifyMerchant(
        merchant: String,
        rules: List<AutoRuleEntity>,
        fallbackRawCategory: String? = null
    ): Pair<ExpenseCategory, String?> {
        val pair = classifyMerchantWithRule(merchant, rules, fallbackRawCategory)
        return pair.first to pair.second?.keyword
    }

    fun classifyMerchantWithRule(
        merchant: String,
        rules: List<AutoRuleEntity>,
        fallbackRawCategory: String? = null
    ): Pair<ExpenseCategory, AutoRuleEntity?> {
        val lower = merchant.lowercase()
        val matchedRule = rules.firstOrNull { rule ->
            rule.isEnabled && rule.keyword.isNotBlank() && lower.contains(rule.keyword.trim().lowercase())
        }
        if (matchedRule != null) {
            return ExpenseCategory.fromRaw(matchedRule.category) to matchedRule
        }
        if (!fallbackRawCategory.isNullOrBlank()) {
            return ExpenseCategory.fromRaw(fallbackRawCategory) to null
        }
        return ExpenseCategory.OTHER to null
    }

    fun parseSingleBankOrUpiSms(
        smsText: String,
        defaultCurrencyCode: String,
        rules: List<AutoRuleEntity>
    ): ParsedSmsPreview? {
        val text = smsText.trim()
        if (text.isBlank()) return null

        val lower = text.lowercase()
        val txnType = when {
            lower.contains("credited") || lower.contains("received") || lower.contains("deposited") ||
                lower.contains("refund") || lower.contains("cashback") -> TransactionType.INCOME
            else -> TransactionType.EXPENSE
        }
        val paymentMethod = when {
            lower.contains("upi") || lower.contains("vpa") || lower.contains("@ok") ||
                lower.contains("gpay") || lower.contains("phonepe") || lower.contains("paytm") -> PaymentMethod.UPI
            lower.contains("neft") || lower.contains("imps") || lower.contains("a/c") ||
                lower.contains("acct") || lower.contains("bank") -> PaymentMethod.BANK_TRANSFER
            lower.contains("cash") -> PaymentMethod.CASH
            else -> PaymentMethod.CARD
        }

        val amountCents = extractFirstPositiveCents(text) ?: return null
        val currencyCode = detectCurrencyCode(text) ?: defaultCurrencyCode
        val merchantMatch = smsVerbAtRegex.find(text)
        val rawMerchant = merchantMatch?.groupValues?.getOrNull(1)
            ?: text.split(Regex("""\s+(?:at|to|from|for)\s+""", RegexOption.IGNORE_CASE))
                .getOrNull(1)?.take(36)
            ?: if (txnType == TransactionType.INCOME) "Bank Credit" else "UPI / Card Payment"
        val merchant = cleanMerchant(rawMerchant)
        val (cat, matchedRule) = if (txnType == TransactionType.INCOME) {
            ExpenseCategory.SALARY_INCOME to null
        } else {
            classifyMerchantWithRule(merchant, rules)
        }
        return ParsedSmsPreview(
            merchant = merchant,
            amountCents = amountCents,
            currencyCode = currencyCode,
            transactionType = txnType,
            paymentMethod = paymentMethod,
            category = cat,
            matchedKeyword = matchedRule?.keyword
        )
    }

    fun detectRepeatCharges(
        expenses: List<ExpenseEntity>,
        existingSubscriptions: List<SubscriptionEntity>
    ): List<RepeatChargeSuggestion> {
        val existingNames = existingSubscriptions.map { it.name.trim().lowercase() }.toSet()
        val onlyExpenses = expenses.filter {
            TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE && it.amountCents > 0L
        }
        val grouped = onlyExpenses.groupBy { normalizeMerchantKey(it.merchant) }
        val suggestions = mutableListOf<RepeatChargeSuggestion>()

        for ((key, items) in grouped) {
            if (key.length < 3 || items.size < 2) continue
            if (existingNames.any { it.contains(key) || key.contains(it) }) continue
            val avg = items.map { it.amountCents }.average().roundToLong().coerceAtLeast(1L)
            val consistentAmounts = items.all { abs(it.amountCents - avg) <= avg * 0.2 }
            val distinctDates = items.map { DateMonthUtils.formatIsoDate(it.dateMillis) }.distinct().size
            if (consistentAmounts && distinctDates >= 2) {
                val sample = items.first()
                suggestions += RepeatChargeSuggestion(
                    merchant = sample.merchant,
                    averageAmountCents = avg,
                    occurrences = items.size,
                    category = ExpenseCategory.fromRaw(sample.category)
                )
            }
        }
        return suggestions.sortedByDescending { it.occurrences }.take(6)
    }

    private fun normalizeMerchantKey(raw: String): String =
        raw.lowercase().replace(Regex("""[^a-z0-9]"""), "").take(18)

    fun parseSampleText(
        rawText: String,
        defaultYearMonth: String,
        rules: List<AutoRuleEntity>,
        defaultCurrencyCode: String = "USD"
    ): List<ParsedExpenseDraft> {
        val lines = rawText
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        val drafts = mutableListOf<ParsedExpenseDraft>()
        var index = 0
        for (line in lines) {
            if (isCsvHeader(line)) continue
            val parsed = parseLine(index++, line, defaultYearMonth, rules, defaultCurrencyCode)
            if (parsed != null && parsed.amountCents > 0L) {
                drafts += parsed
            }
        }
        return drafts
    }

    private fun isCsvHeader(line: String): Boolean {
        val lower = line.lowercase()
        return (lower.contains("merchant") || lower.contains("description") || lower.contains("payee")) &&
            (lower.contains("amount") || lower.contains("debit") || lower.contains("cost"))
    }

    private fun parseLine(
        id: Int,
        line: String,
        defaultYearMonth: String,
        rules: List<AutoRuleEntity>,
        defaultCurrencyCode: String
    ): ParsedExpenseDraft? {
        val smsMerchantMatch = smsVerbAtRegex.find(line)
        if (smsMerchantMatch != null) {
            val smsPreview = parseSingleBankOrUpiSms(line, defaultCurrencyCode, rules) ?: return null
            val dateMillis = extractInlineDateMillis(line, defaultYearMonth)
            val (_, ruleObj) = classifyMerchantWithRule(smsPreview.merchant, rules)
            return ParsedExpenseDraft(
                id = id,
                rawLine = line,
                merchant = smsPreview.merchant,
                amountCents = smsPreview.amountCents,
                currencyCode = smsPreview.currencyCode,
                transactionType = smsPreview.transactionType,
                paymentMethod = smsPreview.paymentMethod,
                dateMillis = dateMillis,
                yearMonth = DateMonthUtils.yearMonthFromMillis(dateMillis),
                category = smsPreview.category,
                matchedKeyword = smsPreview.matchedKeyword,
                targetWalletId = ruleObj?.targetWalletId,
                note = "Parsed from SMS alert"
            )
        }

        val delimiter = when {
            line.contains(",") -> ','
            line.contains("\t") -> '\t'
            line.contains("|") -> '|'
            line.contains(";") -> ';'
            else -> null
        }
        if (delimiter != null) {
            val cols = splitDelimited(line, delimiter).map { it.trim() }.filter { it.isNotEmpty() }
            if (cols.size >= 2) {
                var parsedDate: Long? = null
                var amountCents: Long? = null
                var detectedCurrency: String? = null
                val textCols = mutableListOf<String>()

                for (col in cols) {
                    if (parsedDate == null) {
                        val dt = tryParseDate(col, defaultYearMonth)
                        if (dt != null) {
                            parsedDate = dt
                            continue
                        }
                    }
                    val amt = parseAmountToCents(col)
                    if (amt != null && amountCents == null) {
                        amountCents = amt
                        detectedCurrency = detectCurrencyCode(col)
                        continue
                    }
                    textCols += col
                }

                if (amountCents != null && textCols.isNotEmpty()) {
                    val merchant = cleanMerchant(textCols[0])
                    val rawCategory = textCols.getOrNull(1)
                    val note = textCols.getOrNull(2).orEmpty()
                    val dateMillis = parsedDate ?: defaultDateInMonth(defaultYearMonth)
                    val (category, matchedRule) = classifyMerchantWithRule(merchant, rules, rawCategory)
                    return ParsedExpenseDraft(
                        id = id,
                        rawLine = line,
                        merchant = merchant,
                        amountCents = amountCents,
                        currencyCode = detectedCurrency ?: defaultCurrencyCode,
                        transactionType = if (category == ExpenseCategory.SALARY_INCOME) TransactionType.INCOME else TransactionType.EXPENSE,
                        dateMillis = dateMillis,
                        yearMonth = DateMonthUtils.yearMonthFromMillis(dateMillis),
                        category = category,
                        matchedKeyword = matchedRule?.keyword,
                        targetWalletId = matchedRule?.targetWalletId,
                        note = note
                    )
                }
            }
        }

        val dateMillis = extractInlineDateMillis(line, defaultYearMonth)
        val strippedDate = isoDateInlineRegex.replace(line, " ").let { monthNameInlineRegex.replace(it, " ") }
        val amountMatch = Regex("""(?:INR|RS\.?|USD|EUR|GBP|JPY|AED|[$€£₹¥])?\s*(?:-?\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|-?\d+(?:\.\d{1,2})?)""")
            .findAll(strippedDate)
            .lastOrNull() ?: return null
        val amountCents = parseAmountToCents(amountMatch.value) ?: return null
        val merchantPart = strippedDate.removeRange(amountMatch.range)
            .replace(Regex("""[:\-–|]+"""), " ")
            .trim()
        if (merchantPart.isBlank()) return null
        val merchant = cleanMerchant(merchantPart)
        val (category, matchedRule) = classifyMerchantWithRule(merchant, rules)
        return ParsedExpenseDraft(
            id = id,
            rawLine = line,
            merchant = merchant,
            amountCents = amountCents,
            currencyCode = detectCurrencyCode(amountMatch.value) ?: defaultCurrencyCode,
            transactionType = if (category == ExpenseCategory.SALARY_INCOME) TransactionType.INCOME else TransactionType.EXPENSE,
            dateMillis = dateMillis,
            yearMonth = DateMonthUtils.yearMonthFromMillis(dateMillis),
            category = category,
            matchedKeyword = matchedRule?.keyword,
            targetWalletId = matchedRule?.targetWalletId
        )
    }

    private fun detectCurrencyCode(text: String): String? {
        val upper = text.uppercase()
        return when {
            upper.contains("INR") || upper.contains("RS.") || text.contains("₹") -> "INR"
            upper.contains("EUR") || text.contains("€") -> "EUR"
            upper.contains("GBP") || text.contains("£") -> "GBP"
            upper.contains("JPY") || text.contains("¥") -> "JPY"
            upper.contains("AED") -> "AED"
            upper.contains("SGD") -> "SGD"
            upper.contains("CAD") -> "CAD"
            upper.contains("AUD") -> "AUD"
            upper.contains("USD") || text.contains("$") -> "USD"
            else -> null
        }
    }

    private fun extractFirstPositiveCents(text: String): Long? {
        for (match in smsAmountRegex.findAll(text)) {
            val raw = match.groupValues[2]
            if (raw.isNotBlank()) {
                val cents = parseAmountToCents(raw)
                if (cents != null && cents > 0L) return cents
            }
        }
        return null
    }

    private fun extractInlineDateMillis(line: String, defaultYearMonth: String): Long {
        val iso = isoDateInlineRegex.find(line)?.value
        if (iso != null) {
            tryParseDate(iso, defaultYearMonth)?.let { return it }
        }
        val monthName = monthNameInlineRegex.find(line)?.value
        if (monthName != null) {
            tryParseDate(monthName, defaultYearMonth)?.let { return it }
        }
        return defaultDateInMonth(defaultYearMonth)
    }

    private fun defaultDateInMonth(yearMonth: String): Long {
        val currentYm = DateMonthUtils.currentYearMonth()
        return if (yearMonth == currentYm) {
            System.currentTimeMillis()
        } else {
            DateMonthUtils.millisForDayInMonth(yearMonth, 15)
        }
    }

    private fun tryParseDate(token: String, defaultYearMonth: String): Long? {
        val cleaned = token.trim().removeSurrounding("\"")
        if (cleaned.length < 4 || cleaned.length > 24) return null
        for (fmt in datePatterns) {
            try {
                val parsed = fmt.parse(cleaned) ?: continue
                val cal = Calendar.getInstance().apply { time = parsed }
                if (cal.get(Calendar.YEAR) < 2000) {
                    val refYear = DateMonthUtils.parseYearMonth(defaultYearMonth).get(Calendar.YEAR)
                    cal.set(Calendar.YEAR, refYear)
                }
                cal.set(Calendar.HOUR_OF_DAY, 12)
                cal.set(Calendar.MINUTE, 0)
                return cal.timeInMillis
            } catch (_: Exception) {
            }
        }
        return null
    }

    fun parseAmountToCents(raw: String): Long? {
        val cleaned = raw
            .replace(Regex("""(?i)[$€£₹¥\s,]|USD|EUR|GBP|INR|JPY|AED|SGD|CAD|AUD|RS\.?"""), "")
            .replace("(", "-")
            .replace(")", "")
            .trim()
        if (cleaned.isEmpty()) return null
        val value = cleaned.toDoubleOrNull() ?: return null
        val absVal = abs(value)
        if (absVal <= 0.0 || absVal > 100_000_000.0) return null
        return (absVal * 100.0).roundToLong()
    }

    private fun cleanMerchant(raw: String): String {
        return raw.trim()
            .removeSurrounding("\"")
            .replace(Regex("""\s+"""), " ")
            .take(48)
            .ifBlank { "General Transaction" }
    }

    private fun splitDelimited(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (ch in line) {
            when {
                ch == '"' -> inQuotes = !inQuotes
                ch == delimiter && !inQuotes -> {
                    result += current.toString()
                    current.clear()
                }
                else -> current.append(ch)
            }
        }
        result += current.toString()
        return result
    }
}
