package com.example.data.export

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.data.local.ExpenseEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.parser.DateMonthUtils
import com.example.ui.state.MoneyFormatters
import java.io.FileOutputStream

object ReportExporter {

    private const val CHANNEL_ID = "capitalx_reminders"

    fun buildCsv(expenses: List<ExpenseEntity>, currencyCode: String): String {
        val sb = StringBuilder()
        sb.appendLine("Date,Type,Merchant,Category,Amount ($currencyCode),Payment Method,Original Currency,Note")
        for (e in expenses) {
            val date = DateMonthUtils.formatIsoDate(e.dateMillis)
            val type = TransactionType.fromRaw(e.transactionType).label
            val cat = e.customCategoryName?.takeIf { it.isNotBlank() } ?: ExpenseCategory.fromRaw(e.category).displayName
            val amount = String.format(java.util.Locale.US, "%.2f", e.amountCents / 100.0)
            val method = PaymentMethod.fromRaw(e.paymentMethod).label
            sb.appendLine(
                listOf(
                    csvEscape(date),
                    csvEscape(type),
                    csvEscape(e.merchant),
                    csvEscape(cat),
                    amount,
                    csvEscape(method),
                    csvEscape(e.originalCurrencyCode),
                    csvEscape(e.note)
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    private fun csvEscape(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return "\"$clean\""
    }

    fun printOrSavePdfReport(
        context: Context,
        reportTitle: String,
        periodLabel: String,
        totalIncomeCents: Long,
        totalExpenseCents: Long,
        currencySymbol: String,
        categoryLines: List<Pair<String, Long>>,
        transactions: List<ExpenseEntity>
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val jobName = "Capitalx_Report_${periodLabel.replace(" ", "_")}"

        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                val pdf = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                val page = pdf.startPage(pageInfo)
                val canvas = page.canvas

                val titlePaint = Paint().apply {
                    color = Color.parseColor("#00875A")
                    textSize = 20f
                    isFakeBoldText = true
                }
                val headingPaint = Paint().apply {
                    color = Color.BLACK
                    textSize = 13f
                    isFakeBoldText = true
                }
                val bodyPaint = Paint().apply {
                    color = Color.DKGRAY
                    textSize = 11f
                }

                var y = 48f
                canvas.drawText("CAPITALX FINANCIAL STATEMENT", 40f, y, titlePaint)
                y += 22f
                canvas.drawText("$reportTitle · $periodLabel", 40f, y, headingPaint)
                y += 24f
                canvas.drawText("Total Income: ${MoneyFormatters.formatMoneyExact(totalIncomeCents, currencySymbol)}", 40f, y, bodyPaint)
                y += 18f
                canvas.drawText("Total Expenses: ${MoneyFormatters.formatMoneyExact(totalExpenseCents, currencySymbol)}", 40f, y, bodyPaint)
                y += 18f
                canvas.drawText("Net Cashflow: ${MoneyFormatters.formatMoneyExact(totalIncomeCents - totalExpenseCents, currencySymbol)}", 40f, y, headingPaint)
                y += 28f

                canvas.drawText("CATEGORY BREAKDOWN", 40f, y, headingPaint)
                y += 18f
                for ((catName, cents) in categoryLines.take(10)) {
                    canvas.drawText("• $catName: ${MoneyFormatters.formatMoneyExact(cents, currencySymbol)}", 48f, y, bodyPaint)
                    y += 16f
                }

                y += 16f
                canvas.drawText("TRANSACTIONS (${transactions.size})", 40f, y, headingPaint)
                y += 18f
                for (t in transactions.take(24)) {
                    if (y > 800f) break
                    val sign = if (TransactionType.fromRaw(t.transactionType) == TransactionType.INCOME) "+" else "-"
                    val line = "${DateMonthUtils.formatShortDate(t.dateMillis)}  ${t.merchant.take(26)}  $sign${MoneyFormatters.formatMoneyExact(t.amountCents, currencySymbol)}"
                    canvas.drawText(line, 48f, y, bodyPaint)
                    y += 15f
                }

                pdf.finishPage(page)
                try {
                    FileOutputStream(destination?.fileDescriptor).use { out ->
                        pdf.writeTo(out)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdf.close()
                }
            }
        }

        printManager.print(jobName, adapter, null)
    }

    fun sendNotificationReminder(
        context: Context,
        title: String,
        body: String,
        notificationId: Int
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Capitalx Alerts & Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        manager.notify(notificationId, notification)
    }
}
