package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.ExpenseCategory
import com.example.data.model.WalletType

@Database(
    entities = [
        LocalAccountEntity::class,
        Expense::class,
        ExpenseEntity::class,
        SplitEntryEntity::class,
        WalletEntity::class,
        WalletTransferEntity::class,
        AutoAddRuleEntity::class,
        CustomCategoryEntity::class,
        CategoryBudgetEntity::class,
        AutoRuleEntity::class,
        RecurringExpenseEntity::class,
        GoalEntity::class,
        LendingEntity::class,
        SubscriptionEntity::class,
        ChallengeEntity::class,
        BillItemEntity::class,
        ExchangeRateCacheEntity::class,
        AppSettingsEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class ClearLedgerDatabase : RoomDatabase() {
    abstract fun localAccountDao(): LocalAccountDao
    abstract fun expenseItemDao(): ExpenseItemDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun splitEntryDao(): SplitEntryDao
    abstract fun walletDao(): WalletDao
    abstract fun walletTransferDao(): WalletTransferDao
    abstract fun autoAddRuleDao(): AutoAddRuleDao
    abstract fun customCategoryDao(): CustomCategoryDao
    abstract fun categoryBudgetDao(): CategoryBudgetDao
    abstract fun autoRuleDao(): AutoRuleDao
    abstract fun recurringExpenseDao(): RecurringExpenseDao
    abstract fun goalDao(): GoalDao
    abstract fun lendingDao(): LendingDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun challengeDao(): ChallengeDao
    abstract fun billItemDao(): BillItemDao
    abstract fun exchangeRateCacheDao(): ExchangeRateCacheDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: ClearLedgerDatabase? = null

        fun getInstance(context: Context): ClearLedgerDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): ClearLedgerDatabase {
            return Room.databaseBuilder(
                appContext,
                ClearLedgerDatabase::class.java,
                "clearledger.db"
            ).fallbackToDestructiveMigration(true).build()
        }

        suspend fun seedAccountDefaults(database: ClearLedgerDatabase, accountId: Long) {
            val existingBudgets = database.categoryBudgetDao().getBudgetsSnapshot(accountId)
            if (existingBudgets.isEmpty()) {
                val defaultBudgets = ExpenseCategory.expenseEntries.map { category ->
                    CategoryBudgetEntity(
                        id = "${accountId}_${category.name}",
                        accountId = accountId,
                        category = category.name,
                        limitCents = category.defaultMonthlyLimitCents,
                        rolloverEnabled = false
                    )
                }
                database.categoryBudgetDao().insertBudgetsIfAbsent(defaultBudgets)
            }

            val existingWallets = database.walletDao().getWalletsSnapshot(accountId)
            if (existingWallets.isEmpty()) {
                database.walletDao().insertWallets(
                    listOf(
                        WalletEntity(accountId = accountId, name = "Primary Bank", walletType = WalletType.BANK.name, balanceCents = 0L),
                        WalletEntity(accountId = accountId, name = "UPI Wallet", walletType = WalletType.UPI.name, balanceCents = 0L),
                        WalletEntity(accountId = accountId, name = "Cash", walletType = WalletType.CASH.name, balanceCents = 0L)
                    )
                )
            }

            val existingRules = database.autoRuleDao().getEnabledRulesSnapshot(accountId)
            if (existingRules.isEmpty()) {
                val builtInRules = listOf(
                    AutoRuleEntity(accountId = accountId, keyword = "starbucks", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "coffee", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "tea", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "chai", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "swiggy", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "zomato", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "vada pav", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "biryani", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "samosa", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "lunch", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "dinner", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "breakfast", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "doordash", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "restaurant", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "whole foods", category = ExpenseCategory.GROCERIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "trader joe", category = ExpenseCategory.GROCERIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "blinkit", category = ExpenseCategory.GROCERIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "bigbasket", category = ExpenseCategory.GROCERIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "walmart", category = ExpenseCategory.GROCERIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "uber", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "ola", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "rapido", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "rickshaw", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "lyft", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "metro", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "petrol", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "diesel", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "shell", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "rent", category = ExpenseCategory.HOUSING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "mortgage", category = ExpenseCategory.HOUSING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "electric", category = ExpenseCategory.UTILITIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "internet", category = ExpenseCategory.UTILITIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "wifi", category = ExpenseCategory.UTILITIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "recharge", category = ExpenseCategory.UTILITIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "airtel", category = ExpenseCategory.UTILITIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "jio", category = ExpenseCategory.UTILITIES.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "amazon", category = ExpenseCategory.SHOPPING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "flipkart", category = ExpenseCategory.SHOPPING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "target", category = ExpenseCategory.SHOPPING.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "netflix", category = ExpenseCategory.ENTERTAINMENT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "spotify", category = ExpenseCategory.ENTERTAINMENT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "hotstar", category = ExpenseCategory.ENTERTAINMENT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "youtube premium", category = ExpenseCategory.ENTERTAINMENT.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "pharmacy", category = ExpenseCategory.HEALTH.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "hospital", category = ExpenseCategory.HEALTH.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "gym", category = ExpenseCategory.HEALTH.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "salary", category = ExpenseCategory.SALARY_INCOME.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "payroll", category = ExpenseCategory.SALARY_INCOME.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "pocket money", category = ExpenseCategory.SALARY_INCOME.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "freelance", category = ExpenseCategory.SALARY_INCOME.name, isBuiltIn = true),
                    AutoRuleEntity(accountId = accountId, keyword = "refund", category = ExpenseCategory.SALARY_INCOME.name, isBuiltIn = true)
                )
                database.autoRuleDao().insertRules(builtInRules)
            }
        }
    }
}
