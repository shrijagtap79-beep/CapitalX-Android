package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.AppSettingsEntity
import com.example.data.local.AutoAddRuleEntity
import com.example.data.local.AutoRuleEntity
import com.example.data.local.BillItemEntity
import com.example.data.local.CategoryBudgetEntity
import com.example.data.local.ChallengeEntity
import com.example.data.local.ClearLedgerDatabase
import com.example.data.local.CustomCategoryEntity
import com.example.data.local.ExchangeRateCacheEntity
import com.example.data.local.Expense
import com.example.data.local.ExpenseEntity
import com.example.data.local.GoalEntity
import com.example.data.local.LendingEntity
import com.example.data.local.LocalAccountEntity
import com.example.data.local.RecurringExpenseEntity
import com.example.data.local.SplitEntryEntity
import com.example.data.local.SubscriptionEntity
import com.example.data.local.WalletEntity
import com.example.data.local.WalletTransferEntity
import com.example.data.model.BillType
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseSource
import com.example.data.model.LendingDirection
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.model.WalletType
import com.example.data.model.currencySymbolFor
import com.example.data.network.ExchangeRateService
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.ParsedExpenseDraft
import com.example.data.parser.SampleStatementParser
import com.example.data.security.CryptoAndAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class SplitInput(
    val friendName: String,
    val shareCents: Long
)

class MoneyRepository(
    private val context: Context,
    private val db: ClearLedgerDatabase
) {
    private val accountDao = db.localAccountDao()
    private val expenseItemDao = db.expenseItemDao()
    private val expenseDao = db.expenseDao()
    private val splitDao = db.splitEntryDao()
    private val walletDao = db.walletDao()
    private val transferDao = db.walletTransferDao()
    private val autoAddRuleDao = db.autoAddRuleDao()
    private val customCatDao = db.customCategoryDao()
    private val budgetDao = db.categoryBudgetDao()
    private val ruleDao = db.autoRuleDao()
    private val recurringDao = db.recurringExpenseDao()
    private val goalDao = db.goalDao()
    private val lendingDao = db.lendingDao()
    private val subscriptionDao = db.subscriptionDao()
    private val challengeDao = db.challengeDao()
    private val billDao = db.billItemDao()
    private val rateDao = db.exchangeRateCacheDao()
    private val settingsDao = db.appSettingsDao()

    fun observeSettings(): Flow<AppSettingsEntity> =
        settingsDao.observeSettings().map { it ?: AppSettingsEntity() }

    fun observeAccount(accountId: Long): Flow<LocalAccountEntity?> =
        accountDao.observeAccount(accountId)

    fun observeAllAccounts(): Flow<List<LocalAccountEntity>> =
        accountDao.observeAllAccounts()

    fun observeExpensesForMonth(accountId: Long, yearMonth: String): Flow<List<ExpenseEntity>> =
        expenseDao.observeExpensesForMonth(accountId, yearMonth)

    fun observeAllExpenses(accountId: Long): Flow<List<ExpenseEntity>> =
        expenseDao.observeAllExpenses(accountId)

    fun observeSplits(accountId: Long): Flow<List<SplitEntryEntity>> =
        splitDao.observeAllSplits(accountId)

    fun observeWallets(accountId: Long): Flow<List<WalletEntity>> =
        walletDao.observeWallets(accountId)

    fun observeTransfers(accountId: Long): Flow<List<WalletTransferEntity>> =
        transferDao.observeTransfers(accountId)

    fun observeAutoAddRules(accountId: Long): Flow<List<AutoAddRuleEntity>> =
        autoAddRuleDao.observeAutoAddRules(accountId)

    fun observeCustomCategories(accountId: Long): Flow<List<CustomCategoryEntity>> =
        customCatDao.observeCustomCategories(accountId)

    fun observeBudgets(accountId: Long): Flow<List<CategoryBudgetEntity>> =
        budgetDao.observeAllBudgets(accountId)

    fun observeRules(accountId: Long): Flow<List<AutoRuleEntity>> =
        ruleDao.observeAllRules(accountId)

    fun observeRecurring(accountId: Long): Flow<List<RecurringExpenseEntity>> =
        recurringDao.observeAllRecurring(accountId)

    fun observeGoals(accountId: Long): Flow<List<GoalEntity>> =
        goalDao.observeGoals(accountId)

    fun observeLending(accountId: Long): Flow<List<LendingEntity>> =
        lendingDao.observeLending(accountId)

    fun observeSubscriptions(accountId: Long): Flow<List<SubscriptionEntity>> =
        subscriptionDao.observeSubscriptions(accountId)

    fun observeChallenges(accountId: Long): Flow<List<ChallengeEntity>> =
        challengeDao.observeChallenges(accountId)

    fun observeBills(accountId: Long): Flow<List<BillItemEntity>> =
        billDao.observeBills(accountId)

    fun observeExchangeRates(): Flow<ExchangeRateCacheEntity> =
        rateDao.observeCache().map {
            it ?: ExchangeRateCacheEntity(baseCode = "USD", ratesJson = ExchangeRateService.defaultRatesJson(), updatedAtMillis = 0L)
        }

    fun observeExpenseItems(): Flow<List<Expense>> =
        expenseItemDao.observeAllExpenses()

    fun observeExpenseItemsByCategory(category: String): Flow<List<Expense>> =
        expenseItemDao.observeExpensesByCategory(category)

    suspend fun addExpenseItem(amount: Double, date: Long, category: String, description: String): Long =
        expenseItemDao.insertExpense(
            Expense(amount = amount, date = date, category = category, description = description)
        )

    suspend fun updateExpenseItem(expense: Expense) =
        expenseItemDao.updateExpense(expense)

    suspend fun deleteExpenseItem(expense: Expense) =
        expenseItemDao.deleteExpense(expense)

    // ---------- ACCOUNTS & SECURITY ----------

    suspend fun signUpAccount(displayName: String, username: String, password: String): Result<LocalAccountEntity> {
        val cleanUser = username.trim()
        val cleanName = displayName.trim()
        if (cleanName.isBlank()) return Result.failure(IllegalArgumentException("Display name is required."))
        if (cleanUser.length < 3) return Result.failure(IllegalArgumentException("Username must be at least 3 characters."))
        if (password.length < 6) return Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        if (accountDao.getByUsername(cleanUser) != null) {
            return Result.failure(IllegalArgumentException("Username \"$cleanUser\" is already registered."))
        }
        val salt = CryptoAndAuth.generateSaltBase64()
        val hash = CryptoAndAuth.hashSecret(password, salt)
        val newId = accountDao.insertAccount(
            LocalAccountEntity(
                displayName = cleanName,
                username = cleanUser,
                passwordHash = hash,
                passwordSalt = salt
            )
        )
        ClearLedgerDatabase.seedAccountDefaults(db, newId)
        val currentSettings = settingsDao.getSettingsSnapshot() ?: AppSettingsEntity()
        settingsDao.upsertSettings(currentSettings.copy(activeAccountId = newId))
        return Result.success(accountDao.getById(newId)!!)
    }

    suspend fun loginAccount(username: String, password: String): Result<LocalAccountEntity> {
        val account = accountDao.getByUsername(username.trim())
            ?: return Result.failure(IllegalArgumentException("No local account found for that username."))
        if (!CryptoAndAuth.verifySecret(password, account.passwordSalt, account.passwordHash)) {
            return Result.failure(IllegalArgumentException("Incorrect password."))
        }
        ClearLedgerDatabase.seedAccountDefaults(db, account.id)
        val currentSettings = settingsDao.getSettingsSnapshot() ?: AppSettingsEntity()
        settingsDao.upsertSettings(currentSettings.copy(activeAccountId = account.id))
        return Result.success(account)
    }

    suspend fun logoutAccount() {
        val currentSettings = settingsDao.getSettingsSnapshot() ?: AppSettingsEntity()
        settingsDao.upsertSettings(currentSettings.copy(activeAccountId = 0L))
    }

    suspend fun forgotPasswordResetAndWipe(username: String, newPassword: String): Result<LocalAccountEntity> {
        if (newPassword.length < 6) return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        val account = accountDao.getByUsername(username.trim())
            ?: return Result.failure(IllegalArgumentException("Account \"$username\" not found."))

        // Wipe all data belonging to this account as clearly warned
        wipeAccountData(account.id)
        val newSalt = CryptoAndAuth.generateSaltBase64()
        val newHash = CryptoAndAuth.hashSecret(newPassword, newSalt)
        val updated = account.copy(
            passwordHash = newHash,
            passwordSalt = newSalt,
            pinHash = null,
            pinSalt = null,
            pinFailedAttempts = 0,
            pinLockoutUntilMillis = 0L
        )
        accountDao.updateAccount(updated)
        ClearLedgerDatabase.seedAccountDefaults(db, account.id)
        val currentSettings = settingsDao.getSettingsSnapshot() ?: AppSettingsEntity()
        settingsDao.upsertSettings(currentSettings.copy(activeAccountId = account.id))
        return Result.success(updated)
    }

    private suspend fun wipeAccountData(accountId: Long) {
        expenseDao.deleteAllForAccount(accountId)
        splitDao.deleteAllForAccount(accountId)
        walletDao.deleteAllForAccount(accountId)
        transferDao.deleteAllForAccount(accountId)
        autoAddRuleDao.deleteAllForAccount(accountId)
        customCatDao.deleteAllForAccount(accountId)
        budgetDao.deleteAllForAccount(accountId)
        ruleDao.deleteAllForAccount(accountId)
        recurringDao.deleteAllForAccount(accountId)
        goalDao.deleteAllForAccount(accountId)
        lendingDao.deleteAllForAccount(accountId)
        subscriptionDao.deleteAllForAccount(accountId)
        challengeDao.deleteAllForAccount(accountId)
        billDao.deleteAllForAccount(accountId)
    }

    suspend fun changeAccountPassword(
        accountId: Long,
        currentPassword: String,
        newPassword: String
    ): Result<Unit> {
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        }
        val account = accountDao.getById(accountId)
            ?: return Result.failure(IllegalStateException("No active account loaded."))
        if (!CryptoAndAuth.verifySecret(currentPassword, account.passwordSalt, account.passwordHash)) {
            return Result.failure(IllegalArgumentException("Current password is incorrect."))
        }
        val salt = CryptoAndAuth.generateSaltBase64()
        val hash = CryptoAndAuth.hashSecret(newPassword, salt)
        accountDao.updateAccount(account.copy(passwordHash = hash, passwordSalt = salt))
        return Result.success(Unit)
    }

    suspend fun verifyPasswordAndResetPin(accountId: Long, password: String): Result<Unit> {
        val account = accountDao.getById(accountId)
            ?: return Result.failure(IllegalStateException("No active account loaded."))
        if (password.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter your account password."))
        }
        if (!CryptoAndAuth.verifySecret(password, account.passwordSalt, account.passwordHash)) {
            return Result.failure(IllegalArgumentException("Incorrect account password."))
        }
        accountDao.updateAccount(
            account.copy(pinHash = null, pinSalt = null, pinFailedAttempts = 0, pinLockoutUntilMillis = 0L)
        )
        return Result.success(Unit)
    }

    suspend fun setAppPin(accountId: Long, pin: String) {
        val account = accountDao.getById(accountId) ?: return
        val salt = CryptoAndAuth.generateSaltBase64()
        val hash = CryptoAndAuth.hashSecret(pin, salt)
        accountDao.updateAccount(
            account.copy(pinHash = hash, pinSalt = salt, pinFailedAttempts = 0, pinLockoutUntilMillis = 0L)
        )
    }

    suspend fun disableAppPin(accountId: Long) {
        val account = accountDao.getById(accountId) ?: return
        accountDao.updateAccount(
            account.copy(pinHash = null, pinSalt = null, pinFailedAttempts = 0, pinLockoutUntilMillis = 0L)
        )
    }

    suspend fun verifyAppPin(accountId: Long, pin: String): Result<Unit> {
        val account = accountDao.getById(accountId) ?: return Result.failure(IllegalStateException("Account missing"))
        val now = System.currentTimeMillis()
        if (account.pinLockoutUntilMillis > now) {
            val sec = ((account.pinLockoutUntilMillis - now) / 1000L).coerceAtLeast(1L)
            return Result.failure(IllegalStateException("Locked for ${sec}s due to repeated wrong attempts."))
        }
        val hash = account.pinHash ?: return Result.success(Unit)
        val salt = account.pinSalt ?: return Result.success(Unit)
        if (CryptoAndAuth.verifySecret(pin, salt, hash)) {
            accountDao.updateAccount(account.copy(pinFailedAttempts = 0, pinLockoutUntilMillis = 0L))
            return Result.success(Unit)
        } else {
            val nextFails = account.pinFailedAttempts + 1
            val lockUntil = if (nextFails >= 5) now + 30_000L else 0L
            accountDao.updateAccount(account.copy(pinFailedAttempts = nextFails, pinLockoutUntilMillis = lockUntil))
            val msg = if (lockUntil > 0L) "5 wrong attempts. Locked for 30 seconds."
            else "Incorrect PIN (${5 - nextFails} attempts remaining)."
            return Result.failure(IllegalArgumentException(msg))
        }
    }

    // ---------- RECEIPT PHOTO HELPER ----------

    suspend fun copyReceiptToInternalStorage(pickedUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, "receipts").apply { mkdirs() }
            val dest = File(dir, "receipt_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(pickedUri)?.use { input ->
                FileOutputStream(dest).use { output -> input.copyTo(output) }
            }
            Uri.fromFile(dest).toString()
        } catch (_: Exception) {
            null
        }
    }

    // ---------- TRANSACTIONS & SPLITS ----------

    suspend fun addTransaction(
        accountId: Long,
        merchant: String,
        baseAmountCents: Long,
        originalAmountCents: Long,
        originalCurrencyCode: String,
        transactionType: TransactionType,
        selectedCategory: ExpenseCategory?,
        customCategoryName: String?,
        dateMillis: Long,
        paymentMethod: PaymentMethod,
        walletId: Long,
        note: String,
        receiptUri: String?,
        splits: List<SplitInput>,
        repeatMonthly: Boolean,
        goalId: Long? = null
    ): Result<ExpenseCategory> {
        val effectiveGoalId = if (transactionType == TransactionType.EXPENSE && goalId != null && goalId > 0L) goalId else null
        if (effectiveGoalId != null) {
            if (splits.isNotEmpty()) {
                return Result.failure(IllegalArgumentException("Splitting cannot be combined with paying from a savings goal."))
            }
            if (repeatMonthly) {
                return Result.failure(IllegalArgumentException("Recurring entries cannot pay from a savings goal."))
            }
            val goal = goalDao.getById(effectiveGoalId)
            if (goal == null || goal.savedCents < baseAmountCents) {
                return Result.failure(IllegalArgumentException("Not enough saved in that goal."))
            }
        }

        val rules = ruleDao.getEnabledRulesSnapshot(accountId)
        val (autoCategory, matchedRule) = SampleStatementParser.classifyMerchantWithRule(merchant, rules)
        val finalCategory = selectedCategory ?: if (transactionType == TransactionType.INCOME) ExpenseCategory.SALARY_INCOME else autoCategory
        val source = if (selectedCategory == null && matchedRule != null) ExpenseSource.AUTO_RULE else ExpenseSource.MANUAL

        val effectiveWalletId = if (walletId > 0L) walletId else (matchedRule?.targetWalletId ?: 0L)

        val txnId = expenseDao.insertExpense(
            ExpenseEntity(
                accountId = accountId,
                merchant = merchant.trim(),
                amountCents = baseAmountCents,
                originalAmountCents = if (originalAmountCents > 0L) originalAmountCents else baseAmountCents,
                originalCurrencyCode = originalCurrencyCode,
                transactionType = transactionType.name,
                category = finalCategory.name,
                customCategoryName = customCategoryName?.takeIf { it.isNotBlank() },
                dateMillis = dateMillis,
                yearMonth = DateMonthUtils.yearMonthFromMillis(dateMillis),
                paymentMethod = paymentMethod.name,
                walletId = effectiveWalletId,
                goalId = effectiveGoalId,
                note = note.trim(),
                receiptUri = receiptUri,
                source = source.name,
                matchedRuleKeyword = if (source == ExpenseSource.AUTO_RULE) matchedRule?.keyword else null
            )
        )

        if (effectiveWalletId > 0L) {
            val delta = if (transactionType == TransactionType.INCOME) baseAmountCents else -baseAmountCents
            walletDao.adjustBalance(effectiveWalletId, delta)
        }
        if (effectiveGoalId != null) {
            goalDao.contribute(effectiveGoalId, -baseAmountCents)
        }

        if (splits.isNotEmpty()) {
            splitDao.insertSplits(
                splits.map {
                    SplitEntryEntity(
                        accountId = accountId,
                        transactionId = txnId,
                        friendName = it.friendName.trim(),
                        shareCents = it.shareCents
                    )
                }
            )
        }

        if (repeatMonthly) {
            recurringDao.insertRecurring(
                RecurringExpenseEntity(
                    accountId = accountId,
                    merchant = merchant.trim(),
                    amountCents = baseAmountCents,
                    transactionType = transactionType.name,
                    category = finalCategory.name,
                    paymentMethod = paymentMethod.name,
                    walletId = effectiveWalletId,
                    dayOfMonth = DateMonthUtils.dayOfMonthFromMillis(dateMillis).coerceIn(1, 28),
                    note = note.trim(),
                    isActive = true,
                    lastPostedYearMonth = DateMonthUtils.yearMonthFromMillis(dateMillis)
                )
            )
        }

        writeAutoRecoverySnapshot(accountId)
        return Result.success(finalCategory)
    }

    suspend fun updateTransaction(
        oldExpense: ExpenseEntity,
        updatedExpense: ExpenseEntity
    ): Result<Unit> {
        val oldType = TransactionType.fromRaw(oldExpense.transactionType)
        val newType = TransactionType.fromRaw(updatedExpense.transactionType)
        val newGoalId = if (newType == TransactionType.EXPENSE && (updatedExpense.goalId ?: 0L) > 0L) updatedExpense.goalId else null

        if (newGoalId != null) {
            val g = goalDao.getById(newGoalId)
            val prevRefund = if (oldType == TransactionType.EXPENSE && oldExpense.goalId == newGoalId) oldExpense.amountCents else 0L
            val available = (g?.savedCents ?: 0L) + prevRefund
            if (g == null || updatedExpense.amountCents > available) {
                return Result.failure(IllegalArgumentException("Not enough saved in that goal."))
            }
        }

        // Reverse old wallet & goal deltas
        if (oldExpense.walletId > 0L) {
            val oldDelta = if (oldType == TransactionType.INCOME) -oldExpense.amountCents else oldExpense.amountCents
            walletDao.adjustBalance(oldExpense.walletId, oldDelta)
        }
        if (oldType == TransactionType.EXPENSE && (oldExpense.goalId ?: 0L) > 0L) {
            goalDao.contribute(oldExpense.goalId!!, oldExpense.amountCents)
        }

        val normalized = updatedExpense.copy(
            yearMonth = DateMonthUtils.yearMonthFromMillis(updatedExpense.dateMillis),
            goalId = newGoalId
        )
        expenseDao.updateExpense(normalized)
        if (normalized.walletId > 0L) {
            val newDelta = if (newType == TransactionType.INCOME) normalized.amountCents else -normalized.amountCents
            walletDao.adjustBalance(normalized.walletId, newDelta)
        }
        if (newGoalId != null) {
            goalDao.contribute(newGoalId, -normalized.amountCents)
        }
        writeAutoRecoverySnapshot(oldExpense.accountId)
        return Result.success(Unit)
    }

    suspend fun deleteTransaction(expense: ExpenseEntity) {
        val type = TransactionType.fromRaw(expense.transactionType)
        if (expense.walletId > 0L) {
            val revert = if (type == TransactionType.INCOME) -expense.amountCents else expense.amountCents
            walletDao.adjustBalance(expense.walletId, revert)
        }
        if (type == TransactionType.EXPENSE && (expense.goalId ?: 0L) > 0L) {
            goalDao.contribute(expense.goalId!!, expense.amountCents)
        }
        splitDao.deleteForTransaction(expense.id)
        expenseDao.deleteExpenseById(expense.id)
        writeAutoRecoverySnapshot(expense.accountId)
    }

    suspend fun duplicateTransactionForToday(expense: ExpenseEntity): Boolean {
        val now = System.currentTimeMillis()
        val type = TransactionType.fromRaw(expense.transactionType)
        var linkedGoalId = if (type == TransactionType.EXPENSE) expense.goalId else null
        var droppedGoal = false
        if (linkedGoalId != null && linkedGoalId > 0L) {
            val g = goalDao.getById(linkedGoalId)
            if (g == null || g.savedCents < expense.amountCents) {
                linkedGoalId = null
                droppedGoal = true
            }
        }
        expenseDao.insertExpense(
            expense.copy(
                id = 0L,
                dateMillis = now,
                yearMonth = DateMonthUtils.yearMonthFromMillis(now),
                goalId = linkedGoalId,
                receiptUri = null,
                source = ExpenseSource.MANUAL.name,
                createdAtMillis = now
            )
        )
        if (expense.walletId > 0L) {
            val delta = if (type == TransactionType.INCOME) expense.amountCents else -expense.amountCents
            walletDao.adjustBalance(expense.walletId, delta)
        }
        if (linkedGoalId != null && linkedGoalId > 0L) {
            goalDao.contribute(linkedGoalId, -expense.amountCents)
        }
        writeAutoRecoverySnapshot(expense.accountId)
        return droppedGoal
    }

    suspend fun settleSplit(split: SplitEntryEntity) {
        val newSettled = !split.isSettled
        splitDao.setSplitSettled(split.id, newSettled, if (newSettled) System.currentTimeMillis() else null)
    }

    // ---------- WALLETS, TRANSFERS & AUTO-ADD SCHEDULES ----------

    suspend fun addWallet(accountId: Long, name: String, type: WalletType, initialBalanceCents: Long) {
        walletDao.insertWallet(
            WalletEntity(
                accountId = accountId,
                name = name.trim(),
                walletType = type.name,
                balanceCents = initialBalanceCents
            )
        )
    }

    suspend fun setWalletRealBalance(walletId: Long, actualBalanceCents: Long) {
        val wallet = walletDao.getById(walletId) ?: return
        walletDao.updateWallet(wallet.copy(balanceCents = actualBalanceCents))
        writeAutoRecoverySnapshot(wallet.accountId)
    }

    suspend fun transferBetweenWallets(
        accountId: Long,
        fromWalletId: Long,
        toWalletId: Long,
        amountCents: Long,
        dateMillis: Long,
        note: String
    ): Result<Unit> {
        if (fromWalletId == toWalletId) {
            return Result.failure(IllegalArgumentException("Choose two different wallets."))
        }
        if (amountCents <= 0L) {
            return Result.failure(IllegalArgumentException("Enter a valid transfer amount."))
        }
        transferDao.insert(
            WalletTransferEntity(
                accountId = accountId,
                fromWalletId = fromWalletId,
                toWalletId = toWalletId,
                amountCents = amountCents,
                dateMillis = dateMillis,
                note = note.trim()
            )
        )
        walletDao.adjustBalance(fromWalletId, -amountCents)
        walletDao.adjustBalance(toWalletId, amountCents)
        writeAutoRecoverySnapshot(accountId)
        return Result.success(Unit)
    }

    suspend fun deleteTransfer(transfer: WalletTransferEntity) {
        walletDao.adjustBalance(transfer.fromWalletId, transfer.amountCents)
        walletDao.adjustBalance(transfer.toWalletId, -transfer.amountCents)
        transferDao.deleteById(transfer.id)
        writeAutoRecoverySnapshot(transfer.accountId)
    }

    suspend fun addAutoAddRule(
        accountId: Long,
        walletId: Long,
        amountCents: Long,
        frequency: String,
        startDateKey: String,
        note: String
    ): Int {
        val cleanDate = startDateKey.ifBlank { DateMonthUtils.todayKey() }
        val anchor = cleanDate.takeLast(2).toIntOrNull()?.coerceIn(1, 31) ?: 1
        autoAddRuleDao.insert(
            AutoAddRuleEntity(
                accountId = accountId,
                walletId = walletId,
                amountCents = amountCents,
                frequency = frequency.uppercase(),
                nextDateKey = cleanDate,
                anchorDay = anchor,
                note = note.trim().ifBlank { "Pocket money" },
                isActive = true
            )
        )
        return syncDueAutoAddRules(accountId)
    }

    suspend fun toggleAutoAddRule(rule: AutoAddRuleEntity, skipMissedDays: Boolean = true): Int {
        val nextActive = !rule.isActive
        var nextKey = rule.nextDateKey
        if (nextActive && skipMissedDays) {
            val today = DateMonthUtils.todayKey()
            var guard = 0
            while (nextKey < today && guard++ < 1500) {
                nextKey = DateMonthUtils.advanceDateKey(nextKey, rule.frequency, rule.anchorDay)
            }
        }
        autoAddRuleDao.update(rule.copy(isActive = nextActive, nextDateKey = nextKey))
        return if (nextActive) syncDueAutoAddRules(rule.accountId) else 0
    }

    suspend fun deleteAutoAddRule(id: Long) = autoAddRuleDao.deleteById(id)

    suspend fun syncDueAutoAddRules(accountId: Long): Int {
        val rules = autoAddRuleDao.getSnapshot(accountId)
        if (rules.isEmpty()) return 0
        val today = DateMonthUtils.todayKey()
        val baseCode = settingsDao.getSettingsSnapshot()?.currencyCode ?: "USD"
        var postedCount = 0
        for (rule in rules) {
            if (!rule.isActive || rule.amountCents <= 0L) continue
            var cursor = rule.nextDateKey
            var guard = 0
            var advanced = false
            while (cursor <= today && guard++ < 500) {
                val postMillis = DateMonthUtils.millisForIsoDate(cursor)
                expenseDao.insertExpense(
                    ExpenseEntity(
                        accountId = accountId,
                        merchant = rule.note.ifBlank { "Pocket money" },
                        amountCents = rule.amountCents,
                        originalAmountCents = rule.amountCents,
                        originalCurrencyCode = baseCode,
                        transactionType = TransactionType.INCOME.name,
                        category = ExpenseCategory.SALARY_INCOME.name,
                        dateMillis = postMillis,
                        yearMonth = cursor.take(7),
                        paymentMethod = PaymentMethod.WALLET.name,
                        walletId = rule.walletId,
                        note = "Auto-add (${rule.frequency.lowercase()})",
                        source = ExpenseSource.RECURRING.name,
                        matchedRuleKeyword = "Auto-add"
                    )
                )
                if (rule.walletId > 0L) {
                    walletDao.adjustBalance(rule.walletId, rule.amountCents)
                }
                cursor = DateMonthUtils.advanceDateKey(cursor, rule.frequency, rule.anchorDay)
                advanced = true
                postedCount++
            }
            if (advanced) {
                autoAddRuleDao.update(rule.copy(nextDateKey = cursor))
            }
        }
        if (postedCount > 0) writeAutoRecoverySnapshot(accountId)
        return postedCount
    }

    suspend fun addMoneyToWallet(accountId: Long, walletId: Long, amountCents: Long, logAsIncome: Boolean) {
        walletDao.adjustBalance(walletId, amountCents)
        if (logAsIncome) {
            val now = System.currentTimeMillis()
            expenseDao.insertExpense(
                ExpenseEntity(
                    accountId = accountId,
                    merchant = "Wallet Top-up",
                    amountCents = amountCents,
                    originalAmountCents = amountCents,
                    originalCurrencyCode = settingsDao.getSettingsSnapshot()?.currencyCode ?: "USD",
                    transactionType = TransactionType.INCOME.name,
                    category = ExpenseCategory.SALARY_INCOME.name,
                    dateMillis = now,
                    yearMonth = DateMonthUtils.yearMonthFromMillis(now),
                    paymentMethod = PaymentMethod.WALLET.name,
                    walletId = walletId,
                    note = "Added funds to wallet",
                    source = ExpenseSource.MANUAL.name
                )
            )
        }
        writeAutoRecoverySnapshot(accountId)
    }

    // ---------- CUSTOM CATEGORIES & ROLLOVER BUDGETS ----------

    suspend fun addCustomCategory(accountId: Long, name: String, type: TransactionType) {
        customCatDao.insert(
            CustomCategoryEntity(
                accountId = accountId,
                name = name.trim(),
                transactionType = type.name
            )
        )
    }

    suspend fun updateCategoryBudget(accountId: Long, category: ExpenseCategory, limitCents: Long, rolloverEnabled: Boolean) {
        budgetDao.upsertBudget(
            CategoryBudgetEntity(
                id = "${accountId}_${category.name}",
                accountId = accountId,
                category = category.name,
                limitCents = limitCents,
                rolloverEnabled = rolloverEnabled
            )
        )
    }

    // ---------- AUTO RULES & RECURRING ----------

    suspend fun addAutoRule(accountId: Long, keyword: String, category: ExpenseCategory, targetWalletId: Long?) {
        ruleDao.insertRule(
            AutoRuleEntity(
                accountId = accountId,
                keyword = keyword.trim().lowercase(),
                category = category.name,
                targetWalletId = targetWalletId,
                isEnabled = true,
                isBuiltIn = false
            )
        )
    }

    suspend fun setRuleEnabled(id: Long, enabled: Boolean) = ruleDao.setRuleEnabled(id, enabled)
    suspend fun deleteAutoRule(id: Long) = ruleDao.deleteRuleById(id)

    suspend fun applyRulesToOtherExpenses(accountId: Long): Int {
        val rules = ruleDao.getEnabledRulesSnapshot(accountId)
        val all = expenseDao.getAllExpensesSnapshot(accountId)
        var count = 0
        for (item in all) {
            if (ExpenseCategory.fromRaw(item.category) == ExpenseCategory.OTHER) {
                val (newCat, matchedRule) = SampleStatementParser.classifyMerchantWithRule(item.merchant, rules)
                if (newCat != ExpenseCategory.OTHER && matchedRule != null) {
                    expenseDao.updateExpense(
                        item.copy(
                            category = newCat.name,
                            source = ExpenseSource.AUTO_RULE.name,
                            matchedRuleKeyword = matchedRule.keyword,
                            walletId = if (item.walletId == 0L && matchedRule.targetWalletId != null) matchedRule.targetWalletId else item.walletId
                        )
                    )
                    count++
                }
            }
        }
        return count
    }

    suspend fun importDrafts(
        accountId: Long,
        drafts: List<ParsedExpenseDraft>,
        baseCurrencyCode: String,
        usdRates: Map<String, Double>,
        defaultWalletId: Long
    ): Int {
        val selected = drafts.filter { it.isSelected && it.amountCents > 0L }
        if (selected.isEmpty()) return 0
        for (draft in selected) {
            val converted = ExchangeRateService.convertCents(draft.amountCents, draft.currencyCode, baseCurrencyCode, usdRates)
            val walletId = draft.targetWalletId ?: defaultWalletId
            expenseDao.insertExpense(
                ExpenseEntity(
                    accountId = accountId,
                    merchant = draft.merchant,
                    amountCents = converted,
                    originalAmountCents = draft.amountCents,
                    originalCurrencyCode = draft.currencyCode,
                    transactionType = draft.transactionType.name,
                    category = draft.category.name,
                    dateMillis = draft.dateMillis,
                    yearMonth = draft.yearMonth,
                    paymentMethod = draft.paymentMethod.name,
                    walletId = walletId,
                    note = draft.note,
                    source = ExpenseSource.IMPORTED.name,
                    matchedRuleKeyword = draft.matchedKeyword
                )
            )
            if (walletId > 0L) {
                val delta = if (draft.transactionType == TransactionType.INCOME) converted else -converted
                walletDao.adjustBalance(walletId, delta)
            }
        }
        writeAutoRecoverySnapshot(accountId)
        return selected.size
    }

    suspend fun addRecurringExpense(
        accountId: Long,
        merchant: String,
        amountCents: Long,
        category: ExpenseCategory,
        dayOfMonth: Int,
        walletId: Long,
        note: String
    ) {
        recurringDao.insertRecurring(
            RecurringExpenseEntity(
                accountId = accountId,
                merchant = merchant.trim(),
                amountCents = amountCents,
                category = category.name,
                walletId = walletId,
                dayOfMonth = dayOfMonth.coerceIn(1, 28),
                note = note.trim(),
                isActive = true
            )
        )
    }

    suspend fun setRecurringActive(id: Long, active: Boolean) = recurringDao.setRecurringActive(id, active)
    suspend fun deleteRecurring(id: Long) = recurringDao.deleteRecurringById(id)

    suspend fun syncRecurringForMonth(accountId: Long, targetYearMonth: String, onlyIfDueToday: Boolean): Int {
        val activeItems = recurringDao.getActiveRecurringSnapshot(accountId)
        if (activeItems.isEmpty()) return 0
        val currentYm = DateMonthUtils.currentYearMonth()
        val todayDay = DateMonthUtils.dayOfMonthFromMillis(System.currentTimeMillis())
        val baseCode = settingsDao.getSettingsSnapshot()?.currencyCode ?: "USD"
        var postedCount = 0
        for (item in activeItems) {
            if (item.lastPostedYearMonth == targetYearMonth) continue
            if (onlyIfDueToday && targetYearMonth == currentYm && item.dayOfMonth > todayDay) continue
            if (targetYearMonth > currentYm) continue
            val postMillis = DateMonthUtils.millisForDayInMonth(targetYearMonth, item.dayOfMonth)
            expenseDao.insertExpense(
                ExpenseEntity(
                    accountId = accountId,
                    merchant = item.merchant,
                    amountCents = item.amountCents,
                    originalAmountCents = item.amountCents,
                    originalCurrencyCode = baseCode,
                    transactionType = item.transactionType,
                    category = item.category,
                    dateMillis = postMillis,
                    yearMonth = targetYearMonth,
                    paymentMethod = item.paymentMethod,
                    walletId = item.walletId,
                    note = item.note.ifBlank { "Automated recurring entry" },
                    source = ExpenseSource.RECURRING.name,
                    matchedRuleKeyword = "Day ${item.dayOfMonth}"
                )
            )
            if (item.walletId > 0L) {
                val delta = if (TransactionType.fromRaw(item.transactionType) == TransactionType.INCOME) item.amountCents else -item.amountCents
                walletDao.adjustBalance(item.walletId, delta)
            }
            recurringDao.markPostedForMonth(item.id, targetYearMonth)
            postedCount++
        }
        return postedCount
    }

    // ---------- GOALS, LENDING, SUBSCRIPTIONS, CHALLENGES, BILLS ----------

    suspend fun addGoal(accountId: Long, name: String, targetCents: Long, targetDateMillis: Long?) {
        goalDao.insertGoal(GoalEntity(accountId = accountId, name = name.trim(), targetCents = targetCents, targetDateMillis = targetDateMillis))
    }

    suspend fun contributeToGoal(goalId: Long, deltaCents: Long, walletId: Long?) {
        goalDao.contribute(goalId, deltaCents)
        if (walletId != null && walletId > 0L) {
            walletDao.adjustBalance(walletId, -deltaCents)
        }
    }

    suspend fun deleteGoal(id: Long) = goalDao.deleteById(id)

    suspend fun addLending(
        accountId: Long,
        personName: String,
        direction: LendingDirection,
        totalCents: Long,
        dueDateMillis: Long?,
        note: String
    ) {
        lendingDao.insertLending(
            LendingEntity(
                accountId = accountId,
                personName = personName.trim(),
                direction = direction.name,
                totalCents = totalCents,
                dueDateMillis = dueDateMillis,
                note = note.trim()
            )
        )
    }

    suspend fun settleOrPayLending(item: LendingEntity, paymentCents: Long) {
        val nextPaid = (item.paidCents + paymentCents).coerceAtMost(item.totalCents)
        lendingDao.updateLending(
            item.copy(paidCents = nextPaid, isSettled = nextPaid >= item.totalCents)
        )
    }

    suspend fun deleteLending(id: Long) = lendingDao.deleteById(id)

    suspend fun addSubscription(
        accountId: Long,
        name: String,
        amountCents: Long,
        billingCycle: String,
        category: ExpenseCategory,
        nextRenewalMillis: Long,
        reminderEnabled: Boolean
    ) {
        subscriptionDao.insert(
            SubscriptionEntity(
                accountId = accountId,
                name = name.trim(),
                amountCents = amountCents,
                billingCycle = billingCycle,
                category = category.name,
                nextRenewalMillis = nextRenewalMillis,
                reminderEnabled = reminderEnabled
            )
        )
    }

    suspend fun advanceSubscriptionRenewal(sub: SubscriptionEntity) {
        val next = if (sub.billingCycle.equals("YEARLY", ignoreCase = true)) {
            DateMonthUtils.addMonths(sub.nextRenewalMillis, 12)
        } else {
            DateMonthUtils.addMonths(sub.nextRenewalMillis, 1)
        }
        subscriptionDao.update(sub.copy(nextRenewalMillis = next))
    }

    suspend fun toggleSubscriptionReminder(sub: SubscriptionEntity) {
        subscriptionDao.update(sub.copy(reminderEnabled = !sub.reminderEnabled))
    }

    suspend fun deleteSubscription(id: Long) = subscriptionDao.deleteById(id)

    suspend fun addChallenge(
        accountId: Long,
        title: String,
        kind: String,
        targetDays: Int,
        dailySaveCents: Long,
        startDateKey: String,
        goalId: Long?
    ) {
        val cleanKind = if (kind.equals("NOSPEND", ignoreCase = true)) "NOSPEND" else "SAVE"
        challengeDao.insert(
            ChallengeEntity(
                accountId = accountId,
                title = title.trim(),
                kind = cleanKind,
                targetDays = targetDays.coerceIn(3, 365),
                dailySaveCents = if (cleanKind == "SAVE") dailySaveCents else 0L,
                startDateKey = startDateKey.ifBlank { DateMonthUtils.todayKey() },
                goalId = if (cleanKind == "SAVE" && goalId != null && goalId > 0L) goalId else null
            )
        )
    }

    suspend fun toggleChallengeDay(challenge: ChallengeEntity, dateKey: String): Result<Boolean> {
        if (!challenge.kind.equals("SAVE", ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("No-spend days update automatically from your transactions."))
        }
        val today = DateMonthUtils.todayKey()
        if (dateKey > today) {
            return Result.failure(IllegalArgumentException("Future days cannot be checked in yet."))
        }
        val checkedSet = challenge.checkInDatesCsv
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toMutableSet()
        // Keep legacy lastCheckInDayKey if csv was empty
        if (checkedSet.isEmpty() && !challenge.lastCheckInDayKey.isNullOrBlank()) {
            checkedSet.add(challenge.lastCheckInDayKey)
        }
        val wasChecked = checkedSet.contains(dateKey)
        val amt = challenge.dailySaveCents
        val linkedGoalId = challenge.goalId

        if (wasChecked && linkedGoalId != null && linkedGoalId > 0L && amt > 0L) {
            val goal = goalDao.getById(linkedGoalId)
            if (goal != null && goal.savedCents < amt) {
                return Result.failure(
                    IllegalArgumentException("That day's saving was already spent from \"${goal.name}\", so it cannot be undone.")
                )
            }
        }

        if (wasChecked) checkedSet.remove(dateKey) else checkedSet.add(dateKey)
        if (linkedGoalId != null && linkedGoalId > 0L && amt > 0L) {
            goalDao.contribute(linkedGoalId, if (wasChecked) -amt else amt)
        }

        val challengeDays = DateMonthUtils.daysInChallenge(challenge.startDateKey, challenge.targetDays).toSet()
        val doneCount = checkedSet.count { it in challengeDays || challenge.startDateKey.isBlank() }
        challengeDao.update(
            challenge.copy(
                completedDays = doneCount,
                checkInDatesCsv = checkedSet.sorted().joinToString(","),
                lastCheckInDayKey = checkedSet.maxOrNull(),
                isCompleted = doneCount >= challenge.targetDays
            )
        )
        return Result.success(!wasChecked)
    }

    suspend fun checkInChallenge(challenge: ChallengeEntity): Boolean {
        val today = DateMonthUtils.todayKey()
        val res = toggleChallengeDay(challenge, today)
        return res.getOrDefault(false)
    }

    suspend fun deleteChallenge(id: Long) = challengeDao.deleteById(id)

    suspend fun addBill(
        accountId: Long,
        title: String,
        billType: BillType,
        amountCents: Long,
        dueDayOfMonth: Int,
        category: ExpenseCategory
    ) {
        billDao.insert(
            BillItemEntity(
                accountId = accountId,
                title = title.trim(),
                billType = billType.name,
                amountCents = amountCents,
                dueDayOfMonth = dueDayOfMonth.coerceIn(1, 28),
                category = category.name
            )
        )
    }

    suspend fun markBillPaid(accountId: Long, bill: BillItemEntity, yearMonth: String, walletId: Long) {
        if (bill.lastPaidYearMonth == yearMonth) return
        val baseCode = settingsDao.getSettingsSnapshot()?.currencyCode ?: "USD"
        val paidMillis = System.currentTimeMillis()
        expenseDao.insertExpense(
            ExpenseEntity(
                accountId = accountId,
                merchant = "${bill.title} (${BillType.fromRaw(bill.billType).label})",
                amountCents = bill.amountCents,
                originalAmountCents = bill.amountCents,
                originalCurrencyCode = baseCode,
                transactionType = TransactionType.EXPENSE.name,
                category = bill.category,
                dateMillis = paidMillis,
                yearMonth = yearMonth,
                paymentMethod = PaymentMethod.BANK_TRANSFER.name,
                walletId = walletId,
                note = "Bill calendar payment",
                source = ExpenseSource.MANUAL.name
            )
        )
        if (walletId > 0L) {
            walletDao.adjustBalance(walletId, -bill.amountCents)
        }
        billDao.update(bill.copy(lastPaidYearMonth = yearMonth))
        writeAutoRecoverySnapshot(accountId)
    }

    suspend fun deleteBill(id: Long) = billDao.deleteById(id)

    // ---------- SETTINGS, LIVE RATES & BACKUP/RESTORE ----------

    suspend fun refreshExchangeRates(): Result<Unit> {
        val result = ExchangeRateService.fetchLiveUsdRates()
        return result.fold(
            onSuccess = { json ->
                rateDao.upsertCache(ExchangeRateCacheEntity(baseCode = "USD", ratesJson = json, updatedAtMillis = System.currentTimeMillis()))
                Result.success(Unit)
            },
            onFailure = { err ->
                if (rateDao.getCacheSnapshot() == null) {
                    rateDao.upsertCache(ExchangeRateCacheEntity(baseCode = "USD", ratesJson = ExchangeRateService.defaultRatesJson(), updatedAtMillis = 0L))
                }
                Result.failure(err)
            }
        )
    }

    suspend fun updateSettings(transform: (AppSettingsEntity) -> AppSettingsEntity) {
        val current = settingsDao.getSettingsSnapshot() ?: AppSettingsEntity()
        settingsDao.upsertSettings(transform(current))
    }

    suspend fun updateBaseCurrency(newCode: String) {
        val clean = newCode.uppercase()
        updateSettings { it.copy(currencyCode = clean, currencySymbol = currencySymbolFor(clean)) }
    }

    suspend fun exportAccountBackupJson(accountId: Long): String {
        val expenses = expenseDao.getAllExpensesSnapshot(accountId)
        val splits = splitDao.getAllSplitsSnapshot(accountId)
        val wallets = walletDao.getWalletsSnapshot(accountId)
        val transfers = transferDao.getSnapshot(accountId)
        val autoAdds = autoAddRuleDao.getSnapshot(accountId)
        val customCats = customCatDao.getSnapshot(accountId)
        val budgets = budgetDao.getBudgetsSnapshot(accountId)
        val rules = ruleDao.getEnabledRulesSnapshot(accountId)
        val recurring = recurringDao.getAllSnapshot(accountId)
        val goals = goalDao.getSnapshot(accountId)
        val lending = lendingDao.getSnapshot(accountId)
        val subs = subscriptionDao.getSnapshot(accountId)
        val challenges = challengeDao.getSnapshot(accountId)
        val bills = billDao.getSnapshot(accountId)

        val root = JSONObject()
        root.put("version", 3)
        root.put("exportedAtMillis", System.currentTimeMillis())

        root.put("wallets", JSONArray().apply {
            wallets.forEach { w ->
                put(JSONObject().apply {
                    put("id", w.id); put("name", w.name); put("walletType", w.walletType); put("balanceCents", w.balanceCents)
                })
            }
        })
        root.put("transfers", JSONArray().apply {
            transfers.forEach { t ->
                put(JSONObject().apply {
                    put("fromWalletId", t.fromWalletId); put("toWalletId", t.toWalletId)
                    put("amountCents", t.amountCents); put("dateMillis", t.dateMillis); put("note", t.note)
                })
            }
        })
        root.put("autoAddRules", JSONArray().apply {
            autoAdds.forEach { r ->
                put(JSONObject().apply {
                    put("walletId", r.walletId); put("amountCents", r.amountCents)
                    put("frequency", r.frequency); put("nextDateKey", r.nextDateKey)
                    put("anchorDay", r.anchorDay); put("note", r.note); put("isActive", r.isActive)
                })
            }
        })
        root.put("expenses", JSONArray().apply {
            expenses.forEach { e ->
                put(JSONObject().apply {
                    put("id", e.id); put("merchant", e.merchant); put("amountCents", e.amountCents)
                    put("originalAmountCents", e.originalAmountCents); put("originalCurrencyCode", e.originalCurrencyCode)
                    put("transactionType", e.transactionType); put("category", e.category)
                    put("customCategoryName", e.customCategoryName ?: ""); put("dateMillis", e.dateMillis)
                    put("yearMonth", e.yearMonth); put("paymentMethod", e.paymentMethod)
                    put("walletId", e.walletId); put("goalId", e.goalId ?: 0L); put("note", e.note); put("source", e.source)
                })
            }
        })
        root.put("splits", JSONArray().apply {
            splits.forEach { s ->
                put(JSONObject().apply {
                    put("transactionId", s.transactionId); put("friendName", s.friendName)
                    put("shareCents", s.shareCents); put("isSettled", s.isSettled)
                })
            }
        })
        root.put("customCategories", JSONArray().apply {
            customCats.forEach { c ->
                put(JSONObject().apply { put("name", c.name); put("transactionType", c.transactionType) })
            }
        })
        root.put("budgets", JSONArray().apply {
            budgets.forEach { b ->
                put(JSONObject().apply { put("category", b.category); put("limitCents", b.limitCents); put("rolloverEnabled", b.rolloverEnabled) })
            }
        })
        root.put("rules", JSONArray().apply {
            rules.filter { !it.isBuiltIn }.forEach { r ->
                put(JSONObject().apply { put("keyword", r.keyword); put("category", r.category); put("isEnabled", r.isEnabled) })
            }
        })
        root.put("recurring", JSONArray().apply {
            recurring.forEach { r ->
                put(JSONObject().apply {
                    put("merchant", r.merchant); put("amountCents", r.amountCents); put("transactionType", r.transactionType)
                    put("category", r.category); put("dayOfMonth", r.dayOfMonth); put("note", r.note); put("isActive", r.isActive)
                })
            }
        })
        root.put("goals", JSONArray().apply {
            goals.forEach { g ->
                put(JSONObject().apply {
                    put("id", g.id); put("name", g.name); put("targetCents", g.targetCents)
                    put("savedCents", g.savedCents); put("targetDateMillis", g.targetDateMillis ?: 0L)
                })
            }
        })
        root.put("lending", JSONArray().apply {
            lending.forEach { l ->
                put(JSONObject().apply {
                    put("personName", l.personName); put("direction", l.direction); put("totalCents", l.totalCents)
                    put("paidCents", l.paidCents); put("dueDateMillis", l.dueDateMillis ?: 0L)
                    put("note", l.note); put("isSettled", l.isSettled)
                })
            }
        })
        root.put("subscriptions", JSONArray().apply {
            subs.forEach { s ->
                put(JSONObject().apply {
                    put("name", s.name); put("amountCents", s.amountCents); put("billingCycle", s.billingCycle)
                    put("category", s.category); put("nextRenewalMillis", s.nextRenewalMillis); put("reminderEnabled", s.reminderEnabled)
                })
            }
        })
        root.put("challenges", JSONArray().apply {
            challenges.forEach { c ->
                put(JSONObject().apply {
                    put("title", c.title); put("kind", c.kind); put("targetDays", c.targetDays)
                    put("completedDays", c.completedDays); put("dailySaveCents", c.dailySaveCents)
                    put("startDateKey", c.startDateKey); put("checkInDatesCsv", c.checkInDatesCsv)
                    put("goalId", c.goalId ?: 0L); put("isCompleted", c.isCompleted)
                })
            }
        })
        root.put("bills", JSONArray().apply {
            bills.forEach { b ->
                put(JSONObject().apply {
                    put("title", b.title); put("billType", b.billType); put("amountCents", b.amountCents)
                    put("dueDayOfMonth", b.dueDayOfMonth); put("category", b.category); put("lastPaidYearMonth", b.lastPaidYearMonth ?: "")
                })
            }
        })

        updateSettings { it.copy(lastBackupMillis = System.currentTimeMillis()) }
        return root.toString(2)
    }

    suspend fun restoreAccountBackupJson(accountId: Long, rawJson: String): Result<Int> {
        return try {
            val root = JSONObject(rawJson)
            wipeAccountData(accountId)
            ClearLedgerDatabase.seedAccountDefaults(db, accountId)

            val walletIdMap = mutableMapOf<Long, Long>()
            val walletsArr = root.optJSONArray("wallets")
            if (walletsArr != null && walletsArr.length() > 0) {
                walletDao.deleteAllForAccount(accountId)
                for (i in 0 until walletsArr.length()) {
                    val o = walletsArr.getJSONObject(i)
                    val newId = walletDao.insertWallet(
                        WalletEntity(
                            accountId = accountId,
                            name = o.getString("name"),
                            walletType = o.optString("walletType", "BANK"),
                            balanceCents = o.optLong("balanceCents", 0L)
                        )
                    )
                    walletIdMap[o.optLong("id", 0L)] = newId
                }
            }

            val goalIdMap = mutableMapOf<Long, Long>()
            val goalsArr = root.optJSONArray("goals") ?: JSONArray()
            for (i in 0 until goalsArr.length()) {
                val o = goalsArr.getJSONObject(i)
                val targetDate = o.optLong("targetDateMillis", 0L).takeIf { it > 0L }
                val newId = goalDao.insertGoal(
                    GoalEntity(
                        accountId = accountId,
                        name = o.getString("name"),
                        targetCents = o.getLong("targetCents"),
                        savedCents = o.optLong("savedCents", 0L),
                        targetDateMillis = targetDate
                    )
                )
                val oldId = o.optLong("id", 0L)
                if (oldId > 0L) goalIdMap[oldId] = newId
            }

            val txnIdMap = mutableMapOf<Long, Long>()
            val expArr = root.optJSONArray("expenses") ?: JSONArray()
            for (i in 0 until expArr.length()) {
                val o = expArr.getJSONObject(i)
                val oldWallet = o.optLong("walletId", 0L)
                val oldGoal = o.optLong("goalId", 0L)
                val newId = expenseDao.insertExpense(
                    ExpenseEntity(
                        accountId = accountId,
                        merchant = o.getString("merchant"),
                        amountCents = o.getLong("amountCents"),
                        originalAmountCents = o.optLong("originalAmountCents", o.getLong("amountCents")),
                        originalCurrencyCode = o.optString("originalCurrencyCode", "USD"),
                        transactionType = o.optString("transactionType", "EXPENSE"),
                        category = o.optString("category", "OTHER"),
                        customCategoryName = o.optString("customCategoryName").takeIf { it.isNotBlank() },
                        dateMillis = o.getLong("dateMillis"),
                        yearMonth = o.getString("yearMonth"),
                        paymentMethod = o.optString("paymentMethod", "CARD"),
                        walletId = walletIdMap[oldWallet] ?: 0L,
                        goalId = goalIdMap[oldGoal],
                        note = o.optString("note", ""),
                        source = o.optString("source", "MANUAL")
                    )
                )
                txnIdMap[o.optLong("id", 0L)] = newId
            }

            val transferArr = root.optJSONArray("transfers") ?: JSONArray()
            for (i in 0 until transferArr.length()) {
                val o = transferArr.getJSONObject(i)
                transferDao.insert(
                    WalletTransferEntity(
                        accountId = accountId,
                        fromWalletId = walletIdMap[o.optLong("fromWalletId", 0L)] ?: 0L,
                        toWalletId = walletIdMap[o.optLong("toWalletId", 0L)] ?: 0L,
                        amountCents = o.optLong("amountCents", 0L),
                        dateMillis = o.optLong("dateMillis", System.currentTimeMillis()),
                        note = o.optString("note", "")
                    )
                )
            }

            val autoAddArr = root.optJSONArray("autoAddRules") ?: JSONArray()
            for (i in 0 until autoAddArr.length()) {
                val o = autoAddArr.getJSONObject(i)
                autoAddRuleDao.insert(
                    AutoAddRuleEntity(
                        accountId = accountId,
                        walletId = walletIdMap[o.optLong("walletId", 0L)] ?: 0L,
                        amountCents = o.optLong("amountCents", 0L),
                        frequency = o.optString("frequency", "DAILY"),
                        nextDateKey = o.optString("nextDateKey", DateMonthUtils.todayKey()),
                        anchorDay = o.optInt("anchorDay", 1),
                        note = o.optString("note", "Pocket money"),
                        isActive = o.optBoolean("isActive", true)
                    )
                )
            }

            val splitsArr = root.optJSONArray("splits") ?: JSONArray()
            val splitsToInsert = mutableListOf<SplitEntryEntity>()
            for (i in 0 until splitsArr.length()) {
                val o = splitsArr.getJSONObject(i)
                val mappedTxn = txnIdMap[o.optLong("transactionId", 0L)] ?: continue
                splitsToInsert += SplitEntryEntity(
                    accountId = accountId,
                    transactionId = mappedTxn,
                    friendName = o.getString("friendName"),
                    shareCents = o.getLong("shareCents"),
                    isSettled = o.optBoolean("isSettled", false)
                )
            }
            if (splitsToInsert.isNotEmpty()) splitDao.insertSplits(splitsToInsert)

            val catArr = root.optJSONArray("customCategories") ?: JSONArray()
            for (i in 0 until catArr.length()) {
                val o = catArr.getJSONObject(i)
                customCatDao.insert(CustomCategoryEntity(accountId = accountId, name = o.getString("name"), transactionType = o.optString("transactionType", "EXPENSE")))
            }

            val budgetArr = root.optJSONArray("budgets") ?: JSONArray()
            for (i in 0 until budgetArr.length()) {
                val o = budgetArr.getJSONObject(i)
                val cat = o.getString("category")
                budgetDao.upsertBudget(CategoryBudgetEntity(id = "${accountId}_$cat", accountId = accountId, category = cat, limitCents = o.getLong("limitCents"), rolloverEnabled = o.optBoolean("rolloverEnabled", false)))
            }

            val lendingArr = root.optJSONArray("lending") ?: JSONArray()
            for (i in 0 until lendingArr.length()) {
                val o = lendingArr.getJSONObject(i)
                lendingDao.insertLending(
                    LendingEntity(
                        accountId = accountId, personName = o.getString("personName"), direction = o.getString("direction"),
                        totalCents = o.getLong("totalCents"), paidCents = o.optLong("paidCents", 0L),
                        dueDateMillis = o.optLong("dueDateMillis", 0L).takeIf { it > 0L },
                        note = o.optString("note", ""), isSettled = o.optBoolean("isSettled", false)
                    )
                )
            }

            val subArr = root.optJSONArray("subscriptions") ?: JSONArray()
            for (i in 0 until subArr.length()) {
                val o = subArr.getJSONObject(i)
                subscriptionDao.insert(
                    SubscriptionEntity(
                        accountId = accountId, name = o.getString("name"), amountCents = o.getLong("amountCents"),
                        billingCycle = o.optString("billingCycle", "MONTHLY"), category = o.optString("category", "ENTERTAINMENT"),
                        nextRenewalMillis = o.getLong("nextRenewalMillis"), reminderEnabled = o.optBoolean("reminderEnabled", true)
                    )
                )
            }

            val chalArr = root.optJSONArray("challenges") ?: JSONArray()
            for (i in 0 until chalArr.length()) {
                val o = chalArr.getJSONObject(i)
                val oldGoal = o.optLong("goalId", 0L)
                challengeDao.insert(
                    ChallengeEntity(
                        accountId = accountId,
                        title = o.getString("title"),
                        kind = o.optString("kind", "SAVE"),
                        targetDays = o.optInt("targetDays", 30),
                        completedDays = o.optInt("completedDays", 0),
                        dailySaveCents = o.optLong("dailySaveCents", 500L),
                        startDateKey = o.optString("startDateKey", DateMonthUtils.todayKey()),
                        checkInDatesCsv = o.optString("checkInDatesCsv", ""),
                        goalId = goalIdMap[oldGoal],
                        isCompleted = o.optBoolean("isCompleted", false)
                    )
                )
            }

            val billsArr = root.optJSONArray("bills") ?: JSONArray()
            for (i in 0 until billsArr.length()) {
                val o = billsArr.getJSONObject(i)
                billDao.insert(
                    BillItemEntity(
                        accountId = accountId, title = o.getString("title"), billType = o.optString("billType", "UTILITY"),
                        amountCents = o.getLong("amountCents"), dueDayOfMonth = o.optInt("dueDayOfMonth", 1),
                        category = o.optString("category", "UTILITIES"),
                        lastPaidYearMonth = o.optString("lastPaidYearMonth").takeIf { it.isNotBlank() }
                    )
                )
            }

            Result.success(expArr.length())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun writeAutoRecoverySnapshot(accountId: Long) {
        if (accountId <= 0L) return
        try {
            val json = exportAccountBackupJson(accountId)
            withContext(Dispatchers.IO) {
                File(context.filesDir, "recovery_$accountId.json").writeText(json)
            }
        } catch (_: Exception) {
        }
    }

    suspend fun hasAutoRecoverySnapshot(accountId: Long): Boolean = withContext(Dispatchers.IO) {
        File(context.filesDir, "recovery_$accountId.json").exists()
    }

    suspend fun restoreFromAutoRecovery(accountId: Long): Result<Int> {
        val file = File(context.filesDir, "recovery_$accountId.json")
        if (!file.exists()) return Result.failure(IllegalStateException("No auto-recovery snapshot found yet."))
        val content = withContext(Dispatchers.IO) { file.readText() }
        return restoreAccountBackupJson(accountId, content)
    }
}
