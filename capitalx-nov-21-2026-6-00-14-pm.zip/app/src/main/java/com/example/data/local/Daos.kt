package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseItemDao {
    @Query("SELECT * FROM expense_items ORDER BY date DESC, id DESC")
    fun observeAllExpenses(): Flow<List<Expense>>

    @Query("SELECT * FROM expense_items WHERE category = :category ORDER BY date DESC, id DESC")
    fun observeExpensesByCategory(category: String): Flow<List<Expense>>

    @Query("SELECT * FROM expense_items WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC, id DESC")
    fun observeExpensesInDateRange(startDate: Long, endDate: Long): Flow<List<Expense>>

    @Query("SELECT * FROM expense_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Expense?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)

    @Query("DELETE FROM expense_items WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface LocalAccountDao {
    @Query("SELECT * FROM local_accounts ORDER BY id ASC")
    fun observeAllAccounts(): Flow<List<LocalAccountEntity>>

    @Query("SELECT * FROM local_accounts WHERE LOWER(username) = LOWER(:username) LIMIT 1")
    suspend fun getByUsername(username: String): LocalAccountEntity?

    @Query("SELECT * FROM local_accounts WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): LocalAccountEntity?

    @Query("SELECT * FROM local_accounts WHERE id = :id LIMIT 1")
    fun observeAccount(id: Long): Flow<LocalAccountEntity?>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAccount(account: LocalAccountEntity): Long

    @Update
    suspend fun updateAccount(account: LocalAccountEntity)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE accountId = :accountId AND yearMonth = :yearMonth ORDER BY dateMillis DESC, id DESC")
    fun observeExpensesForMonth(accountId: Long, yearMonth: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE accountId = :accountId ORDER BY dateMillis DESC, id DESC")
    fun observeAllExpenses(accountId: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE accountId = :accountId")
    suspend fun getAllExpensesSnapshot(accountId: Long): List<ExpenseEntity>

    @Query("SELECT * FROM expenses WHERE accountId = :accountId AND yearMonth = :yearMonth")
    suspend fun getMonthExpensesSnapshot(accountId: Long, yearMonth: String): List<ExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(expenses: List<ExpenseEntity>)

    @Update
    suspend fun updateExpense(expense: ExpenseEntity)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpenseById(id: Long)

    @Query("DELETE FROM expenses WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface SplitEntryDao {
    @Query("SELECT * FROM split_entries WHERE accountId = :accountId ORDER BY id DESC")
    fun observeAllSplits(accountId: Long): Flow<List<SplitEntryEntity>>

    @Query("SELECT * FROM split_entries WHERE accountId = :accountId")
    suspend fun getAllSplitsSnapshot(accountId: Long): List<SplitEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSplits(splits: List<SplitEntryEntity>)

    @Query("UPDATE split_entries SET isSettled = :settled, settledAtMillis = :settledAtMillis WHERE id = :id")
    suspend fun setSplitSettled(id: Long, settled: Boolean, settledAtMillis: Long?)

    @Query("DELETE FROM split_entries WHERE transactionId = :transactionId")
    suspend fun deleteForTransaction(transactionId: Long)

    @Query("DELETE FROM split_entries WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets WHERE accountId = :accountId ORDER BY id ASC")
    fun observeWallets(accountId: Long): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets WHERE accountId = :accountId ORDER BY id ASC")
    suspend fun getWalletsSnapshot(accountId: Long): List<WalletEntity>

    @Query("SELECT * FROM wallets WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): WalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: WalletEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallets(wallets: List<WalletEntity>)

    @Update
    suspend fun updateWallet(wallet: WalletEntity)

    @Query("UPDATE wallets SET balanceCents = balanceCents + :deltaCents WHERE id = :walletId")
    suspend fun adjustBalance(walletId: Long, deltaCents: Long)

    @Query("DELETE FROM wallets WHERE id = :id")
    suspend fun deleteWalletById(id: Long)

    @Query("DELETE FROM wallets WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface WalletTransferDao {
    @Query("SELECT * FROM wallet_transfers WHERE accountId = :accountId ORDER BY dateMillis DESC, id DESC")
    fun observeTransfers(accountId: Long): Flow<List<WalletTransferEntity>>

    @Query("SELECT * FROM wallet_transfers WHERE accountId = :accountId ORDER BY dateMillis DESC, id DESC")
    suspend fun getSnapshot(accountId: Long): List<WalletTransferEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transfer: WalletTransferEntity): Long

    @Query("DELETE FROM wallet_transfers WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM wallet_transfers WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface AutoAddRuleDao {
    @Query("SELECT * FROM auto_add_rules WHERE accountId = :accountId ORDER BY id DESC")
    fun observeAutoAddRules(accountId: Long): Flow<List<AutoAddRuleEntity>>

    @Query("SELECT * FROM auto_add_rules WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<AutoAddRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(rule: AutoAddRuleEntity): Long

    @Update
    suspend fun update(rule: AutoAddRuleEntity)

    @Query("DELETE FROM auto_add_rules WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM auto_add_rules WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface CustomCategoryDao {
    @Query("SELECT * FROM custom_categories WHERE accountId = :accountId ORDER BY name ASC")
    fun observeCustomCategories(accountId: Long): Flow<List<CustomCategoryEntity>>

    @Query("SELECT * FROM custom_categories WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<CustomCategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CustomCategoryEntity): Long

    @Query("DELETE FROM custom_categories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM custom_categories WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface CategoryBudgetDao {
    @Query("SELECT * FROM category_budgets WHERE accountId = :accountId")
    fun observeAllBudgets(accountId: Long): Flow<List<CategoryBudgetEntity>>

    @Query("SELECT * FROM category_budgets WHERE accountId = :accountId")
    suspend fun getBudgetsSnapshot(accountId: Long): List<CategoryBudgetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBudget(budget: CategoryBudgetEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBudgetsIfAbsent(budgets: List<CategoryBudgetEntity>)

    @Query("DELETE FROM category_budgets WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface AutoRuleDao {
    @Query("SELECT * FROM auto_rules WHERE accountId = :accountId ORDER BY isBuiltIn ASC, id DESC")
    fun observeAllRules(accountId: Long): Flow<List<AutoRuleEntity>>

    @Query("SELECT * FROM auto_rules WHERE accountId = :accountId AND isEnabled = 1 ORDER BY isBuiltIn ASC, id DESC")
    suspend fun getEnabledRulesSnapshot(accountId: Long): List<AutoRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AutoRuleEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertRules(rules: List<AutoRuleEntity>)

    @Query("UPDATE auto_rules SET isEnabled = :enabled WHERE id = :id")
    suspend fun setRuleEnabled(id: Long, enabled: Boolean)

    @Query("DELETE FROM auto_rules WHERE id = :id")
    suspend fun deleteRuleById(id: Long)

    @Query("DELETE FROM auto_rules WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface RecurringExpenseDao {
    @Query("SELECT * FROM recurring_expenses WHERE accountId = :accountId ORDER BY dayOfMonth ASC, id DESC")
    fun observeAllRecurring(accountId: Long): Flow<List<RecurringExpenseEntity>>

    @Query("SELECT * FROM recurring_expenses WHERE accountId = :accountId AND isActive = 1")
    suspend fun getActiveRecurringSnapshot(accountId: Long): List<RecurringExpenseEntity>

    @Query("SELECT * FROM recurring_expenses WHERE accountId = :accountId")
    suspend fun getAllSnapshot(accountId: Long): List<RecurringExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecurring(item: RecurringExpenseEntity): Long

    @Query("UPDATE recurring_expenses SET isActive = :active WHERE id = :id")
    suspend fun setRecurringActive(id: Long, active: Boolean)

    @Query("UPDATE recurring_expenses SET lastPostedYearMonth = :yearMonth WHERE id = :id")
    suspend fun markPostedForMonth(id: Long, yearMonth: String)

    @Query("DELETE FROM recurring_expenses WHERE id = :id")
    suspend fun deleteRecurringById(id: Long)

    @Query("DELETE FROM recurring_expenses WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM savings_goals WHERE accountId = :accountId ORDER BY id DESC")
    fun observeGoals(accountId: Long): Flow<List<GoalEntity>>

    @Query("SELECT * FROM savings_goals WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<GoalEntity>

    @Query("SELECT * FROM savings_goals WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): GoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity): Long

    @Query("UPDATE savings_goals SET savedCents = MAX(0, savedCents + :deltaCents) WHERE id = :id")
    suspend fun contribute(id: Long, deltaCents: Long)

    @Query("DELETE FROM savings_goals WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM savings_goals WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface LendingDao {
    @Query("SELECT * FROM lending_records WHERE accountId = :accountId ORDER BY isSettled ASC, id DESC")
    fun observeLending(accountId: Long): Flow<List<LendingEntity>>

    @Query("SELECT * FROM lending_records WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<LendingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLending(item: LendingEntity): Long

    @Update
    suspend fun updateLending(item: LendingEntity)

    @Query("DELETE FROM lending_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM lending_records WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions WHERE accountId = :accountId ORDER BY nextRenewalMillis ASC")
    fun observeSubscriptions(accountId: Long): Flow<List<SubscriptionEntity>>

    @Query("SELECT * FROM subscriptions WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<SubscriptionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sub: SubscriptionEntity): Long

    @Update
    suspend fun update(sub: SubscriptionEntity)

    @Query("DELETE FROM subscriptions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM subscriptions WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface ChallengeDao {
    @Query("SELECT * FROM savings_challenges WHERE accountId = :accountId ORDER BY id DESC")
    fun observeChallenges(accountId: Long): Flow<List<ChallengeEntity>>

    @Query("SELECT * FROM savings_challenges WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<ChallengeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(challenge: ChallengeEntity): Long

    @Update
    suspend fun update(challenge: ChallengeEntity)

    @Query("DELETE FROM savings_challenges WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM savings_challenges WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface BillItemDao {
    @Query("SELECT * FROM bill_calendar_items WHERE accountId = :accountId ORDER BY dueDayOfMonth ASC")
    fun observeBills(accountId: Long): Flow<List<BillItemEntity>>

    @Query("SELECT * FROM bill_calendar_items WHERE accountId = :accountId")
    suspend fun getSnapshot(accountId: Long): List<BillItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bill: BillItemEntity): Long

    @Update
    suspend fun update(bill: BillItemEntity)

    @Query("DELETE FROM bill_calendar_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM bill_calendar_items WHERE accountId = :accountId")
    suspend fun deleteAllForAccount(accountId: Long)
}

@Dao
interface ExchangeRateCacheDao {
    @Query("SELECT * FROM exchange_rate_cache WHERE baseCode = 'USD' LIMIT 1")
    fun observeCache(): Flow<ExchangeRateCacheEntity?>

    @Query("SELECT * FROM exchange_rate_cache WHERE baseCode = 'USD' LIMIT 1")
    suspend fun getCacheSnapshot(): ExchangeRateCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCache(cache: ExchangeRateCacheEntity)
}

@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun observeSettings(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun getSettingsSnapshot(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettings(settings: AppSettingsEntity)
}
