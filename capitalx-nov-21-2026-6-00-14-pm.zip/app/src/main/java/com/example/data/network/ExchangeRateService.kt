package com.example.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToLong

object ExchangeRateService {

    // Offline baseline rates relative to 1 USD so currency conversion works offline immediately
    val defaultUsdRates: Map<String, Double> = mapOf(
        "USD" to 1.0,
        "INR" to 84.35,
        "EUR" to 0.92,
        "GBP" to 0.79,
        "JPY" to 154.20,
        "AED" to 3.6725,
        "SGD" to 1.34,
        "CAD" to 1.40,
        "AUD" to 1.54
    )

    fun defaultRatesJson(): String = JSONObject(defaultUsdRates).toString()

    fun parseRatesJson(json: String?): Map<String, Double> {
        if (json.isNullOrBlank()) return defaultUsdRates
        return try {
            val obj = JSONObject(json)
            val result = mutableMapOf<String, Double>()
            for (key in obj.keys()) {
                val value = obj.optDouble(key, 0.0)
                if (value > 0.0) result[key.uppercase()] = value
            }
            if (result.isEmpty()) defaultUsdRates else defaultUsdRates + result
        } catch (_: Exception) {
            defaultUsdRates
        }
    }

    fun convertCents(
        amountCents: Long,
        fromCurrency: String,
        toCurrency: String,
        usdRates: Map<String, Double>
    ): Long {
        if (fromCurrency.equals(toCurrency, ignoreCase = true)) return amountCents
        val fromRate = usdRates[fromCurrency.uppercase()] ?: return amountCents
        val toRate = usdRates[toCurrency.uppercase()] ?: return amountCents
        if (fromRate <= 0.0) return amountCents
        val converted = amountCents.toDouble() * (toRate / fromRate)
        return converted.roundToLong()
    }

    suspend fun fetchLiveUsdRates(): Result<String> = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val url = URL("https://open.er-api.com/v6/latest/USD")
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                requestMethod = "GET"
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                return@withContext Result.failure(IllegalStateException("HTTP $code"))
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val ratesObj = root.optJSONObject("rates")
                ?: return@withContext Result.failure(IllegalStateException("Missing rates payload"))
            val subset = JSONObject()
            for (c in listOf("USD", "INR", "EUR", "GBP", "JPY", "AED", "SGD", "CAD", "AUD")) {
                val r = ratesObj.optDouble(c, -1.0)
                if (r > 0.0) subset.put(c, r)
            }
            Result.success(subset.toString())
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            conn?.disconnect()
        }
    }
}
