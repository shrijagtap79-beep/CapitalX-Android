package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AttachMoney
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.CatEntertainmentColor
import com.example.ui.theme.CatFoodColor
import com.example.ui.theme.CatGroceriesColor
import com.example.ui.theme.CatHealthColor
import com.example.ui.theme.CatHousingColor
import com.example.ui.theme.CatOtherColor
import com.example.ui.theme.CatSalaryColor
import com.example.ui.theme.CatShoppingColor
import com.example.ui.theme.CatTransportColor
import com.example.ui.theme.CatTravelColor
import com.example.ui.theme.CatUtilitiesColor

enum class TransactionType(val label: String) {
    EXPENSE("Expense"),
    INCOME("Income");

    companion object {
        fun fromRaw(raw: String?): TransactionType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: EXPENSE
    }
}

enum class PaymentMethod(val label: String, val icon: ImageVector) {
    UPI("UPI", Icons.Rounded.QrCode2),
    CARD("Card", Icons.Rounded.CreditCard),
    CASH("Cash", Icons.Rounded.Payments),
    BANK_TRANSFER("Bank", Icons.Rounded.AccountBalance),
    WALLET("Wallet", Icons.Rounded.AccountBalanceWallet);

    companion object {
        fun fromRaw(raw: String?): PaymentMethod =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: CARD
    }
}

enum class WalletType(val label: String, val icon: ImageVector) {
    BANK("Bank Account", Icons.Rounded.AccountBalance),
    UPI("UPI Wallet", Icons.Rounded.QrCode2),
    CASH("Cash", Icons.Rounded.Payments);

    companion object {
        fun fromRaw(raw: String?): WalletType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: BANK
    }
}

enum class LendingDirection(val label: String) {
    OWED_TO_ME("Owed to Me"),
    I_OWE("I Owe");

    companion object {
        fun fromRaw(raw: String?): LendingDirection =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: OWED_TO_ME
    }
}

enum class BillType(val label: String) {
    EMI("EMI"),
    RENT("Rent"),
    CREDIT_CARD("Credit Card"),
    UTILITY("Utility");

    companion object {
        fun fromRaw(raw: String?): BillType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: UTILITY
    }
}

enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark");

    companion object {
        fun fromRaw(raw: String?): ThemeMode =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: SYSTEM
    }
}

enum class DashboardWidget(val key: String, val label: String) {
    SAFE_TO_SPEND("safe_to_spend", "Safe to spend today"),
    MONTH_END_FORECAST("month_end_forecast", "Month-end forecast"),
    NET_THIS_MONTH("net_this_month", "Net this month"),
    BUDGET_USED("budget_used", "Budget used")
}

data class CurrencyInfo(
    val code: String,
    val symbol: String,
    val name: String
)

val SupportedCurrencies = listOf(
    CurrencyInfo("USD", "$", "US Dollar"),
    CurrencyInfo("INR", "₹", "Indian Rupee"),
    CurrencyInfo("EUR", "€", "Euro"),
    CurrencyInfo("GBP", "£", "British Pound"),
    CurrencyInfo("JPY", "¥", "Japanese Yen"),
    CurrencyInfo("AED", "د.إ", "UAE Dirham"),
    CurrencyInfo("SGD", "S$", "Singapore Dollar"),
    CurrencyInfo("CAD", "C$", "Canadian Dollar"),
    CurrencyInfo("AUD", "A$", "Australian Dollar")
)

fun currencySymbolFor(code: String): String =
    SupportedCurrencies.firstOrNull { it.code.equals(code, ignoreCase = true) }?.symbol ?: "$"

enum class ExpenseCategory(
    val displayName: String,
    val shortName: String,
    val defaultMonthlyLimitCents: Long,
    val color: Color,
    val icon: ImageVector,
    val isIncomeDefault: Boolean = false
) {
    FOOD_DINING("Food & Dining", "Dining", 450_00L, CatFoodColor, Icons.Rounded.Restaurant),
    GROCERIES("Groceries", "Groceries", 500_00L, CatGroceriesColor, Icons.Rounded.ShoppingCart),
    TRANSPORT("Transport", "Transport", 250_00L, CatTransportColor, Icons.Rounded.DirectionsCar),
    HOUSING("Housing & Rent", "Housing", 1500_00L, CatHousingColor, Icons.Rounded.Home),
    UTILITIES("Bills & Utilities", "Utilities", 220_00L, CatUtilitiesColor, Icons.Rounded.Bolt),
    SHOPPING("Shopping", "Shopping", 300_00L, CatShoppingColor, Icons.Rounded.ShoppingBag),
    ENTERTAINMENT("Entertainment", "Fun", 150_00L, CatEntertainmentColor, Icons.Rounded.Movie),
    HEALTH("Health & Fitness", "Health", 180_00L, CatHealthColor, Icons.Rounded.LocalHospital),
    TRAVEL("Travel", "Travel", 250_00L, CatTravelColor, Icons.Rounded.Flight),
    SALARY_INCOME("Income & Salary", "Income", 0L, CatSalaryColor, Icons.Rounded.AttachMoney, isIncomeDefault = true),
    OTHER("Other", "Other", 200_00L, CatOtherColor, Icons.Rounded.Category);

    companion object {
        val expenseEntries: List<ExpenseCategory>
            get() = entries.filter { !it.isIncomeDefault }

        fun fromRaw(raw: String?): ExpenseCategory {
            if (raw.isNullOrBlank()) return OTHER
            val normalized = raw.trim().lowercase()
            return entries.firstOrNull {
                it.name.equals(raw.trim(), ignoreCase = true) ||
                    it.displayName.equals(raw.trim(), ignoreCase = true) ||
                    it.shortName.equals(raw.trim(), ignoreCase = true)
            } ?: when {
                normalized.contains("salary") || normalized.contains("income") || normalized.contains("bonus") || normalized.contains("dividend") -> SALARY_INCOME
                normalized.contains("food") || normalized.contains("dining") || normalized.contains("restaurant") || normalized.contains("coffee") -> FOOD_DINING
                normalized.contains("grocer") || normalized.contains("supermarket") -> GROCERIES
                normalized.contains("transport") || normalized.contains("fuel") || normalized.contains("gas") || normalized.contains("transit") -> TRANSPORT
                normalized.contains("hous") || normalized.contains("rent") || normalized.contains("mortgage") -> HOUSING
                normalized.contains("util") || normalized.contains("bill") || normalized.contains("internet") || normalized.contains("phone") -> UTILITIES
                normalized.contains("shop") || normalized.contains("retail") || normalized.contains("cloth") -> SHOPPING
                normalized.contains("entertain") || normalized.contains("sub") || normalized.contains("stream") -> ENTERTAINMENT
                normalized.contains("health") || normalized.contains("med") || normalized.contains("gym") || normalized.contains("fitness") -> HEALTH
                normalized.contains("travel") || normalized.contains("flight") || normalized.contains("hotel") -> TRAVEL
                else -> OTHER
            }
        }
    }
}

enum class ExpenseSource(val label: String) {
    MANUAL("Manual"),
    AUTO_RULE("Auto-Rule"),
    IMPORTED("Imported"),
    RECURRING("Recurring");

    companion object {
        fun fromRaw(raw: String?): ExpenseSource =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: MANUAL
    }
}
