package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "local_accounts")
data class LocalAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val displayName: String,
    val username: String,
    val passwordHash: String,
    val passwordSalt: String,
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val pinFailedAttempts: Int = 0,
    val pinLockoutUntilMillis: Long = 0L,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "expense_items")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val amount: Double,
    val date: Long,
    val category: String,
    val description: String
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long = 1L,
    val merchant: String,
    val amountCents: Long,
    val originalAmountCents: Long = 0L,
    val originalCurrencyCode: String = "USD",
    val transactionType: String = "EXPENSE",
    val category: String,
    val customCategoryName: String? = null,
    val dateMillis: Long,
    val yearMonth: String,
    val paymentMethod: String = "CARD",
    val walletId: Long = 0L,
    val goalId: Long? = null,
    val note: String = "",
    val receiptUri: String? = null,
    val source: String = "MANUAL",
    val matchedRuleKeyword: String? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "split_entries")
data class SplitEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val transactionId: Long,
    val friendName: String,
    val shareCents: Long,
    val isSettled: Boolean = false,
    val settledAtMillis: Long? = null
)

@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val name: String,
    val walletType: String,
    val balanceCents: Long,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallet_transfers")
data class WalletTransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val fromWalletId: Long,
    val toWalletId: Long,
    val amountCents: Long,
    val dateMillis: Long,
    val note: String = ""
)

@Entity(tableName = "auto_add_rules")
data class AutoAddRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val walletId: Long,
    val amountCents: Long,
    val frequency: String = "DAILY", // DAILY, WEEKLY, MONTHLY
    val nextDateKey: String,
    val anchorDay: Int = 1,
    val note: String = "Pocket money",
    val isActive: Boolean = true
)

@Entity(tableName = "custom_categories")
data class CustomCategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val name: String,
    val transactionType: String = "EXPENSE",
    val colorArgb: Long = 0xFF22E58BL
)

@Entity(tableName = "category_budgets")
data class CategoryBudgetEntity(
    @PrimaryKey val id: String,
    val accountId: Long,
    val category: String,
    val limitCents: Long,
    val rolloverEnabled: Boolean = false
)

@Entity(tableName = "auto_rules")
data class AutoRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val keyword: String,
    val category: String,
    val targetWalletId: Long? = null,
    val isEnabled: Boolean = true,
    val isBuiltIn: Boolean = false
)

@Entity(tableName = "recurring_expenses")
data class RecurringExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val merchant: String,
    val amountCents: Long,
    val transactionType: String = "EXPENSE",
    val category: String,
    val paymentMethod: String = "CARD",
    val walletId: Long = 0L,
    val dayOfMonth: Int,
    val note: String = "",
    val isActive: Boolean = true,
    val lastPostedYearMonth: String? = null
)

@Entity(tableName = "savings_goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val name: String,
    val targetCents: Long,
    val savedCents: Long = 0L,
    val targetDateMillis: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "lending_records")
data class LendingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val personName: String,
    val direction: String,
    val totalCents: Long,
    val paidCents: Long = 0L,
    val dueDateMillis: Long? = null,
    val note: String = "",
    val isSettled: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val name: String,
    val amountCents: Long,
    val billingCycle: String = "MONTHLY",
    val category: String = "ENTERTAINMENT",
    val nextRenewalMillis: Long,
    val reminderEnabled: Boolean = true,
    val isActive: Boolean = true
)

@Entity(tableName = "savings_challenges")
data class ChallengeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val title: String,
    val kind: String = "SAVE", // SAVE or NOSPEND
    val targetDays: Int = 30,
    val completedDays: Int = 0,
    val dailySaveCents: Long = 500L,
    val startDateKey: String = "",
    val checkInDatesCsv: String = "",
    val goalId: Long? = null,
    val lastCheckInDayKey: String? = null,
    val isCompleted: Boolean = false
)

@Entity(tableName = "bill_calendar_items")
data class BillItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val accountId: Long,
    val title: String,
    val billType: String,
    val amountCents: Long,
    val dueDayOfMonth: Int,
    val category: String = "UTILITIES",
    val lastPaidYearMonth: String? = null,
    val reminderEnabled: Boolean = true
)

@Entity(tableName = "exchange_rate_cache")
data class ExchangeRateCacheEntity(
    @PrimaryKey val baseCode: String = "USD",
    val ratesJson: String,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val activeAccountId: Long = 0L,
    val currencyCode: String = "USD",
    val currencySymbol: String = "$",
    val themeMode: String = "DARK",
    val hideAmounts: Boolean = false,
    val notificationsEnabled: Boolean = false,
    val lastBackupMillis: Long = 0L,
    val visibleWidgetsCsv: String = "safe_to_spend,month_end_forecast,net_this_month,budget_used"
)
