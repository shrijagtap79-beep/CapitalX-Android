package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CapitalX v9.5 Light Palette: Crisp Financial Sage + Bull Green / Bear Red
val BullGreenLight = Color(0xFF24734B)
val BullGreenBright = Color(0xFF2E8B5B)
val BullGreenSoft = Color(0xFFDFF2E5)
val BullMist = Color(0xFFEDF4EE)

val BearRedLight = Color(0xFFC34F4F)
val BearRedSoft = Color(0xFFFFF0EF)
val TickerGoldLight = Color(0xFF9B6818)
val TickerGoldSoft = Color(0xFFFFF8E8)

val CanvasLight = Color(0xFFF5F7F4)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2ED)
val OutlineLight = Color(0xFFDCE5DD)
val OutlineHairlineLight = Color(0xFFE5EBE5)
val TextPrimaryLight = Color(0xFF17251C)
val TextSecondaryLight = Color(0xFF6B786E)

// CapitalX v9.5 Dark Palette: Trading Glass Terminal (#070B10 + Luminous Bull Green #22E58B / Bear Red #FF4D6A)
val BullGreenDark = Color(0xFF22E58B)
val BullContainerDark = Color(0xFF0D2E22)
val BearRedDark = Color(0xFFFF4D6A)
val BearContainerDark = Color(0xFF3A131E)
val TickerGoldDark = Color(0xFFFFB84D)
val TickerGoldContainerDark = Color(0xFF36270B)

val CanvasDark = Color(0xFF070B10)
val SurfaceDark = Color(0xFF0E151E)
val SurfaceVariantDark = Color(0xFF151E2A)
val OutlineDark = Color(0xFF283444)
val OutlineHairlineDark = Color(0x18FFFFFF)
val TextPrimaryDark = Color(0xFFE8EEF5)
val TextSecondaryDark = Color(0xFF8693A3)

// Ambient Trading Glass Glows (used on dark terminal canvas)
val GlassEmeraldGlow = Color(0x2222E58B)
val GlassBlueGlow = Color(0x1E4D7CFF)
val GlassRedGlow = Color(0x14FF4D6A)

// Distinct Category Chart Colors
val CatFoodColor = Color(0xFF22E58B)
val CatGroceriesColor = Color(0xFF38BDF8)
val CatTransportColor = Color(0xFFFFB84D)
val CatHousingColor = Color(0xFF818CF8)
val CatUtilitiesColor = Color(0xFF2DD4BF)
val CatShoppingColor = Color(0xFFF472B6)
val CatEntertainmentColor = Color(0xFFA78BFA)
val CatHealthColor = Color(0xFFFF4D6A)
val CatTravelColor = Color(0xFF0EA5E9)
val CatSalaryColor = Color(0xFF10B981)
val CatOtherColor = Color(0xFF8693A3)
