package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.GoalEntity
import com.example.data.local.WalletEntity
import com.example.data.model.BillType
import com.example.data.model.ExpenseCategory
import com.example.data.model.LendingDirection
import com.example.data.model.WalletType
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.SampleStatementParser
import com.example.ui.state.MoneyFormatters
import java.util.Locale

@Composable
fun AddWalletDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (name: String, type: WalletType, balanceCents: Long) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var balanceText by remember { mutableStateOf("0") }
    var type by remember { mutableStateOf(WalletType.BANK) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Wallet") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Wallet name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = balanceText, onValueChange = { balanceText = it }, label = { Text("Opening balance ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WalletType.entries.forEach { wt ->
                        FilterChip(selected = type == wt, onClick = { type = wt }, label = { Text(wt.label.substringBefore(" ")) })
                    }
                }
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(balanceText) ?: 0L
            Button(onClick = { onConfirm(name.trim(), type, cents) }, enabled = name.isNotBlank()) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddMoneyToWalletDialog(
    wallet: WalletEntity,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (amountCents: Long, logAsIncome: Boolean) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var logAsIncome by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Money · ${wallet.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Also log as Income transaction", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = logAsIncome, onCheckedChange = { logAsIncome = it })
                }
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            Button(onClick = { cents?.let { onConfirm(it, logAsIncome) } }, enabled = cents != null && cents > 0L) { Text("Add Funds") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SetRealBalanceDialog(
    wallet: WalletEntity,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (actualBalanceCents: Long) -> Unit
) {
    var balanceText by remember(wallet.id) {
        mutableStateOf(String.format(Locale.US, "%.2f", wallet.balanceCents / 100.0))
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Real Balance · ${wallet.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Calibrate this wallet to match your actual bank or cash balance without adding a fake transaction.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it },
                    label = { Text("Actual balance ($currencySymbol)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().testTag("real_balance_input")
                )
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(balanceText)
            Button(
                onClick = { cents?.let(onConfirm) },
                enabled = cents != null,
                modifier = Modifier.testTag("confirm_real_balance_button")
            ) { Text("Calibrate") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun TransferWalletsDialog(
    wallets: List<WalletEntity>,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (fromWalletId: Long, toWalletId: Long, amountCents: Long, dateMillis: Long, note: String) -> Unit
) {
    var fromId by remember(wallets) { mutableStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var toId by remember(wallets) { mutableStateOf(wallets.getOrNull(1)?.id ?: wallets.firstOrNull()?.id ?: 0L) }
    var amountText by remember { mutableStateOf("") }
    var dateKey by remember { mutableStateOf(DateMonthUtils.todayKey()) }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Transfer Between Wallets") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("From wallet:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    wallets.forEach { w ->
                        FilterChip(selected = fromId == w.id, onClick = { fromId = w.id }, label = { Text(w.name) })
                    }
                }
                Text("To wallet:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    wallets.forEach { w ->
                        FilterChip(selected = toId == w.id, onClick = { toId = w.id }, label = { Text(w.name) })
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount ($currencySymbol)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().testTag("transfer_amount_input")
                )
                OutlinedTextField(
                    value = dateKey,
                    onValueChange = { dateKey = it },
                    label = { Text("Date (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            val valid = wallets.size >= 2 && fromId != toId && cents != null && cents > 0L
            Button(
                onClick = {
                    if (valid) {
                        onConfirm(fromId, toId, cents!!, DateMonthUtils.millisForIsoDate(dateKey), note.trim())
                    }
                },
                enabled = valid,
                modifier = Modifier.testTag("confirm_transfer_button")
            ) { Text("Transfer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddAutoAddScheduleDialog(
    wallets: List<WalletEntity>,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (walletId: Long, amountCents: Long, frequency: String, startDateKey: String, note: String) -> Unit
) {
    var walletId by remember(wallets) { mutableStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var amountText by remember { mutableStateOf("") }
    var frequency by remember { mutableStateOf("DAILY") }
    var startDateKey by remember { mutableStateOf(DateMonthUtils.todayKey()) }
    var note by remember { mutableStateOf("Pocket money") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule Auto-Add Money") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Target wallet:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    wallets.forEach { w ->
                        FilterChip(selected = walletId == w.id, onClick = { walletId = w.id }, label = { Text(w.name) })
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount ($currencySymbol)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().testTag("auto_add_amount_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("DAILY", "WEEKLY", "MONTHLY").forEach { f ->
                        FilterChip(
                            selected = frequency == f,
                            onClick = { frequency = f },
                            label = { Text(f.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
                OutlinedTextField(
                    value = startDateKey,
                    onValueChange = { startDateKey = it },
                    label = { Text("Start date (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            Button(
                onClick = {
                    if (walletId > 0L && cents != null && cents > 0L) {
                        onConfirm(walletId, cents, frequency, startDateKey.ifBlank { DateMonthUtils.todayKey() }, note.trim())
                    }
                },
                enabled = walletId > 0L && cents != null && cents > 0L,
                modifier = Modifier.testTag("confirm_auto_add_button")
            ) { Text("Start Schedule") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddGoalDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (name: String, targetCents: Long, targetDateMillis: Long?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var targetText by remember { mutableStateOf("") }
    var targetMonthsText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Savings Goal") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Goal name (e.g. Emergency Fund)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = targetText, onValueChange = { targetText = it }, label = { Text("Target ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = targetMonthsText,
                    onValueChange = { if (it.length <= 3 && it.all(Char::isDigit)) targetMonthsText = it },
                    label = { Text("Target timeline in months (optional)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(targetText)
            val months = targetMonthsText.toIntOrNull()?.takeIf { it > 0 }
            val targetMillis = months?.let { DateMonthUtils.addMonths(System.currentTimeMillis(), it) }
            Button(onClick = { cents?.let { onConfirm(name.trim(), it, targetMillis) } }, enabled = name.isNotBlank() && cents != null && cents > 0L) { Text("Create Goal") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ContributeGoalDialog(
    goalName: String,
    currencySymbol: String,
    wallets: List<WalletEntity>,
    onDismiss: () -> Unit,
    onConfirm: (amountCents: Long, walletId: Long?) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var selectedWalletId by remember { mutableStateOf<Long?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Contribute · $goalName") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Contribution ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                if (wallets.isNotEmpty()) {
                    Text("Deduct from wallet (optional):", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = selectedWalletId == null, onClick = { selectedWalletId = null }, label = { Text("None") })
                        wallets.forEach { w -> FilterChip(selected = selectedWalletId == w.id, onClick = { selectedWalletId = w.id }, label = { Text(w.name) }) }
                    }
                }
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            Button(onClick = { cents?.let { onConfirm(it, selectedWalletId) } }, enabled = cents != null && cents > 0L) { Text("Contribute") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddLendingDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (person: String, dir: LendingDirection, amountCents: Long, note: String) -> Unit
) {
    var person by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var dir by remember { mutableStateOf(LendingDirection.OWED_TO_ME) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lending Record") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LendingDirection.entries.forEach { d ->
                        FilterChip(selected = dir == d, onClick = { dir = d }, label = { Text(d.label) })
                    }
                }
                OutlinedTextField(value = person, onValueChange = { person = it }, label = { Text("Person name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            Button(onClick = { cents?.let { onConfirm(person.trim(), dir, it, note) } }, enabled = person.isNotBlank() && cents != null && cents > 0L) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddSubscriptionDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (name: String, amountCents: Long, cycle: String, category: ExpenseCategory, nextRenewalMillis: Long) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var cycle by remember { mutableStateOf("MONTHLY") }
    var daysUntilRenewal by remember { mutableStateOf("15") }
    var category by remember { mutableStateOf(ExpenseCategory.ENTERTAINMENT) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Subscription") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Service name (e.g. Netflix)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Cost ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1.3f))
                    OutlinedTextField(value = daysUntilRenewal, onValueChange = { if (it.all(Char::isDigit)) daysUntilRenewal = it }, label = { Text("Renews in days") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = cycle == "MONTHLY", onClick = { cycle = "MONTHLY" }, label = { Text("Monthly") })
                    FilterChip(selected = cycle == "YEARLY", onClick = { cycle = "YEARLY" }, label = { Text("Yearly") })
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExpenseCategory.expenseEntries.forEach { cat ->
                        FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.shortName) })
                    }
                }
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            val days = (daysUntilRenewal.toIntOrNull() ?: 15).coerceIn(0, 365)
            Button(
                onClick = { cents?.let { onConfirm(name.trim(), it, cycle, category, DateMonthUtils.addDays(System.currentTimeMillis(), days)) } },
                enabled = name.isNotBlank() && cents != null && cents > 0L
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddChallengeDialog(
    currencySymbol: String,
    goals: List<GoalEntity> = emptyList(),
    onDismiss: () -> Unit,
    onConfirm: (title: String, kind: String, targetDays: Int, dailySaveCents: Long, startDateKey: String, goalId: Long?) -> Unit
) {
    var kind by remember { mutableStateOf("SAVE") }
    var title by remember { mutableStateOf("30-Day Daily Saver") }
    var daysText by remember { mutableStateOf("30") }
    var dailyText by remember { mutableStateOf("50") }
    var startDateKey by remember { mutableStateOf(DateMonthUtils.todayKey()) }
    var selectedGoalId by remember { mutableStateOf<Long?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Start Savings Challenge") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Quick presets:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = false,
                        onClick = { kind = "SAVE"; title = "Save ${currencySymbol}50 × 30d"; daysText = "30"; dailyText = "50" },
                        label = { Text("50 × 30d") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { kind = "SAVE"; title = "Save ${currencySymbol}100 × 21d"; daysText = "21"; dailyText = "100" },
                        label = { Text("100 × 21d") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { kind = "NOSPEND"; title = "7-Day No-Spend"; daysText = "7"; dailyText = "0"; selectedGoalId = null },
                        label = { Text("7-day No-Spend") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { kind = "NOSPEND"; title = "30-Day No-Spend"; daysText = "30"; dailyText = "0"; selectedGoalId = null },
                        label = { Text("30-day No-Spend") }
                    )
                }

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = kind == "SAVE",
                        onClick = { kind = "SAVE" },
                        shape = SegmentedButtonDefaults.itemShape(0, 2)
                    ) { Text("Save Daily") }
                    SegmentedButton(
                        selected = kind == "NOSPEND",
                        onClick = { kind = "NOSPEND"; selectedGoalId = null },
                        shape = SegmentedButtonDefaults.itemShape(1, 2)
                    ) { Text("No-Spend") }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Challenge title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = daysText,
                        onValueChange = { if (it.all(Char::isDigit)) daysText = it },
                        label = { Text("Target days") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    if (kind == "SAVE") {
                        OutlinedTextField(
                            value = dailyText,
                            onValueChange = { dailyText = it },
                            label = { Text("Daily save ($currencySymbol)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                OutlinedTextField(
                    value = startDateKey,
                    onValueChange = { startDateKey = it },
                    label = { Text("Start date (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (kind == "SAVE" && goals.isNotEmpty()) {
                    Text("Auto-credit Savings Goal (optional):", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = selectedGoalId == null, onClick = { selectedGoalId = null }, label = { Text("None") })
                        goals.forEach { g ->
                            FilterChip(
                                selected = selectedGoalId == g.id,
                                onClick = { selectedGoalId = g.id },
                                label = { Text("${g.name} (${MoneyFormatters.formatMoney(g.savedCents, currencySymbol)})") }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            val days = (daysText.toIntOrNull() ?: 30).coerceIn(1, 365)
            val daily = if (kind == "NOSPEND") 0L else (SampleStatementParser.parseAmountToCents(dailyText) ?: 500L)
            Button(
                onClick = {
                    onConfirm(
                        title.trim(),
                        kind,
                        days,
                        daily,
                        startDateKey.ifBlank { DateMonthUtils.todayKey() },
                        if (kind == "SAVE") selectedGoalId else null
                    )
                },
                enabled = title.isNotBlank() && (kind == "NOSPEND" || daily > 0L)
            ) { Text("Start") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddBillDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (title: String, billType: BillType, amountCents: Long, dueDay: Int, category: ExpenseCategory) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var dayText by remember { mutableStateOf("5") }
    var billType by remember { mutableStateOf(BillType.CREDIT_CARD) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Bill Due Date") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Bill title (e.g. Home EMI, Rent)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1.4f))
                    OutlinedTextField(value = dayText, onValueChange = { if (it.length <= 2 && it.all(Char::isDigit)) dayText = it }, label = { Text("Due day (1-28)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BillType.entries.forEach { bt ->
                        FilterChip(selected = billType == bt, onClick = { billType = bt }, label = { Text(bt.label) })
                    }
                }
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            val day = (dayText.toIntOrNull() ?: 5).coerceIn(1, 28)
            val cat = when (billType) {
                BillType.RENT -> ExpenseCategory.HOUSING
                BillType.EMI -> ExpenseCategory.HOUSING
                BillType.CREDIT_CARD -> ExpenseCategory.OTHER
                BillType.UTILITY -> ExpenseCategory.UTILITIES
            }
            Button(onClick = { cents?.let { onConfirm(title.trim(), billType, it, day, cat) } }, enabled = title.isNotBlank() && cents != null && cents > 0L) { Text("Save Bill") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SetPinDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set App PIN Lock") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Choose a 4 to 8 digit PIN to protect Capitalx.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it },
                    label = { Text("4-8 Digit PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth().testTag("set_pin_input")
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(pin) }, enabled = pin.length in 4..8, modifier = Modifier.testTag("confirm_set_pin_button")) {
                Text("Enable PIN")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun BackupPasswordDialog(
    title: String,
    subtitle: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var pwd by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it },
                    label = { Text("Encryption Password (min 4 chars)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().testTag("backup_password_input")
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(pwd) }, enabled = pwd.length >= 4, modifier = Modifier.testTag("confirm_backup_password_button")) {
                Text(confirmLabel)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
