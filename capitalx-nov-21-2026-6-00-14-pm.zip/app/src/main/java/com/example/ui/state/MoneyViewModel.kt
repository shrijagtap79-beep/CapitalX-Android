package com.example.ui.state

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.export.ReportExporter
import com.example.data.local.AppSettingsEntity
import com.example.data.local.AutoAddRuleEntity
import com.example.data.local.AutoRuleEntity
import com.example.data.local.BillItemEntity
import com.example.data.local.CategoryBudgetEntity
import com.example.data.local.ChallengeEntity
import com.example.data.local.ClearLedgerDatabase
import com.example.data.local.CustomCategoryEntity
import com.example.data.local.ExchangeRateCacheEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.GoalEntity
import com.example.data.local.LendingEntity
import com.example.data.local.LocalAccountEntity
import com.example.data.local.RecurringExpenseEntity
import com.example.data.local.SplitEntryEntity
import com.example.data.local.SubscriptionEntity
import com.example.data.local.WalletEntity
import com.example.data.local.WalletTransferEntity
import com.example.data.model.BillType
import com.example.data.model.DashboardWidget
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseSource
import com.example.data.model.LendingDirection
import com.example.data.model.PaymentMethod
import com.example.data.model.ThemeMode
import com.example.data.model.TransactionType
import com.example.data.model.WalletType
import com.example.data.network.ExchangeRateService
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.ParsedExpenseDraft
import com.example.data.parser.ParsedSmsPreview
import com.example.data.parser.RepeatChargeSuggestion
import com.example.data.parser.SampleStatementParser
import com.example.data.repository.MoneyRepository
import com.example.data.repository.SplitInput
import com.example.data.security.CryptoAndAuth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

data class CategoryBreakdownItem(
    val category: ExpenseCategory,
    val spentCents: Long,
    val lastMonthSpentCents: Long,
    val baseBudgetCents: Long,
    val rolloverCents: Long,
    val effectiveBudgetCents: Long,
    val rolloverEnabled: Boolean,
    val shareFraction: Float,
    val budgetUtilization: Float,
    val transactionCount: Int
)

data class DailySpendPoint(
    val dayOfMonth: Int,
    val spentCents: Long,
    val incomeCents: Long,
    val transactionCount: Int
)

data class MonthlyCashflowPoint(
    val yearMonth: String,
    val shortLabel: String,
    val incomeCents: Long,
    val expenseCents: Long
)

data class ComingUpItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val amountCents: Long,
    val dueMillis: Long,
    val daysLeft: Int,
    val isBill: Boolean
)

data class TickerItem(
    val label: String,
    val valueText: String,
    val trend: Int // 1 = up/green, -1 = down/red, 0 = neutral
)

data class QuickFillSuggestion(
    val templateExpense: ExpenseEntity,
    val count: Int
)

data class MonthlyInsightsSummary(
    val avgSpendPerDayCents: Long = 0L,
    val projectedOrTotalCents: Long = 0L,
    val isCurrentMonth: Boolean = true,
    val savingsRatePercent: Int? = null,
    val savingsRateDeltaPts: Int? = null,
    val noSpendDays: Int = 0,
    val elapsedDays: Int = 0,
    val bullets: List<String> = emptyList()
)

data class ChallengeDayCell(
    val dayNumber: Int,
    val dateKey: String,
    val isDone: Boolean,
    val isToday: Boolean,
    val isFuture: Boolean
)

data class ChallengeSummary(
    val challenge: ChallengeEntity,
    val completedCount: Int,
    val streak: Int,
    val bestStreak: Int,
    val savedCents: Long,
    val dayNumber: Int,
    val isEnded: Boolean,
    val notStarted: Boolean,
    val linkedGoalName: String?,
    val cells: List<ChallengeDayCell>
)

data class WalletAnalyticsItem(
    val wallet: WalletEntity,
    val inflowCents: Long,
    val outflowCents: Long,
    val txnCount: Int
)

data class FilterState(
    val searchQuery: String = "",
    val selectedType: TransactionType? = null,
    val selectedCategory: ExpenseCategory? = null,
    val selectedPaymentMethod: PaymentMethod? = null,
    val selectedWalletId: Long? = null,
    val selectedSource: ExpenseSource? = null
)

data class ImporterState(
    val rawText: String = "",
    val drafts: List<ParsedExpenseDraft> = emptyList()
)

data class MoneyUiState(
    val activeAccount: LocalAccountEntity? = null,
    val knownUsernames: List<String> = emptyList(),
    val isPinLocked: Boolean = false,
    val pinError: String? = null,
    val authError: String? = null,
    val selectedYearMonth: String = DateMonthUtils.currentYearMonth(),
    val monthTitle: String = DateMonthUtils.formatMonthTitle(DateMonthUtils.currentYearMonth()),
    val currencySymbol: String = "$",
    val currencyCode: String = "USD",
    val themeMode: ThemeMode = ThemeMode.DARK,
    val hideAmounts: Boolean = false,
    val notificationsEnabled: Boolean = false,
    val visibleWidgets: Set<DashboardWidget> = DashboardWidget.entries.toSet(),
    val usdRates: Map<String, Double> = ExchangeRateService.defaultUsdRates,
    val ratesUpdatedAtMillis: Long = 0L,
    val allTransactions: List<ExpenseEntity> = emptyList(),
    val monthTransactions: List<ExpenseEntity> = emptyList(),
    val filteredTransactions: List<ExpenseEntity> = emptyList(),
    val splitsByTransactionId: Map<Long, List<SplitEntryEntity>> = emptyMap(),
    val wallets: List<WalletEntity> = emptyList(),
    val transfers: List<WalletTransferEntity> = emptyList(),
    val autoAddSchedules: List<AutoAddRuleEntity> = emptyList(),
    val walletAnalytics: List<WalletAnalyticsItem> = emptyList(),
    val totalWalletBalanceCents: Long = 0L,
    val negativeWallets: List<WalletEntity> = emptyList(),
    val customCategories: List<CustomCategoryEntity> = emptyList(),
    val totalIncomeCents: Long = 0L,
    val totalSpentCents: Long = 0L,
    val netThisMonthCents: Long = 0L,
    val savingsRatePercent: Int? = null,
    val todaySpentCents: Long = 0L,
    val totalBudgetCents: Long = 0L,
    val remainingCents: Long = 0L,
    val safeToSpendTodayCents: Long = 0L,
    val previousMonthSpentCents: Long = 0L,
    val projectedMonthEndCents: Long = 0L,
    val paceOverBudgetWarning: Boolean = false,
    val dailyTargetCents: Long = 0L,
    val dailyAverageCents: Long = 0L,
    val budgetAlertLevel: Int = 0, // 0 = ok, 1 = >=80%, 2 = >100%
    val overdueLendingCount: Int = 0,
    val quickFillSuggestions: List<QuickFillSuggestion> = emptyList(),
    val tickerItems: List<TickerItem> = emptyList(),
    val monthlyInsights: MonthlyInsightsSummary = MonthlyInsightsSummary(),
    val categoryBreakdowns: List<CategoryBreakdownItem> = emptyList(),
    val dailyPoints: List<DailySpendPoint> = emptyList(),
    val last6MonthsCashflow: List<MonthlyCashflowPoint> = emptyList(),
    val yearlyCashflow: List<MonthlyCashflowPoint> = emptyList(),
    val comingUp30Days: List<ComingUpItem> = emptyList(),
    val autoRules: List<AutoRuleEntity> = emptyList(),
    val recurringExpenses: List<RecurringExpenseEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val lendingRecords: List<LendingEntity> = emptyList(),
    val subscriptions: List<SubscriptionEntity> = emptyList(),
    val repeatChargeSuggestions: List<RepeatChargeSuggestion> = emptyList(),
    val challenges: List<ChallengeEntity> = emptyList(),
    val challengeSummaries: List<ChallengeSummary> = emptyList(),
    val bills: List<BillItemEntity> = emptyList(),
    val showWeeklyBackupNudge: Boolean = false,
    val lastBackupMillis: Long = 0L,
    val filters: FilterState = FilterState(),
    val importer: ImporterState = ImporterState()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MoneyViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val repository = MoneyRepository(appContext, ClearLedgerDatabase.getInstance(appContext))

    private val selectedMonthFlow = MutableStateFlow(DateMonthUtils.currentYearMonth())
    private val filterFlow = MutableStateFlow(FilterState())
    private val importerFlow = MutableStateFlow(ImporterState())
    private val pinUnlockedForAccountFlow = MutableStateFlow<Long?>(null)
    private val pinErrorFlow = MutableStateFlow<String?>(null)
    private val authErrorFlow = MutableStateFlow<String?>(null)

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 12)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    private val settingsFlow = repository.observeSettings()

    private val accountFlow = settingsFlow.flatMapLatest { settings ->
        if (settings.activeAccountId > 0L) repository.observeAccount(settings.activeAccountId)
        else flowOf(null)
    }

    private val allExpensesFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeAllExpenses(s.activeAccountId) else flowOf(emptyList())
    }
    private val splitsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeSplits(s.activeAccountId) else flowOf(emptyList())
    }
    private val walletsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeWallets(s.activeAccountId) else flowOf(emptyList())
    }
    private val transfersFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeTransfers(s.activeAccountId) else flowOf(emptyList())
    }
    private val autoAddRulesFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeAutoAddRules(s.activeAccountId) else flowOf(emptyList())
    }
    private val customCatsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeCustomCategories(s.activeAccountId) else flowOf(emptyList())
    }
    private val budgetsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeBudgets(s.activeAccountId) else flowOf(emptyList())
    }
    private val rulesFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeRules(s.activeAccountId) else flowOf(emptyList())
    }
    private val recurringFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeRecurring(s.activeAccountId) else flowOf(emptyList())
    }
    private val goalsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeGoals(s.activeAccountId) else flowOf(emptyList())
    }
    private val lendingFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeLending(s.activeAccountId) else flowOf(emptyList())
    }
    private val subsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeSubscriptions(s.activeAccountId) else flowOf(emptyList())
    }
    private val challengesFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeChallenges(s.activeAccountId) else flowOf(emptyList())
    }
    private val billsFlow = settingsFlow.flatMapLatest { s ->
        if (s.activeAccountId > 0L) repository.observeBills(s.activeAccountId) else flowOf(emptyList())
    }

    init {
        viewModelScope.launch {
            repository.refreshExchangeRates()
        }
        viewModelScope.launch {
            settingsFlow
                .map { it.activeAccountId }
                .distinctUntilChanged()
                .collect { accId ->
                    if (accId > 0L) {
                        val added = repository.syncDueAutoAddRules(accId)
                        if (added > 0) _snackbarMessages.tryEmit("Auto-added $added scheduled wallet entry(ies)")
                    }
                }
        }
    }

    private val authGroupFlow = combine(
        settingsFlow,
        accountFlow,
        repository.observeAllAccounts(),
        repository.observeExchangeRates(),
        selectedMonthFlow
    ) { settings, account, allAccounts, rates, ym ->
        AuthGroup(settings, account, allAccounts, rates, ym)
    }

    private val walletPlusExtrasFlow = combine(walletsFlow, transfersFlow, autoAddRulesFlow) { wallets, transfers, autoAdds ->
        Triple(wallets, transfers, autoAdds)
    }

    private val ledgerGroupFlow = combine(
        allExpensesFlow,
        splitsFlow,
        walletPlusExtrasFlow,
        customCatsFlow,
        budgetsFlow
    ) { expenses, splits, walletTriple, customCats, budgets ->
        LedgerGroup(expenses, splits, walletTriple.first, walletTriple.second, walletTriple.third, customCats, budgets)
    }

    private val planGroupFlow = combine(
        rulesFlow,
        recurringFlow,
        goalsFlow,
        lendingFlow,
        subsFlow
    ) { rules, recurring, goals, lending, subs ->
        PlanGroup(rules, recurring, goals, lending, subs)
    }

    private val extrasGroupFlow = combine(
        challengesFlow,
        billsFlow,
        filterFlow,
        importerFlow,
        combine(pinUnlockedForAccountFlow, pinErrorFlow, authErrorFlow) { unlocked, pErr, aErr ->
            Triple(unlocked, pErr, aErr)
        }
    ) { challenges, bills, filters, importer, secTriple ->
        ExtrasGroup(challenges, bills, filters, importer, secTriple.first, secTriple.second, secTriple.third)
    }

    val uiState: StateFlow<MoneyUiState> = combine(
        authGroupFlow,
        ledgerGroupFlow,
        planGroupFlow,
        extrasGroupFlow
    ) { auth, ledger, plan, extras ->
        buildUiState(auth, ledger, plan, extras)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = MoneyUiState()
    )

    private fun buildUiState(
        auth: AuthGroup,
        ledger: LedgerGroup,
        plan: PlanGroup,
        extras: ExtrasGroup
    ): MoneyUiState {
        val settings = auth.settings
        val account = auth.account
        val ym = auth.yearMonth
        val prevYm = DateMonthUtils.shiftYearMonth(ym, -1)

        val isPinLocked = account != null && !account.pinHash.isNullOrBlank() && extras.pinUnlockedAccountId != account.id

        val allTxns = ledger.allExpenses
        val monthTxns = allTxns.filter { it.yearMonth == ym }
        val prevMonthTxns = allTxns.filter { it.yearMonth == prevYm }

        val monthExpensesOnly = monthTxns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }
        val monthIncomeOnly = monthTxns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }
        val prevExpensesOnly = prevMonthTxns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }

        val totalSpent = monthExpensesOnly.sumOf { it.amountCents }
        val totalIncome = monthIncomeOnly.sumOf { it.amountCents }
        val netThisMonth = totalIncome - totalSpent
        val prevMonthSpent = prevExpensesOnly.sumOf { it.amountCents }
        val prevMonthIncome = prevMonthTxns
            .filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }
            .sumOf { it.amountCents }

        val savingsRatePercent = if (totalIncome > 0L) {
            ((netThisMonth.toDouble() / totalIncome.toDouble()) * 100.0).roundToInt()
        } else null
        val prevSavingsRatePercent = if (prevMonthIncome > 0L) {
            (((prevMonthIncome - prevMonthSpent).toDouble() / prevMonthIncome.toDouble()) * 100.0).roundToInt()
        } else null

        val todayKey = DateMonthUtils.todayKey()
        val todaySpent = allTxns
            .filter {
                TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE &&
                    DateMonthUtils.formatIsoDate(it.dateMillis) == todayKey
            }
            .sumOf { it.amountCents }

        val budgetEntityMap = ledger.budgets.associateBy { ExpenseCategory.fromRaw(it.category) }
        val expByCat = monthExpensesOnly.groupBy { ExpenseCategory.fromRaw(it.category) }
        val prevExpByCat = prevExpensesOnly.groupBy { ExpenseCategory.fromRaw(it.category) }

        val breakdowns = ExpenseCategory.expenseEntries.map { cat ->
            val entity = budgetEntityMap[cat]
            val baseLimit = entity?.limitCents ?: cat.defaultMonthlyLimitCents
            val rolloverEnabled = entity?.rolloverEnabled ?: false
            val prevSpent = prevExpByCat[cat].orEmpty().sumOf { it.amountCents }
            val rollover = if (rolloverEnabled) (baseLimit - prevSpent).coerceAtLeast(0L) else 0L
            val effectiveBudget = (baseLimit + rollover).coerceAtLeast(100L)
            val catTxns = expByCat[cat].orEmpty()
            val spent = catTxns.sumOf { it.amountCents }
            CategoryBreakdownItem(
                category = cat,
                spentCents = spent,
                lastMonthSpentCents = prevSpent,
                baseBudgetCents = baseLimit,
                rolloverCents = rollover,
                effectiveBudgetCents = effectiveBudget,
                rolloverEnabled = rolloverEnabled,
                shareFraction = if (totalSpent > 0L) spent.toFloat() / totalSpent.toFloat() else 0f,
                budgetUtilization = spent.toFloat() / effectiveBudget.toFloat(),
                transactionCount = catTxns.size
            )
        }.sortedWith(compareByDescending<CategoryBreakdownItem> { it.spentCents }.thenByDescending { it.effectiveBudgetCents })

        val totalBudget = breakdowns.sumOf { it.effectiveBudgetCents }.coerceAtLeast(100L)
        val remaining = totalBudget - totalSpent

        val daysInMonth = DateMonthUtils.daysInMonth(ym).coerceAtLeast(1)
        val currentYm = DateMonthUtils.currentYearMonth()
        val elapsedDays = when {
            ym == currentYm -> DateMonthUtils.dayOfMonthFromMillis(System.currentTimeMillis()).coerceIn(1, daysInMonth)
            ym < currentYm -> daysInMonth
            else -> 0
        }
        val safeDiv = elapsedDays.coerceAtLeast(1)
        val remainingDays = (daysInMonth - safeDiv + 1).coerceAtLeast(1)
        val safeToSpendToday = if (remaining > 0L) remaining / remainingDays else 0L
        val dailyAvg = if (elapsedDays > 0) totalSpent / elapsedDays else 0L
        val projected = if (ym == currentYm) dailyAvg * daysInMonth else totalSpent
        val dailyTarget = totalBudget / daysInMonth

        val budgetRatio = totalSpent.toFloat() / totalBudget.toFloat()
        val alertLevel = when {
            budgetRatio > 1.0f -> 2
            budgetRatio >= 0.8f -> 1
            else -> 0
        }
        val paceOverBudgetWarning = (ym == currentYm && totalSpent <= totalBudget && elapsedDays >= 5 && projected > totalBudget)

        val groupedDay = monthTxns.groupBy { DateMonthUtils.dayOfMonthFromMillis(it.dateMillis) }
        val dailyPoints = (1..daysInMonth).map { day ->
            val list = groupedDay[day].orEmpty()
            DailySpendPoint(
                dayOfMonth = day,
                spentCents = list.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }.sumOf { it.amountCents },
                incomeCents = list.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }.sumOf { it.amountCents },
                transactionCount = list.size
            )
        }

        val last6Months = (-5..0).map { offset ->
            val targetYm = DateMonthUtils.shiftYearMonth(ym, offset)
            val txns = allTxns.filter { it.yearMonth == targetYm }
            MonthlyCashflowPoint(
                yearMonth = targetYm,
                shortLabel = DateMonthUtils.formatMonthTitle(targetYm).take(3),
                incomeCents = txns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }.sumOf { it.amountCents },
                expenseCents = txns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }.sumOf { it.amountCents }
            )
        }

        val selectedYear = ym.substringBefore("-")
        val yearlyCashflow = (1..12).map { m ->
            val targetYm = "$selectedYear-${m.toString().padStart(2, '0')}"
            val txns = allTxns.filter { it.yearMonth == targetYm }
            MonthlyCashflowPoint(
                yearMonth = targetYm,
                shortLabel = DateMonthUtils.formatMonthTitle(targetYm).take(3),
                incomeCents = txns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }.sumOf { it.amountCents },
                expenseCents = txns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }.sumOf { it.amountCents }
            )
        }

        // Coming up next 30 days (Subscriptions + Unpaid Bills)
        val nowMillis = System.currentTimeMillis()
        val thirtyDaysLater = DateMonthUtils.addDays(nowMillis, 30)
        val comingUp = mutableListOf<ComingUpItem>()
        plan.subs.filter { it.isActive && it.nextRenewalMillis <= thirtyDaysLater }.forEach { sub ->
            val daysLeft = ((sub.nextRenewalMillis - nowMillis) / 86_400_000L).toInt().coerceAtLeast(0)
            comingUp += ComingUpItem(
                id = "sub_${sub.id}",
                title = sub.name,
                subtitle = "Subscription · ${DateMonthUtils.formatShortDate(sub.nextRenewalMillis)}",
                amountCents = sub.amountCents,
                dueMillis = sub.nextRenewalMillis,
                daysLeft = daysLeft,
                isBill = false
            )
        }
        extras.bills.filter { it.lastPaidYearMonth != currentYm }.forEach { bill ->
            val dueThisMonth = DateMonthUtils.millisForDayInMonth(currentYm, bill.dueDayOfMonth)
            val dueMillis = if (dueThisMonth + 86_400_000L < nowMillis) {
                DateMonthUtils.millisForDayInMonth(DateMonthUtils.shiftYearMonth(currentYm, 1), bill.dueDayOfMonth)
            } else dueThisMonth
            if (dueMillis <= thirtyDaysLater) {
                val daysLeft = ((dueMillis - nowMillis) / 86_400_000L).toInt().coerceAtLeast(0)
                comingUp += ComingUpItem(
                    id = "bill_${bill.id}",
                    title = bill.title,
                    subtitle = "${BillType.fromRaw(bill.billType).label} · Day ${bill.dueDayOfMonth}",
                    amountCents = bill.amountCents,
                    dueMillis = dueMillis,
                    daysLeft = daysLeft,
                    isBill = true
                )
            }
        }

        val walletAnalytics = ledger.wallets.map { w ->
            val wTxns = allTxns.filter { it.walletId == w.id }
            WalletAnalyticsItem(
                wallet = w,
                inflowCents = wTxns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }.sumOf { it.amountCents },
                outflowCents = wTxns.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }.sumOf { it.amountCents },
                txnCount = wTxns.size
            )
        }
        val totalWalletBalanceCents = ledger.wallets.sumOf { it.balanceCents }
        val negativeWallets = ledger.wallets.filter { it.balanceCents < 0L }
        val overdueLendingCount = plan.lending.count {
            !it.isSettled && it.dueDateMillis != null && it.dueDateMillis < nowMillis && it.paidCents < it.totalCents
        }

        // Quick-Fill Frequent Entries (entries seen >= 2 times)
        val quickFillSuggestions = allTxns
            .groupBy { "${it.transactionType}|${it.merchant.trim().lowercase()}|${it.amountCents}" }
            .values
            .filter { it.size >= 2 }
            .sortedByDescending { it.size }
            .take(6)
            .map { group -> QuickFillSuggestion(templateExpense = group.first(), count = group.size) }

        // Challenge Summaries (SAVE check-ins & NOSPEND automatic from zero-expense days)
        val expenseDates = allTxns
            .filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }
            .map { DateMonthUtils.formatIsoDate(it.dateMillis) }
            .toSet()
        val goalNamesById = plan.goals.associateBy({ it.id }, { it.name })
        val challengeSummaries = extras.challenges.map { ch ->
            val startKey = ch.startDateKey.ifBlank { todayKey }
            val dates = DateMonthUtils.daysInChallenge(startKey, ch.targetDays)
            val isNoSpend = ch.kind.equals("NOSPEND", ignoreCase = true)
            val checkedSet = ch.checkInDatesCsv
                .split(",")
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .toMutableSet()
                .apply {
                    if (isEmpty() && !ch.lastCheckInDayKey.isNullOrBlank()) add(ch.lastCheckInDayKey)
                }

            fun isDayDone(dateKey: String): Boolean =
                if (isNoSpend) !expenseDates.contains(dateKey) else checkedSet.contains(dateKey)

            val pastDates = dates.filter { it <= todayKey }
            val doneCount = pastDates.count { isDayDone(it) }
            var streakIdx = pastDates.lastIndex
            if (streakIdx >= 0 && pastDates[streakIdx] == todayKey && !isNoSpend && !isDayDone(todayKey)) {
                streakIdx--
            }
            var streak = 0
            while (streakIdx >= 0 && isDayDone(pastDates[streakIdx])) {
                streak++
                streakIdx--
            }
            var best = 0
            var run = 0
            pastDates.forEach { dk ->
                if (isDayDone(dk)) {
                    run++
                    if (run > best) best = run
                } else {
                    run = 0
                }
            }
            val todayIdx = dates.indexOf(todayKey)
            val lastDate = dates.lastOrNull() ?: todayKey
            val firstDate = dates.firstOrNull() ?: todayKey
            val dayNum = when {
                todayIdx >= 0 -> todayIdx + 1
                todayKey > lastDate -> ch.targetDays
                else -> 0
            }
            val cells = dates.mapIndexed { idx, dk ->
                val isFuture = dk > todayKey
                ChallengeDayCell(
                    dayNumber = idx + 1,
                    dateKey = dk,
                    isDone = !isFuture && isDayDone(dk),
                    isToday = dk == todayKey,
                    isFuture = isFuture
                )
            }
            ChallengeSummary(
                challenge = ch,
                completedCount = doneCount,
                streak = streak,
                bestStreak = best,
                savedCents = if (isNoSpend) 0L else doneCount * ch.dailySaveCents,
                dayNumber = dayNum,
                isEnded = todayKey > lastDate,
                notStarted = todayKey < firstDate,
                linkedGoalName = ch.goalId?.let { goalNamesById[it] },
                cells = cells
            )
        }

        // Ticker items (CapitalX v9.5 tape)
        val hideAmt = settings.hideAmounts
        val sym = settings.currencySymbol
        val tickerItems = buildList {
            add(
                TickerItem(
                    label = "BALANCE",
                    valueText = MoneyFormatters.formatMoney(totalWalletBalanceCents, sym, hidden = hideAmt),
                    trend = totalWalletBalanceCents.compareTo(0L)
                )
            )
            add(
                TickerItem(
                    label = "INCOME",
                    valueText = MoneyFormatters.formatMoney(totalIncome, sym, hidden = hideAmt),
                    trend = if (totalIncome > 0L) 1 else 0
                )
            )
            add(
                TickerItem(
                    label = "EXPENSES",
                    valueText = MoneyFormatters.formatMoney(totalSpent, sym, hidden = hideAmt),
                    trend = if (totalSpent > 0L) -1 else 0
                )
            )
            add(
                TickerItem(
                    label = "NET",
                    valueText = MoneyFormatters.formatMoney(netThisMonth, sym, includeSign = true, hidden = hideAmt),
                    trend = netThisMonth.compareTo(0L)
                )
            )
            add(
                TickerItem(
                    label = "SAVINGS RATE",
                    valueText = savingsRatePercent?.let { "$it%" } ?: "—",
                    trend = when {
                        savingsRatePercent == null -> 0
                        savingsRatePercent >= 0 -> 1
                        else -> -1
                    }
                )
            )
            if (totalBudget > 0L) {
                val pct = ((totalSpent.toDouble() / totalBudget.toDouble()) * 100.0).roundToInt()
                add(
                    TickerItem(
                        label = "BUDGET USED",
                        valueText = "$pct%",
                        trend = if (pct >= 80) -1 else 1
                    )
                )
            }
            plan.goals.take(3).forEach { g ->
                val gp = if (g.targetCents > 0L) ((g.savedCents.toDouble() / g.targetCents.toDouble()) * 100.0).roundToInt().coerceIn(0, 100) else 0
                add(TickerItem("GOAL ${g.name.uppercase().take(12)}", "$gp%", if (gp >= 100) 1 else 0))
            }
            val activeSubs = plan.subs.filter { it.isActive }
            if (activeSubs.isNotEmpty()) {
                val monthlySubs = activeSubs.sumOf { s ->
                    if (s.billingCycle.equals("YEARLY", ignoreCase = true)) s.amountCents / 12L else s.amountCents
                }
                add(TickerItem("SUBS / MO", MoneyFormatters.formatMoney(monthlySubs, sym, hidden = hideAmt), 0))
            }
        }

        // Monthly Money Insights (CapitalX v9.5)
        val spendDayCount = monthExpensesOnly
            .filter { DateMonthUtils.dayOfMonthFromMillis(it.dateMillis) <= safeDiv }
            .map { DateMonthUtils.formatIsoDate(it.dateMillis) }
            .distinct()
            .size
        val noSpendDays = (elapsedDays - spendDayCount).coerceAtLeast(0)
        val insightBullets = buildList {
            if (monthExpensesOnly.isNotEmpty() || monthIncomeOnly.isNotEmpty()) {
                if (prevMonthSpent > 0L && totalSpent > 0L) {
                    val ch = (((totalSpent - prevMonthSpent).toDouble() / prevMonthSpent.toDouble()) * 100.0).roundToInt()
                    val dir = if (ch >= 0) "more" else "less"
                    val emoji = if (ch >= 0) "📈" else "📉"
                    add("$emoji You spent ${abs(ch)}% $dir than last month (${MoneyFormatters.formatMoney(totalSpent, sym, hidden = hideAmt)} vs ${MoneyFormatters.formatMoney(prevMonthSpent, sym, hidden = hideAmt)}).")
                }
                if (prevMonthSpent > 0L) {
                    val deltas = breakdowns
                        .map { it.category to (it.spentCents - it.lastMonthSpentCents) }
                        .filter { it.second != 0L }
                        .sortedByDescending { it.second }
                    val biggestRise = deltas.firstOrNull { it.second > 0L }
                    if (biggestRise != null) {
                        add("🔺 Biggest rise: ${biggestRise.first.displayName} is up ${MoneyFormatters.formatMoney(biggestRise.second, sym, hidden = hideAmt)} vs last month.")
                    }
                    val biggestDrop = deltas.lastOrNull { it.second < 0L }
                    if (biggestDrop != null) {
                        add("🔻 Biggest drop: ${biggestDrop.first.displayName} is down ${MoneyFormatters.formatMoney(-biggestDrop.second, sym, hidden = hideAmt)} vs last month.")
                    }
                }
                val top3 = monthExpensesOnly.sortedByDescending { it.amountCents }.take(3)
                if (top3.isNotEmpty()) {
                    add("💸 Top expenses: ${top3.joinToString(", ") { "${it.merchant} ${MoneyFormatters.formatMoney(it.amountCents, sym, hidden = hideAmt)}" }}.")
                }
                if (monthExpensesOnly.size >= 3) {
                    val wdTotals = LongArray(7)
                    monthExpensesOnly.forEach { tx ->
                        wdTotals[DateMonthUtils.dayOfWeekIndex(tx.dateMillis)] += tx.amountCents
                    }
                    val bestWd = wdTotals.indices.maxByOrNull { wdTotals[it] } ?: 0
                    val wdNames = listOf("Sundays", "Mondays", "Tuesdays", "Wednesdays", "Thursdays", "Fridays", "Saturdays")
                    if (wdTotals[bestWd] > 0L) {
                        add("📅 You spend the most on ${wdNames[bestWd]} (${MoneyFormatters.formatMoney(wdTotals[bestWd], sym, hidden = hideAmt)}).")
                    }
                }
                if (savingsRatePercent != null) {
                    add(
                        when {
                            savingsRatePercent >= 20 -> "💚 Savings rate $savingsRatePercent%: strong, you kept over a fifth of your income."
                            savingsRatePercent >= 0 -> "🟡 Savings rate $savingsRatePercent%: aim for 20% or more."
                            else -> "🔴 You spent more than you earned this month (${MoneyFormatters.formatMoney(totalSpent - totalIncome, sym, hidden = hideAmt)} deficit)."
                        }
                    )
                } else if (monthExpensesOnly.isNotEmpty()) {
                    add("💡 No income recorded this month, so savings rate is pending.")
                }
                if (totalBudget > 0L) {
                    val u = ((totalSpent.toDouble() / totalBudget.toDouble()) * 100.0).roundToInt()
                    val pacePart = if (ym == currentYm) {
                        val daysLeft = (daysInMonth - elapsedDays).coerceAtLeast(0)
                        if (totalSpent >= totalBudget) {
                            " Over budget by ${MoneyFormatters.formatMoney(totalSpent - totalBudget, sym, hidden = hideAmt)}."
                        } else {
                            val projNote = if (projected > totalBudget) {
                                " Projected ${MoneyFormatters.formatMoney(projected, sym, hidden = hideAmt)} (${MoneyFormatters.formatMoney(projected - totalBudget, sym, hidden = hideAmt)} over)."
                            } else {
                                " Projected ${MoneyFormatters.formatMoney(projected, sym, hidden = hideAmt)}, on track."
                            }
                            val allowNote = if (daysLeft > 0) {
                                " Allowance: ${MoneyFormatters.formatMoney((totalBudget - totalSpent) / daysLeft, sym, hidden = hideAmt)}/day for remaining $daysLeft days."
                            } else ""
                            projNote + allowNote
                        }
                    } else ""
                    add("🎯 Budget: $u% used (${MoneyFormatters.formatMoney(totalSpent, sym, hidden = hideAmt)} of ${MoneyFormatters.formatMoney(totalBudget, sym, hidden = hideAmt)}).$pacePart")
                }
            }
        }
        val monthlyInsights = MonthlyInsightsSummary(
            avgSpendPerDayCents = dailyAvg,
            projectedOrTotalCents = projected,
            isCurrentMonth = ym == currentYm,
            savingsRatePercent = savingsRatePercent,
            savingsRateDeltaPts = if (savingsRatePercent != null && prevSavingsRatePercent != null) savingsRatePercent - prevSavingsRatePercent else null,
            noSpendDays = noSpendDays,
            elapsedDays = elapsedDays,
            bullets = insightBullets
        )

        val q = extras.filters.searchQuery.trim().lowercase()
        val filteredTxns = monthTxns.filter { e ->
            val matchQ = q.isEmpty() ||
                e.merchant.lowercase().contains(q) ||
                e.note.lowercase().contains(q) ||
                (e.customCategoryName?.lowercase()?.contains(q) == true) ||
                ExpenseCategory.fromRaw(e.category).displayName.lowercase().contains(q)
            val matchType = extras.filters.selectedType == null || TransactionType.fromRaw(e.transactionType) == extras.filters.selectedType
            val matchCat = extras.filters.selectedCategory == null || ExpenseCategory.fromRaw(e.category) == extras.filters.selectedCategory
            val matchMethod = extras.filters.selectedPaymentMethod == null || PaymentMethod.fromRaw(e.paymentMethod) == extras.filters.selectedPaymentMethod
            val matchWallet = extras.filters.selectedWalletId == null || e.walletId == extras.filters.selectedWalletId
            val matchSource = extras.filters.selectedSource == null || ExpenseSource.fromRaw(e.source) == extras.filters.selectedSource
            matchQ && matchType && matchCat && matchMethod && matchWallet && matchSource
        }

        val visibleWidgets = settings.visibleWidgetsCsv
            .split(",")
            .mapNotNull { key -> DashboardWidget.entries.firstOrNull { it.key == key.trim() } }
            .toSet()
            .ifEmpty { DashboardWidget.entries.toSet() }

        val sevenDaysMillis = 7L * 24L * 60L * 60L * 1000L
        val showBackupNudge = account != null && allTxns.isNotEmpty() &&
            (settings.lastBackupMillis == 0L || (nowMillis - settings.lastBackupMillis) > sevenDaysMillis)

        return MoneyUiState(
            activeAccount = account,
            knownUsernames = auth.allAccounts.map { it.username },
            isPinLocked = isPinLocked,
            pinError = extras.pinError,
            authError = extras.authError,
            selectedYearMonth = ym,
            monthTitle = DateMonthUtils.formatMonthTitle(ym),
            currencySymbol = settings.currencySymbol,
            currencyCode = settings.currencyCode,
            themeMode = ThemeMode.fromRaw(settings.themeMode),
            hideAmounts = settings.hideAmounts,
            notificationsEnabled = settings.notificationsEnabled,
            visibleWidgets = visibleWidgets,
            usdRates = ExchangeRateService.parseRatesJson(auth.ratesCache.ratesJson),
            ratesUpdatedAtMillis = auth.ratesCache.updatedAtMillis,
            allTransactions = allTxns,
            monthTransactions = monthTxns,
            filteredTransactions = filteredTxns,
            splitsByTransactionId = ledger.splits.groupBy { it.transactionId },
            wallets = ledger.wallets,
            transfers = ledger.transfers,
            autoAddSchedules = ledger.autoAddRules,
            walletAnalytics = walletAnalytics,
            totalWalletBalanceCents = totalWalletBalanceCents,
            negativeWallets = negativeWallets,
            customCategories = ledger.customCategories,
            totalIncomeCents = totalIncome,
            totalSpentCents = totalSpent,
            netThisMonthCents = netThisMonth,
            savingsRatePercent = savingsRatePercent,
            todaySpentCents = todaySpent,
            totalBudgetCents = totalBudget,
            remainingCents = remaining,
            safeToSpendTodayCents = safeToSpendToday,
            previousMonthSpentCents = prevMonthSpent,
            projectedMonthEndCents = projected,
            paceOverBudgetWarning = paceOverBudgetWarning,
            dailyTargetCents = dailyTarget,
            dailyAverageCents = dailyAvg,
            budgetAlertLevel = alertLevel,
            overdueLendingCount = overdueLendingCount,
            quickFillSuggestions = quickFillSuggestions,
            tickerItems = tickerItems,
            monthlyInsights = monthlyInsights,
            categoryBreakdowns = breakdowns,
            dailyPoints = dailyPoints,
            last6MonthsCashflow = last6Months,
            yearlyCashflow = yearlyCashflow,
            comingUp30Days = comingUp.sortedBy { it.dueMillis },
            autoRules = plan.rules,
            recurringExpenses = plan.recurring,
            goals = plan.goals,
            lendingRecords = plan.lending,
            subscriptions = plan.subs,
            repeatChargeSuggestions = SampleStatementParser.detectRepeatCharges(allTxns, plan.subs),
            challenges = extras.challenges,
            challengeSummaries = challengeSummaries,
            bills = extras.bills,
            showWeeklyBackupNudge = showBackupNudge,
            lastBackupMillis = settings.lastBackupMillis,
            filters = extras.filters,
            importer = extras.importer
        )
    }

    // ---------- ACCOUNTS & PIN LOCK ----------

    fun clearAuthError() { authErrorFlow.value = null }

    fun signUp(displayName: String, username: String, password: String) {
        viewModelScope.launch {
            val res = repository.signUpAccount(displayName, username, password)
            res.fold(
                onSuccess = { acc ->
                    authErrorFlow.value = null
                    pinUnlockedForAccountFlow.value = acc.id
                    _snackbarMessages.tryEmit("Welcome to Capitalx, ${acc.displayName}")
                },
                onFailure = { authErrorFlow.value = it.message ?: "Sign up failed" }
            )
        }
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val res = repository.loginAccount(username, password)
            res.fold(
                onSuccess = { acc ->
                    authErrorFlow.value = null
                    pinUnlockedForAccountFlow.value = if (acc.pinHash.isNullOrBlank()) acc.id else null
                    val posted = repository.syncRecurringForMonth(acc.id, DateMonthUtils.currentYearMonth(), true)
                    val autoAdded = repository.syncDueAutoAddRules(acc.id)
                    if (posted > 0 || autoAdded > 0) {
                        _snackbarMessages.tryEmit("Auto-posted $posted recurring & $autoAdded auto-add item(s)")
                    }
                },
                onFailure = { authErrorFlow.value = it.message ?: "Login failed" }
            )
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logoutAccount()
            pinUnlockedForAccountFlow.value = null
            pinErrorFlow.value = null
        }
    }

    fun forgotPasswordReset(username: String, newPassword: String) {
        viewModelScope.launch {
            val res = repository.forgotPasswordResetAndWipe(username, newPassword)
            res.fold(
                onSuccess = { acc ->
                    authErrorFlow.value = null
                    pinUnlockedForAccountFlow.value = acc.id
                    _snackbarMessages.tryEmit("Password reset and account data cleared")
                },
                onFailure = { authErrorFlow.value = it.message ?: "Reset failed" }
            )
        }
    }

    fun changeAccountPassword(currentPassword: String, newPassword: String, onDone: (Result<Unit>) -> Unit = {}) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val res = repository.changeAccountPassword(accId, currentPassword, newPassword)
            if (res.isSuccess) _snackbarMessages.tryEmit("Account password updated")
            onDone(res)
        }
    }

    fun verifyPasswordAndResetPin(password: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val res = repository.verifyPasswordAndResetPin(accId, password)
            res.fold(
                onSuccess = {
                    pinErrorFlow.value = null
                    pinUnlockedForAccountFlow.value = accId
                    _snackbarMessages.tryEmit("PIN cleared. You can set a new PIN anytime in Settings.")
                },
                onFailure = { pinErrorFlow.value = it.message ?: "Incorrect password" }
            )
        }
    }

    fun verifyPin(pin: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val res = repository.verifyAppPin(accId, pin)
            res.fold(
                onSuccess = {
                    pinErrorFlow.value = null
                    pinUnlockedForAccountFlow.value = accId
                },
                onFailure = { pinErrorFlow.value = it.message }
            )
        }
    }

    fun lockAppNow() {
        if (!uiState.value.activeAccount?.pinHash.isNullOrBlank()) {
            pinUnlockedForAccountFlow.value = null
        }
    }

    fun setPin(pin: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.setAppPin(accId, pin)
            pinUnlockedForAccountFlow.value = accId
            _snackbarMessages.tryEmit("App PIN lock enabled (${pin.length} digits)")
        }
    }

    fun disablePin() {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.disableAppPin(accId)
            _snackbarMessages.tryEmit("App PIN lock removed")
        }
    }

    // ---------- NAVIGATION & FILTERS ----------

    fun shiftMonth(delta: Int) {
        selectedMonthFlow.value = DateMonthUtils.shiftYearMonth(selectedMonthFlow.value, delta)
    }

    fun jumpToCurrentMonth() {
        selectedMonthFlow.value = DateMonthUtils.currentYearMonth()
    }

    fun updateSearchQuery(query: String) {
        filterFlow.value = filterFlow.value.copy(searchQuery = query)
    }

    fun toggleTypeFilter(type: TransactionType?) {
        val cur = filterFlow.value.selectedType
        filterFlow.value = filterFlow.value.copy(selectedType = if (cur == type) null else type)
    }

    fun toggleCategoryFilter(category: ExpenseCategory?) {
        val cur = filterFlow.value.selectedCategory
        filterFlow.value = filterFlow.value.copy(selectedCategory = if (cur == category) null else category)
    }

    fun togglePaymentMethodFilter(method: PaymentMethod?) {
        val cur = filterFlow.value.selectedPaymentMethod
        filterFlow.value = filterFlow.value.copy(selectedPaymentMethod = if (cur == method) null else method)
    }

    fun toggleWalletFilter(walletId: Long?) {
        val cur = filterFlow.value.selectedWalletId
        filterFlow.value = filterFlow.value.copy(selectedWalletId = if (cur == walletId) null else walletId)
    }

    // ---------- TRANSACTIONS, SMS FILL & SPLITS ----------

    fun previewAutoCategory(merchant: String): Pair<ExpenseCategory, String?> =
        SampleStatementParser.classifyMerchant(merchant, uiState.value.autoRules)

    fun parseSmsForForm(smsText: String): ParsedSmsPreview? =
        SampleStatementParser.parseSingleBankOrUpiSms(smsText, uiState.value.currencyCode, uiState.value.autoRules)

    suspend fun savePickedReceipt(uri: Uri): String? = repository.copyReceiptToInternalStorage(uri)

    fun addTransaction(
        merchant: String,
        originalAmountCents: Long,
        originalCurrencyCode: String,
        transactionType: TransactionType,
        selectedCategory: ExpenseCategory?,
        customCategoryName: String?,
        dateMillis: Long,
        paymentMethod: PaymentMethod,
        walletId: Long,
        note: String,
        receiptUri: String?,
        splits: List<SplitInput>,
        repeatMonthly: Boolean,
        goalId: Long? = null
    ) {
        val accId = uiState.value.activeAccount?.id ?: return
        val baseCode = uiState.value.currencyCode
        val baseCents = ExchangeRateService.convertCents(
            originalAmountCents,
            originalCurrencyCode,
            baseCode,
            uiState.value.usdRates
        )
        viewModelScope.launch {
            val res = repository.addTransaction(
                accountId = accId,
                merchant = merchant,
                baseAmountCents = baseCents,
                originalAmountCents = originalAmountCents,
                originalCurrencyCode = originalCurrencyCode,
                transactionType = transactionType,
                selectedCategory = selectedCategory,
                customCategoryName = customCategoryName,
                dateMillis = dateMillis,
                paymentMethod = paymentMethod,
                walletId = walletId,
                note = note,
                receiptUri = receiptUri,
                splits = splits,
                repeatMonthly = repeatMonthly,
                goalId = goalId
            )
            res.fold(
                onSuccess = { cat ->
                    _snackbarMessages.tryEmit("Saved ${transactionType.label} in ${customCategoryName ?: cat.displayName}")
                    maybeNotifyBudgetAlert()
                },
                onFailure = { _snackbarMessages.tryEmit(it.message ?: "Could not save transaction") }
            )
        }
    }

    fun updateTransaction(oldExpense: ExpenseEntity, updated: ExpenseEntity) {
        viewModelScope.launch {
            val res = repository.updateTransaction(oldExpense, updated)
            res.fold(
                onSuccess = { _snackbarMessages.tryEmit("Transaction updated") },
                onFailure = { _snackbarMessages.tryEmit(it.message ?: "Update failed") }
            )
        }
    }

    fun duplicateTransaction(expense: ExpenseEntity) {
        viewModelScope.launch {
            val droppedGoal = repository.duplicateTransactionForToday(expense)
            _snackbarMessages.tryEmit(
                if (droppedGoal) "Duplicated for today (unlinked goal due to balance)" else "Duplicated for today"
            )
            maybeNotifyBudgetAlert()
        }
    }

    fun deleteTransaction(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(expense)
            _snackbarMessages.tryEmit("Transaction deleted")
        }
    }

    fun toggleSettleSplit(split: SplitEntryEntity) {
        viewModelScope.launch {
            repository.settleSplit(split)
            _snackbarMessages.tryEmit(
                if (!split.isSettled) "${split.friendName} marked settled" else "${split.friendName} marked pending"
            )
        }
    }

    fun addCustomCategory(name: String, type: TransactionType) {
        val accId = uiState.value.activeAccount?.id ?: return
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.addCustomCategory(accId, name, type)
            _snackbarMessages.tryEmit("Category \"$name\" added")
        }
    }

    // ---------- WALLETS, TRANSFERS, AUTO-ADD, BUDGETS, RULES, RECURRING ----------

    fun addWallet(name: String, type: WalletType, initialBalanceCents: Long) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addWallet(accId, name, type, initialBalanceCents)
            _snackbarMessages.tryEmit("Wallet \"$name\" created")
        }
    }

    fun addMoneyToWallet(walletId: Long, amountCents: Long, logAsIncome: Boolean) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addMoneyToWallet(accId, walletId, amountCents, logAsIncome)
            _snackbarMessages.tryEmit("Wallet balance updated")
        }
    }

    fun setWalletRealBalance(walletId: Long, actualBalanceCents: Long) {
        viewModelScope.launch {
            repository.setWalletRealBalance(walletId, actualBalanceCents)
            _snackbarMessages.tryEmit("Real wallet balance calibrated")
        }
    }

    fun transferBetweenWallets(fromWalletId: Long, toWalletId: Long, amountCents: Long, dateMillis: Long, note: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val res = repository.transferBetweenWallets(accId, fromWalletId, toWalletId, amountCents, dateMillis, note)
            res.fold(
                onSuccess = { _snackbarMessages.tryEmit("Wallet transfer completed") },
                onFailure = { _snackbarMessages.tryEmit(it.message ?: "Transfer failed") }
            )
        }
    }

    fun deleteTransfer(transfer: WalletTransferEntity) {
        viewModelScope.launch {
            repository.deleteTransfer(transfer)
            _snackbarMessages.tryEmit("Transfer deleted and balances restored")
        }
    }

    fun addAutoAddSchedule(walletId: Long, amountCents: Long, frequency: String, startDateKey: String, note: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val added = repository.addAutoAddRule(accId, walletId, amountCents, frequency, startDateKey, note)
            _snackbarMessages.tryEmit(if (added > 0) "Auto-add started ($added entry added)" else "Auto-add schedule saved")
        }
    }

    fun toggleAutoAddSchedule(rule: AutoAddRuleEntity) {
        viewModelScope.launch {
            val added = repository.toggleAutoAddRule(rule, skipMissedDays = true)
            _snackbarMessages.tryEmit(
                if (!rule.isActive) {
                    if (added > 0) "Auto-add resumed ($added added)" else "Auto-add resumed"
                } else "Auto-add paused"
            )
        }
    }

    fun deleteAutoAddSchedule(id: Long) {
        viewModelScope.launch {
            repository.deleteAutoAddRule(id)
            _snackbarMessages.tryEmit("Auto-add schedule removed")
        }
    }

    fun updateCategoryBudget(category: ExpenseCategory, limitCents: Long, rolloverEnabled: Boolean) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.updateCategoryBudget(accId, category, limitCents, rolloverEnabled)
            _snackbarMessages.tryEmit("${category.shortName} budget saved")
        }
    }

    fun addAutoRule(keyword: String, category: ExpenseCategory, targetWalletId: Long?) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addAutoRule(accId, keyword, category, targetWalletId)
            _snackbarMessages.tryEmit("Auto-rule \"$keyword\" saved")
        }
    }

    fun toggleAutoRule(id: Long, enabled: Boolean) {
        viewModelScope.launch { repository.setRuleEnabled(id, enabled) }
    }

    fun deleteAutoRule(id: Long) {
        viewModelScope.launch { repository.deleteAutoRule(id) }
    }

    fun reRunAutoRules() {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val count = repository.applyRulesToOtherExpenses(accId)
            _snackbarMessages.tryEmit(if (count > 0) "Auto-categorized $count transactions" else "No uncategorized matches")
        }
    }

    fun addRecurringExpense(merchant: String, amountCents: Long, category: ExpenseCategory, dayOfMonth: Int, walletId: Long, note: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addRecurringExpense(accId, merchant, amountCents, category, dayOfMonth, walletId, note)
            _snackbarMessages.tryEmit("Recurring rule scheduled")
        }
    }

    fun toggleRecurring(id: Long, active: Boolean) {
        viewModelScope.launch { repository.setRecurringActive(id, active) }
    }

    fun deleteRecurring(id: Long) {
        viewModelScope.launch { repository.deleteRecurring(id) }
    }

    fun syncRecurringNow() {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val count = repository.syncRecurringForMonth(accId, selectedMonthFlow.value, false)
            _snackbarMessages.tryEmit(if (count > 0) "Posted $count recurring entries" else "All recurring items up to date")
        }
    }

    // ---------- GOALS, LENDING, SUBSCRIPTIONS, CHALLENGES, BILLS ----------

    fun addGoal(name: String, targetCents: Long, targetDateMillis: Long?) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addGoal(accId, name, targetCents, targetDateMillis)
            _snackbarMessages.tryEmit("Goal \"$name\" added")
        }
    }

    fun contributeToGoal(goalId: Long, deltaCents: Long, walletId: Long?) {
        viewModelScope.launch {
            repository.contributeToGoal(goalId, deltaCents, walletId)
            _snackbarMessages.tryEmit("Contribution added to goal")
        }
    }

    fun deleteGoal(id: Long) { viewModelScope.launch { repository.deleteGoal(id) } }

    fun addLending(person: String, dir: LendingDirection, amountCents: Long, dueMillis: Long?, note: String) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addLending(accId, person, dir, amountCents, dueMillis, note)
            _snackbarMessages.tryEmit("Lending record added")
        }
    }

    fun settleLending(item: LendingEntity, paymentCents: Long) {
        viewModelScope.launch {
            repository.settleOrPayLending(item, paymentCents)
            _snackbarMessages.tryEmit("Lending balance updated")
        }
    }

    fun deleteLending(id: Long) { viewModelScope.launch { repository.deleteLending(id) } }

    fun addSubscription(name: String, amountCents: Long, cycle: String, category: ExpenseCategory, nextRenewalMillis: Long, reminder: Boolean) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addSubscription(accId, name, amountCents, cycle, category, nextRenewalMillis, reminder)
            _snackbarMessages.tryEmit("Subscription \"$name\" added")
        }
    }

    fun acceptRepeatChargeSuggestion(s: RepeatChargeSuggestion) {
        addSubscription(
            name = s.merchant,
            amountCents = s.averageAmountCents,
            cycle = "MONTHLY",
            category = s.category,
            nextRenewalMillis = DateMonthUtils.addMonths(System.currentTimeMillis(), 1),
            reminder = true
        )
    }

    fun advanceSubscription(sub: SubscriptionEntity) {
        viewModelScope.launch {
            repository.advanceSubscriptionRenewal(sub)
            _snackbarMessages.tryEmit("Next renewal updated")
        }
    }

    fun toggleSubscriptionReminder(sub: SubscriptionEntity) {
        viewModelScope.launch { repository.toggleSubscriptionReminder(sub) }
    }

    fun deleteSubscription(id: Long) { viewModelScope.launch { repository.deleteSubscription(id) } }

    fun addChallenge(
        title: String,
        kind: String,
        targetDays: Int,
        dailySaveCents: Long,
        startDateKey: String = DateMonthUtils.todayKey(),
        goalId: Long? = null
    ) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addChallenge(accId, title, kind, targetDays, dailySaveCents, startDateKey, goalId)
            _snackbarMessages.tryEmit("Challenge started!")
        }
    }

    fun toggleChallengeDay(challenge: ChallengeEntity, dateKey: String = DateMonthUtils.todayKey()) {
        viewModelScope.launch {
            val res = repository.toggleChallengeDay(challenge, dateKey)
            res.fold(
                onSuccess = { checkedIn ->
                    _snackbarMessages.tryEmit(if (checkedIn) "Day marked complete!" else "Check-in undone")
                },
                onFailure = { _snackbarMessages.tryEmit(it.message ?: "Unable to update challenge") }
            )
        }
    }

    fun checkInChallenge(challenge: ChallengeEntity) = toggleChallengeDay(challenge, DateMonthUtils.todayKey())

    fun deleteChallenge(id: Long) { viewModelScope.launch { repository.deleteChallenge(id) } }

    fun addBill(title: String, billType: BillType, amountCents: Long, dueDay: Int, category: ExpenseCategory) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.addBill(accId, title, billType, amountCents, dueDay, category)
            _snackbarMessages.tryEmit("Bill added to calendar")
        }
    }

    fun markBillPaid(bill: BillItemEntity, walletId: Long) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            repository.markBillPaid(accId, bill, selectedMonthFlow.value, walletId)
            _snackbarMessages.tryEmit("${bill.title} marked paid")
        }
    }

    fun deleteBill(id: Long) { viewModelScope.launch { repository.deleteBill(id) } }

    // ---------- SAMPLE / BATCH IMPORTER ----------

    fun updateImporterText(text: String) {
        importerFlow.value = importerFlow.value.copy(rawText = text)
    }

    fun loadEditableFormatTemplate() {
        val ym = selectedMonthFlow.value
        val template = buildString {
            appendLine("Date,Merchant,Amount,Note")
            appendLine("$ym-02,Trader Joe's,68.40,Weekly groceries")
            appendLine("$ym-05,Starbucks Reserve,6.85,Morning coffee")
            appendLine("Debited $24.50 at Uber Trip via UPI on $ym-08")
            appendLine("Credited $1200.00 at Tech Payroll on $ym-10")
            append("Your card was charged $15.99 at Netflix on $ym-12")
        }
        val drafts = SampleStatementParser.parseSampleText(template, ym, uiState.value.autoRules, uiState.value.currencyCode)
        importerFlow.value = ImporterState(rawText = template, drafts = drafts)
    }

    fun parseImporterText() {
        val raw = importerFlow.value.rawText
        val ym = selectedMonthFlow.value
        val drafts = SampleStatementParser.parseSampleText(raw, ym, uiState.value.autoRules, uiState.value.currencyCode)
        importerFlow.value = importerFlow.value.copy(drafts = drafts)
        if (drafts.isEmpty() && raw.isNotBlank()) {
            _snackbarMessages.tryEmit("No transactions detected. Try: Merchant 12.50 or Date,Merchant,Amount")
        }
    }

    fun toggleDraftSelected(draftId: Int) {
        importerFlow.value = importerFlow.value.copy(
            drafts = importerFlow.value.drafts.map { if (it.id == draftId) it.copy(isSelected = !it.isSelected) else it }
        )
    }

    fun updateDraftCategory(draftId: Int, cat: ExpenseCategory) {
        importerFlow.value = importerFlow.value.copy(
            drafts = importerFlow.value.drafts.map { if (it.id == draftId) it.copy(category = cat) else it }
        )
    }

    fun commitImportedDrafts() {
        val accId = uiState.value.activeAccount?.id ?: return
        val defaultWallet = uiState.value.wallets.firstOrNull()?.id ?: 0L
        viewModelScope.launch {
            val count = repository.importDrafts(
                accountId = accId,
                drafts = importerFlow.value.drafts,
                baseCurrencyCode = uiState.value.currencyCode,
                usdRates = uiState.value.usdRates,
                defaultWalletId = defaultWallet
            )
            if (count > 0) {
                importerFlow.value = ImporterState()
                _snackbarMessages.tryEmit("Imported $count transaction(s)")
                maybeNotifyBudgetAlert()
            }
        }
    }

    fun clearImporter() { importerFlow.value = ImporterState() }

    // ---------- SETTINGS, RATES, BACKUP & NOTIFICATIONS ----------

    fun toggleHideAmounts() {
        viewModelScope.launch {
            repository.updateSettings { it.copy(hideAmounts = !it.hideAmounts) }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(themeMode = mode.name) }
        }
    }

    fun toggleDashboardWidget(widget: DashboardWidget) {
        val current = uiState.value.visibleWidgets.toMutableSet()
        if (current.contains(widget)) {
            if (current.size > 1) current.remove(widget)
        } else {
            current.add(widget)
        }
        val csv = current.joinToString(",") { it.key }
        viewModelScope.launch {
            repository.updateSettings { it.copy(visibleWidgetsCsv = csv) }
        }
    }

    fun updateBaseCurrency(code: String) {
        viewModelScope.launch {
            repository.updateBaseCurrency(code)
            _snackbarMessages.tryEmit("Base currency set to $code")
        }
    }

    fun refreshExchangeRates() {
        viewModelScope.launch {
            val res = repository.refreshExchangeRates()
            _snackbarMessages.tryEmit(
                if (res.isSuccess) "Live exchange rates updated" else "Offline: using cached exchange rates"
            )
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(notificationsEnabled = enabled) }
            if (enabled) {
                sendUpcomingRemindersNotification()
            }
        }
    }

    fun sendUpcomingRemindersNotification() {
        val coming = uiState.value.comingUp30Days
        val msg = if (coming.isEmpty()) {
            "Notifications active. Capitalx will alert you on 80%/100% budgets and renewals."
        } else {
            "${coming.size} upcoming renewal/bill(s) in the next 30 days. Next: ${coming.first().title}."
        }
        ReportExporter.sendNotificationReminder(appContext, "Capitalx Reminders", msg, 1001)
    }

    private fun maybeNotifyBudgetAlert() {
        val st = uiState.value
        if (!st.notificationsEnabled) return
        when (st.budgetAlertLevel) {
            2 -> ReportExporter.sendNotificationReminder(
                appContext,
                "Budget Alert: Over 100%",
                "You have exceeded your monthly budget for ${st.monthTitle}.",
                1002
            )
            1 -> ReportExporter.sendNotificationReminder(
                appContext,
                "Budget Alert: 80% Used",
                "You have used over 80% of your ${st.monthTitle} budget.",
                1002
            )
        }
    }

    suspend fun exportBackupPayload(password: String?): String? {
        val accId = uiState.value.activeAccount?.id ?: return null
        val json = repository.exportAccountBackupJson(accId)
        return if (!password.isNullOrBlank()) CryptoAndAuth.encryptBackup(json, password) else json
    }

    fun restoreBackupPayload(rawPayload: String, password: String?) {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            try {
                val json = if (CryptoAndAuth.isEncryptedBackup(rawPayload)) {
                    require(!password.isNullOrBlank()) { "Enter the backup password to decrypt." }
                    CryptoAndAuth.decryptBackup(rawPayload, password)
                } else {
                    rawPayload
                }
                val res = repository.restoreAccountBackupJson(accId, json)
                res.fold(
                    onSuccess = { count -> _snackbarMessages.tryEmit("Restored backup ($count transactions)") },
                    onFailure = { _snackbarMessages.tryEmit("Restore failed: ${it.message}") }
                )
            } catch (e: Exception) {
                _snackbarMessages.tryEmit("Decryption failed: ${e.message}")
            }
        }
    }

    fun restoreAutoRecovery() {
        val accId = uiState.value.activeAccount?.id ?: return
        viewModelScope.launch {
            val res = repository.restoreFromAutoRecovery(accId)
            res.fold(
                onSuccess = { count -> _snackbarMessages.tryEmit("Recovered $count transactions from local snapshot") },
                onFailure = { _snackbarMessages.tryEmit(it.message ?: "No recovery copy available") }
            )
        }
    }

    fun notifyMessage(msg: String) {
        _snackbarMessages.tryEmit(msg)
    }

    private data class AuthGroup(
        val settings: AppSettingsEntity,
        val account: LocalAccountEntity?,
        val allAccounts: List<LocalAccountEntity>,
        val ratesCache: ExchangeRateCacheEntity,
        val yearMonth: String
    )

    private data class LedgerGroup(
        val allExpenses: List<ExpenseEntity>,
        val splits: List<SplitEntryEntity>,
        val wallets: List<WalletEntity>,
        val transfers: List<WalletTransferEntity>,
        val autoAddRules: List<AutoAddRuleEntity>,
        val customCategories: List<CustomCategoryEntity>,
        val budgets: List<CategoryBudgetEntity>
    )

    private data class PlanGroup(
        val rules: List<AutoRuleEntity>,
        val recurring: List<RecurringExpenseEntity>,
        val goals: List<GoalEntity>,
        val lending: List<LendingEntity>,
        val subs: List<SubscriptionEntity>
    )

    private data class ExtrasGroup(
        val challenges: List<ChallengeEntity>,
        val bills: List<BillItemEntity>,
        val filters: FilterState,
        val importer: ImporterState,
        val pinUnlockedAccountId: Long?,
        val pinError: String?,
        val authError: String?
    )
}
