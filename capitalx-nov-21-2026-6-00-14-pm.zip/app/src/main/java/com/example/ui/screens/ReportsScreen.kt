package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.data.export.ReportExporter
import com.example.data.model.ExpenseCategory
import com.example.data.model.TransactionType
import com.example.data.parser.DateMonthUtils
import com.example.ui.components.CategoryDonutChartCard
import com.example.ui.components.IncomeVsExpenseChartCard
import com.example.ui.state.CategoryBreakdownItem
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.MoneyUiState
import com.example.ui.theme.MonoNumericTextStyle

private enum class ReportRange(val label: String) {
    MONTHLY("Monthly"),
    SIX_MONTHS("Last 6M"),
    YEARLY("Yearly")
}

@Composable
fun ReportsScreen(
    state: MoneyUiState,
    onMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var range by remember { mutableStateOf(ReportRange.MONTHLY) }
    val context = LocalContext.current

    val selectedYear = state.selectedYearMonth.substringBefore("-")
    val sixMonthKeys = remember(state.last6MonthsCashflow) {
        state.last6MonthsCashflow.map { it.yearMonth }.toSet()
    }

    val scopedTransactions = remember(state.allTransactions, range, state.selectedYearMonth, sixMonthKeys) {
        when (range) {
            ReportRange.MONTHLY -> state.monthTransactions
            ReportRange.SIX_MONTHS -> state.allTransactions.filter { sixMonthKeys.contains(it.yearMonth) }
            ReportRange.YEARLY -> state.allTransactions.filter { it.yearMonth.startsWith(selectedYear) }
        }
    }

    val periodLabel = when (range) {
        ReportRange.MONTHLY -> state.monthTitle
        ReportRange.SIX_MONTHS -> "Last 6 Months"
        ReportRange.YEARLY -> "Year $selectedYear"
    }

    val incomeCents = scopedTransactions
        .filter { TransactionType.fromRaw(it.transactionType) == TransactionType.INCOME }
        .sumOf { it.amountCents }
    val expenseCents = scopedTransactions
        .filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }
        .sumOf { it.amountCents }

    val categoryLines = remember(scopedTransactions, expenseCents) {
        val expOnly = scopedTransactions.filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }
        val grouped = expOnly.groupBy { ExpenseCategory.fromRaw(it.category) }
        ExpenseCategory.expenseEntries.map { cat ->
            val list = grouped[cat].orEmpty()
            val spent = list.sumOf { it.amountCents }
            CategoryBreakdownItem(
                category = cat,
                spentCents = spent,
                lastMonthSpentCents = 0L,
                baseBudgetCents = cat.defaultMonthlyLimitCents,
                rolloverCents = 0L,
                effectiveBudgetCents = cat.defaultMonthlyLimitCents,
                rolloverEnabled = false,
                shareFraction = if (expenseCents > 0L) spent.toFloat() / expenseCents.toFloat() else 0f,
                budgetUtilization = 0f,
                transactionCount = list.size
            )
        }.filter { it.spentCents > 0L }.sortedByDescending { it.spentCents }
    }

    val csvSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) {
            try {
                val csv = ReportExporter.buildCsv(scopedTransactions, state.currencyCode)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(csv) }
                onMessage("CSV report exported (${scopedTransactions.size} rows)")
            } catch (e: Exception) {
                onMessage("Export failed: ${e.message}")
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("reports_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text("Financial Reports", style = MaterialTheme.typography.headlineSmall)
                Text("Analyze performance, export CSV, or print / save PDF", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                ReportRange.entries.forEachIndexed { idx, r ->
                    SegmentedButton(
                        selected = range == r,
                        onClick = { range = r },
                        shape = SegmentedButtonDefaults.itemShape(idx, ReportRange.entries.size)
                    ) { Text(r.label) }
                }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(periodLabel, style = MaterialTheme.typography.titleMedium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Income", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                MoneyFormatters.formatMoney(incomeCents, state.currencySymbol, hidden = state.hideAmounts),
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(16f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Expenses", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                MoneyFormatters.formatMoney(expenseCents, state.currencySymbol, hidden = state.hideAmounts),
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(16f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Net", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val net = incomeCents - expenseCents
                            Text(
                                MoneyFormatters.formatMoney(net, state.currencySymbol, includeSign = true, hidden = state.hideAmounts),
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(16f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                color = if (net >= 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = {
                                csvSaver.launch("capitalx_${range.name.lowercase()}_${DateMonthUtils.todayKey()}.csv")
                            },
                            modifier = Modifier.weight(1f).height(48.dp).testTag("export_csv_button")
                        ) {
                            Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export CSV")
                        }
                        Button(
                            onClick = {
                                ReportExporter.printOrSavePdfReport(
                                    context = context,
                                    reportTitle = "${range.label} Report",
                                    periodLabel = periodLabel,
                                    totalIncomeCents = incomeCents,
                                    totalExpenseCents = expenseCents,
                                    currencySymbol = state.currencySymbol,
                                    categoryLines = categoryLines.map { it.category.displayName to it.spentCents },
                                    transactions = scopedTransactions
                                )
                            },
                            modifier = Modifier.weight(1f).height(48.dp).testTag("print_pdf_button")
                        ) {
                            Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Print / PDF")
                        }
                    }
                }
            }
        }

        item {
            MonthlyInsightsCard(state = state)
        }

        item {
            IncomeVsExpenseChartCard(
                title = if (range == ReportRange.YEARLY) "Yearly Cashflow ($selectedYear)" else "6-Month Cashflow",
                points = if (range == ReportRange.YEARLY) state.yearlyCashflow else state.last6MonthsCashflow,
                currencySymbol = state.currencySymbol,
                hideAmounts = state.hideAmounts
            )
        }

        item {
            CategoryDonutChartCard(
                breakdowns = categoryLines,
                totalSpentCents = expenseCents,
                currencySymbol = state.currencySymbol,
                hideAmounts = state.hideAmounts
            )
        }
    }
}

@Composable
private fun MonthlyInsightsCard(state: MoneyUiState) {
    val ins = state.monthlyInsights
    Surface(
        modifier = Modifier.fillMaxWidth().testTag("monthly_insights_card"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column {
                Text("Monthly Money Insights", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Auto-analyzed from ${state.monthTitle}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InsightKpiCell(
                    label = "Avg spend / day",
                    value = MoneyFormatters.formatMoney(ins.avgSpendPerDayCents, state.currencySymbol, hidden = state.hideAmounts),
                    sub = "${ins.elapsedDays} elapsed days",
                    modifier = Modifier.weight(1f)
                )
                InsightKpiCell(
                    label = if (ins.isCurrentMonth) "Projected spend" else "Total spend",
                    value = MoneyFormatters.formatMoney(ins.projectedOrTotalCents, state.currencySymbol, hidden = state.hideAmounts),
                    sub = if (state.totalBudgetCents > 0L) "Cap ${MoneyFormatters.formatCompact(state.totalBudgetCents, state.currencySymbol, state.hideAmounts)}" else "No cap set",
                    modifier = Modifier.weight(1f)
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val srText = ins.savingsRatePercent?.let { "$it%" } ?: "—"
                val deltaText = ins.savingsRateDeltaPts?.let { pts ->
                    if (pts >= 0) "+$pts pts vs last mo" else "$pts pts vs last mo"
                } ?: "Net / Income"
                InsightKpiCell(
                    label = "Savings rate",
                    value = srText,
                    sub = deltaText,
                    modifier = Modifier.weight(1f)
                )
                InsightKpiCell(
                    label = "No-spend days",
                    value = "${ins.noSpendDays} of ${ins.elapsedDays}",
                    sub = "Zero-expense days",
                    modifier = Modifier.weight(1f)
                )
            }

            if (ins.bullets.isEmpty()) {
                Text(
                    text = "Add expenses or income in ${state.monthTitle} to unlock behavioral spending insights.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ins.bullets.forEach { bullet ->
                        Text(
                            text = bullet,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightKpiCell(
    label: String,
    value: String,
    sub: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                text = value,
                style = MonoNumericTextStyle.copy(fontSize = TextUnit(15f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
