package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.CustomCategoryEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.GoalEntity
import com.example.data.local.SplitEntryEntity
import com.example.data.local.WalletEntity
import com.example.data.model.DashboardWidget
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.SupportedCurrencies
import com.example.data.model.TransactionType
import com.example.data.model.currencySymbolFor
import com.example.data.network.ExchangeRateService
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.ParsedSmsPreview
import com.example.data.parser.SampleStatementParser
import com.example.data.repository.SplitInput
import com.example.ui.state.MoneyFormatters
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditExpenseSheet(
    baseCurrencyCode: String,
    usdRates: Map<String, Double>,
    selectedYearMonth: String,
    wallets: List<WalletEntity>,
    customCategories: List<CustomCategoryEntity>,
    goals: List<GoalEntity> = emptyList(),
    prefillTemplate: ExpenseEntity? = null,
    existingExpense: ExpenseEntity?,
    existingSplits: List<SplitEntryEntity>,
    previewAutoCategory: (String) -> Pair<ExpenseCategory, String?>,
    onParseSms: (String) -> ParsedSmsPreview?,
    onSaveReceiptUri: suspend (Uri) -> String?,
    onAddCustomCategory: (String, TransactionType) -> Unit,
    onToggleSettleSplit: (SplitEntryEntity) -> Unit,
    onDismiss: () -> Unit,
    onSaveNew: (
        merchant: String,
        originalAmountCents: Long,
        originalCurrencyCode: String,
        type: TransactionType,
        category: ExpenseCategory?,
        customCategoryName: String?,
        dateMillis: Long,
        paymentMethod: PaymentMethod,
        walletId: Long,
        note: String,
        receiptUri: String?,
        splits: List<SplitInput>,
        repeatMonthly: Boolean,
        goalId: Long?
    ) -> Unit,
    onUpdateExisting: (ExpenseEntity) -> Unit,
    onDelete: ((ExpenseEntity) -> Unit)? = null
) {
    val scope = rememberCoroutineScope()
    val seed = existingExpense ?: prefillTemplate
    var txnType by remember(existingExpense, prefillTemplate) {
        mutableStateOf(seed?.let { TransactionType.fromRaw(it.transactionType) } ?: TransactionType.EXPENSE)
    }
    var merchant by remember(existingExpense, prefillTemplate) { mutableStateOf(seed?.merchant.orEmpty()) }
    var amountText by remember(existingExpense, prefillTemplate) {
        mutableStateOf(
            seed?.let {
                val cents = if (it.originalAmountCents > 0L) it.originalAmountCents else it.amountCents
                String.format(java.util.Locale.US, "%.2f", cents / 100.0)
            }.orEmpty()
        )
    }
    var txnCurrency by remember(existingExpense, prefillTemplate, baseCurrencyCode) {
        mutableStateOf(seed?.originalCurrencyCode ?: baseCurrencyCode)
    }
    var manualCategory by remember(existingExpense, prefillTemplate) {
        mutableStateOf(seed?.let { ExpenseCategory.fromRaw(it.category) })
    }
    var selectedCustomCatName by remember(existingExpense, prefillTemplate) {
        mutableStateOf(seed?.customCategoryName)
    }
    var paymentMethod by remember(existingExpense, prefillTemplate) {
        mutableStateOf(seed?.let { PaymentMethod.fromRaw(it.paymentMethod) } ?: PaymentMethod.UPI)
    }
    var selectedWalletId by remember(existingExpense, prefillTemplate, wallets) {
        mutableStateOf(seed?.walletId?.takeIf { it > 0L } ?: wallets.firstOrNull()?.id ?: 0L)
    }
    var selectedGoalId by remember(existingExpense, prefillTemplate) {
        mutableStateOf(existingExpense?.goalId)
    }
    var note by remember(existingExpense, prefillTemplate) { mutableStateOf(seed?.note.orEmpty()) }
    var receiptUri by remember(existingExpense) { mutableStateOf(existingExpense?.receiptUri) }
    var repeatMonthly by remember { mutableStateOf(false) }

    var showSmsPasteBox by remember { mutableStateOf(false) }
    var smsInput by remember { mutableStateOf("") }
    var showNewCatDialog by remember { mutableStateOf(false) }

    // Splits for new transaction
    var splitFriendInput by remember { mutableStateOf("") }
    var splitAmountInput by remember { mutableStateOf("") }
    val draftSplits = remember { mutableStateListOf<SplitInput>() }

    val defaultDay = remember(selectedYearMonth, existingExpense) {
        if (existingExpense != null) DateMonthUtils.dayOfMonthFromMillis(existingExpense.dateMillis).toString()
        else if (selectedYearMonth == DateMonthUtils.currentYearMonth()) DateMonthUtils.dayOfMonthFromMillis(System.currentTimeMillis()).toString()
        else "15"
    }
    var dayText by remember(existingExpense, selectedYearMonth) { mutableStateOf(defaultDay) }

    // Zero-permission Photo Picker for receipt attachment
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                receiptUri = onSaveReceiptUri(uri) ?: uri.toString()
            }
        }
    }

    val (autoSuggested, matchedRule) = remember(merchant, txnType) {
        if (txnType == TransactionType.INCOME) ExpenseCategory.SALARY_INCOME to null
        else previewAutoCategory(merchant)
    }
    val effectiveCategory = manualCategory ?: autoSuggested
    val parsedCents = SampleStatementParser.parseAmountToCents(amountText)
    val convertedBaseCents = parsedCents?.let {
        ExchangeRateService.convertCents(it, txnCurrency, baseCurrencyCode, usdRates)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (existingExpense == null) "New Transaction" else "Edit Transaction",
                    style = MaterialTheme.typography.headlineSmall
                )
                Row {
                    if (existingExpense == null) {
                        TextButton(
                            onClick = { showSmsPasteBox = !showSmsPasteBox },
                            modifier = Modifier.testTag("toggle_sms_autofill_button")
                        ) {
                            Icon(Icons.Rounded.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Paste SMS")
                        }
                    }
                    if (existingExpense != null && onDelete != null) {
                        IconButton(
                            onClick = { onDelete(existingExpense) },
                            modifier = Modifier.testTag("delete_expense_button")
                        ) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, contentDescription = "Close") }
                }
            }

            if (showSmsPasteBox) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Paste Bank or UPI SMS to auto-fill:", style = MaterialTheme.typography.labelMedium)
                        OutlinedTextField(
                            value = smsInput,
                            onValueChange = { smsInput = it },
                            placeholder = { Text("e.g. Debited INR 450.00 via UPI at Starbucks") },
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth().testTag("sms_autofill_input")
                        )
                        Button(
                            onClick = {
                                val parsed = onParseSms(smsInput)
                                if (parsed != null) {
                                    merchant = parsed.merchant
                                    amountText = String.format(java.util.Locale.US, "%.2f", parsed.amountCents / 100.0)
                                    txnCurrency = parsed.currencyCode
                                    txnType = parsed.transactionType
                                    paymentMethod = parsed.paymentMethod
                                    manualCategory = parsed.category
                                    showSmsPasteBox = false
                                }
                            },
                            enabled = smsInput.isNotBlank(),
                            modifier = Modifier.fillMaxWidth().testTag("apply_sms_autofill_button")
                        ) { Text("Auto-Fill Details") }
                    }
                }
            }

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                TransactionType.entries.forEachIndexed { idx, type ->
                    SegmentedButton(
                        selected = txnType == type,
                        onClick = { txnType = type },
                        shape = SegmentedButtonDefaults.itemShape(idx, TransactionType.entries.size)
                    ) { Text(type.label) }
                }
            }

            OutlinedTextField(
                value = merchant,
                onValueChange = { merchant = it },
                label = { Text("Description / Merchant") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                modifier = Modifier.fillMaxWidth().testTag("expense_merchant_input")
            )

            if (merchant.isNotBlank()) {
                Surface(
                    color = effectiveCategory.color.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = effectiveCategory.color, modifier = Modifier.size(16.dp))
                        Text(
                            text = when {
                                selectedCustomCatName != null -> "Custom category: $selectedCustomCatName"
                                manualCategory != null -> "Category: ${manualCategory!!.displayName}"
                                matchedRule != null -> "Auto-suggested \"$matchedRule\" → ${autoSuggested.displayName}"
                                else -> "Suggested: ${autoSuggested.displayName}"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = effectiveCategory.color
                        )
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (${currencySymbolFor(txnCurrency)})") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1.6f).testTag("expense_amount_input")
                )
                OutlinedTextField(
                    value = dayText,
                    onValueChange = { if (it.length <= 2 && it.all(Char::isDigit)) dayText = it },
                    label = { Text("Day") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(0.9f).testTag("expense_day_input")
                )
            }

            // Foreign currency selector + conversion preview
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SupportedCurrencies.forEach { cur ->
                    FilterChip(
                        selected = txnCurrency == cur.code,
                        onClick = { txnCurrency = cur.code },
                        label = { Text("${cur.symbol} ${cur.code}") }
                    )
                }
            }
            if (!txnCurrency.equals(baseCurrencyCode, ignoreCase = true) && convertedBaseCents != null) {
                Text(
                    text = "Converts to ${MoneyFormatters.formatMoneyExact(convertedBaseCents, currencySymbolFor(baseCurrencyCode))} ($baseCurrencyCode)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Category + Custom Categories
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Category", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { showNewCatDialog = true }) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Custom")
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = manualCategory == null && selectedCustomCatName == null,
                        onClick = { manualCategory = null; selectedCustomCatName = null },
                        label = { Text("Auto") }
                    )
                    customCategories.forEach { custom ->
                        FilterChip(
                            selected = selectedCustomCatName == custom.name,
                            onClick = {
                                selectedCustomCatName = custom.name
                                manualCategory = if (txnType == TransactionType.INCOME) ExpenseCategory.SALARY_INCOME else ExpenseCategory.OTHER
                            },
                            label = { Text(custom.name) }
                        )
                    }
                    ExpenseCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = manualCategory == cat && selectedCustomCatName == null,
                            onClick = {
                                selectedCustomCatName = null
                                manualCategory = if (manualCategory == cat) null else cat
                            },
                            label = { Text(cat.shortName) }
                        )
                    }
                }
            }

            // Payment Method & Wallet
            Text("Payment Method & Wallet", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PaymentMethod.entries.forEach { method ->
                    FilterChip(
                        selected = paymentMethod == method,
                        onClick = { paymentMethod = method },
                        label = { Text(method.label) }
                    )
                }
            }
            if (wallets.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    wallets.forEach { w ->
                        FilterChip(
                            selected = selectedWalletId == w.id,
                            onClick = { selectedWalletId = w.id },
                            label = { Text(w.name) }
                        )
                    }
                }
            }

            // Pay from Savings Goal selector (CapitalX v9.5)
            val eligibleGoals = goals.filter { it.savedCents > 0L || it.id == existingExpense?.goalId }
            if (txnType == TransactionType.EXPENSE && eligibleGoals.isNotEmpty()) {
                val goalDisabled = draftSplits.isNotEmpty() || repeatMonthly
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (goalDisabled) "Pay from Savings Goal (unavailable with splits/repeat)" else "Pay from Savings Goal (optional)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedGoalId == null,
                            onClick = { selectedGoalId = null },
                            enabled = !goalDisabled,
                            label = { Text("None") }
                        )
                        eligibleGoals.forEach { g ->
                            FilterChip(
                                selected = selectedGoalId == g.id,
                                onClick = { selectedGoalId = if (selectedGoalId == g.id) null else g.id },
                                enabled = !goalDisabled,
                                label = {
                                    Text("${g.name} (${MoneyFormatters.formatMoney(g.savedCents, currencySymbolFor(baseCurrencyCode))})")
                                }
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Note (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Receipt Photo Attachment (Zero-permission Photo Picker)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.testTag("attach_receipt_button")
                ) {
                    Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (receiptUri == null) "Attach Receipt" else "Change Receipt")
                }
                if (receiptUri != null) {
                    AsyncImage(
                        model = receiptUri,
                        contentDescription = "Attached receipt photo",
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Existing Splits Settle-Up OR Add Splits for New Transaction
            if (existingExpense != null && existingSplits.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.Group, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("Split Settle-Up", style = MaterialTheme.typography.titleSmall)
                        }
                        existingSplits.forEach { sp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onToggleSettleSplit(sp) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(sp.friendName, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        text = MoneyFormatters.formatMoneyExact(sp.shareCents, currencySymbolFor(baseCurrencyCode)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                FilterChip(
                                    selected = sp.isSettled,
                                    onClick = { onToggleSettleSplit(sp) },
                                    label = { Text(if (sp.isSettled) "Paid Back" else "Settle Up") },
                                    leadingIcon = if (sp.isSettled) {
                                        { Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null
                                )
                            }
                        }
                    }
                }
            } else if (existingExpense == null && txnType == TransactionType.EXPENSE) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Split with Friends (optional)", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = splitFriendInput,
                                onValueChange = { splitFriendInput = it },
                                label = { Text("Friend") },
                                singleLine = true,
                                modifier = Modifier.weight(1.3f)
                            )
                            OutlinedTextField(
                                value = splitAmountInput,
                                onValueChange = { splitAmountInput = it },
                                label = { Text("Share") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    val share = SampleStatementParser.parseAmountToCents(splitAmountInput)
                                    if (splitFriendInput.isNotBlank() && share != null && share > 0L) {
                                        selectedGoalId = null
                                        draftSplits += SplitInput(splitFriendInput.trim(), share)
                                        splitFriendInput = ""
                                        splitAmountInput = ""
                                    }
                                }
                            ) { Icon(Icons.Rounded.Add, contentDescription = "Add split friend") }
                        }
                        draftSplits.forEachIndexed { idx, sp ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${sp.friendName}: ${MoneyFormatters.formatMoneyExact(sp.shareCents, currencySymbolFor(baseCurrencyCode))}", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { draftSplits.removeAt(idx) }) { Text("Remove") }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Repeat monthly (auto-rule)", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = repeatMonthly,
                        onCheckedChange = {
                            repeatMonthly = it
                            if (it) selectedGoalId = null
                        }
                    )
                }
            }

            val isValid = merchant.isNotBlank() && parsedCents != null && parsedCents > 0L
            Button(
                onClick = {
                    val cents = parsedCents ?: return@Button
                    val day = dayText.toIntOrNull() ?: 1
                    val millis = DateMonthUtils.millisForDayInMonth(selectedYearMonth, day)
                    val effectiveGoalId = if (txnType == TransactionType.EXPENSE && draftSplits.isEmpty() && !repeatMonthly) selectedGoalId else null
                    if (existingExpense == null) {
                        onSaveNew(
                            merchant, cents, txnCurrency, txnType, manualCategory, selectedCustomCatName,
                            millis, paymentMethod, selectedWalletId, note, receiptUri, draftSplits.toList(), repeatMonthly, effectiveGoalId
                        )
                    } else {
                        val resolvedCat = manualCategory ?: effectiveCategory
                        val baseCents = ExchangeRateService.convertCents(cents, txnCurrency, baseCurrencyCode, usdRates)
                        onUpdateExisting(
                            existingExpense.copy(
                                merchant = merchant.trim(),
                                amountCents = baseCents,
                                originalAmountCents = cents,
                                originalCurrencyCode = txnCurrency,
                                transactionType = txnType.name,
                                category = resolvedCat.name,
                                customCategoryName = selectedCustomCatName,
                                dateMillis = millis,
                                paymentMethod = paymentMethod.name,
                                walletId = selectedWalletId,
                                goalId = effectiveGoalId,
                                note = note.trim(),
                                receiptUri = receiptUri
                            )
                        )
                    }
                },
                enabled = isValid,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("save_expense_button")
            ) {
                Text(if (existingExpense == null) "Save Transaction" else "Update Transaction", fontWeight = FontWeight.SemiBold)
            }
        }
    }

    if (showNewCatDialog) {
        var newCatName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewCatDialog = false },
            title = { Text("Create Custom Category") },
            text = {
                OutlinedTextField(
                    value = newCatName,
                    onValueChange = { newCatName = it },
                    label = { Text("Category name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCatName.isNotBlank()) {
                            onAddCustomCategory(newCatName.trim(), txnType)
                            selectedCustomCatName = newCatName.trim()
                            showNewCatDialog = false
                        }
                    },
                    enabled = newCatName.isNotBlank()
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewCatDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun EditBudgetDialog(
    category: ExpenseCategory,
    currentLimitCents: Long,
    rolloverEnabled: Boolean,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (limitCents: Long, rolloverEnabled: Boolean) -> Unit
) {
    var limitInput by remember(category, currentLimitCents) {
        mutableStateOf(String.format(java.util.Locale.US, "%.0f", currentLimitCents / 100.0))
    }
    var rollover by remember(category, rolloverEnabled) { mutableStateOf(rolloverEnabled) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Budget · ${category.shortName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = limitInput,
                    onValueChange = { limitInput = it },
                    label = { Text("Monthly Limit ($currencySymbol)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().testTag("edit_budget_input")
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Rollover unspent amount", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Carry unused balance from last month into this month's cap.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = rollover, onCheckedChange = { rollover = it })
                }
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(limitInput)
            Button(
                onClick = { cents?.let { onConfirm(it, rollover) } },
                enabled = cents != null && cents > 0L,
                modifier = Modifier.testTag("confirm_budget_button")
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddAutoRuleDialog(
    wallets: List<WalletEntity>,
    onDismiss: () -> Unit,
    onConfirm: (keyword: String, category: ExpenseCategory, targetWalletId: Long?) -> Unit
) {
    var keyword by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.FOOD_DINING) }
    var selectedWalletId by remember { mutableStateOf<Long?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Auto-Rule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = keyword,
                    onValueChange = { keyword = it },
                    label = { Text("If merchant contains…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("rule_keyword_input")
                )
                Text("Assign category:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExpenseCategory.entries.forEach { cat ->
                        FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat }, label = { Text(cat.shortName) })
                    }
                }
                if (wallets.isNotEmpty()) {
                    Text("Auto-assign wallet (optional):", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = selectedWalletId == null, onClick = { selectedWalletId = null }, label = { Text("Default") })
                        wallets.forEach { w ->
                            FilterChip(selected = selectedWalletId == w.id, onClick = { selectedWalletId = w.id }, label = { Text(w.name) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(keyword.trim(), selectedCategory, selectedWalletId) },
                enabled = keyword.trim().length >= 2,
                modifier = Modifier.testTag("confirm_rule_button")
            ) { Text("Save Rule") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddRecurringDialog(
    currencySymbol: String,
    wallets: List<WalletEntity>,
    onDismiss: () -> Unit,
    onConfirm: (merchant: String, amountCents: Long, category: ExpenseCategory, dayOfMonth: Int, walletId: Long, note: String) -> Unit
) {
    var merchant by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var dayText by remember { mutableStateOf("1") }
    var note by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.UTILITIES) }
    var selectedWalletId by remember { mutableStateOf(wallets.firstOrNull()?.id ?: 0L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule Recurring") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = merchant, onValueChange = { merchant = it }, label = { Text("Merchant / Bill") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount ($currencySymbol)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1.4f))
                    OutlinedTextField(value = dayText, onValueChange = { if (it.length <= 2 && it.all(Char::isDigit)) dayText = it }, label = { Text("Day") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExpenseCategory.expenseEntries.forEach { cat ->
                        FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat }, label = { Text(cat.shortName) })
                    }
                }
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            val cents = SampleStatementParser.parseAmountToCents(amountText)
            val day = dayText.toIntOrNull()?.coerceIn(1, 28) ?: 1
            Button(
                onClick = { cents?.let { onConfirm(merchant.trim(), it, selectedCategory, day, selectedWalletId, note) } },
                enabled = merchant.isNotBlank() && cents != null && cents > 0L
            ) { Text("Schedule") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun CustomizeWidgetsDialog(
    visibleWidgets: Set<DashboardWidget>,
    onToggleWidget: (DashboardWidget) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dashboard Widget Cards") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                DashboardWidget.entries.forEach { widget ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onToggleWidget(widget) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = visibleWidgets.contains(widget), onCheckedChange = { onToggleWidget(widget) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(widget.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("Done") } }
    )
}
