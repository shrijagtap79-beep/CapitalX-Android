package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.data.local.ExpenseEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.parser.DateMonthUtils
import com.example.ui.state.CategoryBreakdownItem
import com.example.ui.state.DailySpendPoint
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.MonthlyCashflowPoint
import com.example.ui.theme.MonoNumericTextStyle
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.hypot

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategoryDonutChartCard(
    breakdowns: List<CategoryBreakdownItem>,
    totalSpentCents: Long,
    currencySymbol: String,
    hideAmounts: Boolean,
    modifier: Modifier = Modifier
) {
    val activeSlices = remember(breakdowns) { breakdowns.filter { it.spentCents > 0L } }
    var selectedCategory by remember(activeSlices) { mutableStateOf<ExpenseCategory?>(null) }
    val selectedItem = activeSlices.firstOrNull { it.category == selectedCategory }

    val animatedProgress by animateFloatAsState(
        targetValue = if (activeSlices.isEmpty()) 0f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "donut_sweep"
    )
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val primaryColor = MaterialTheme.colorScheme.primary

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("category_donut_card"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Sector Allocation", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = if (activeSlices.isEmpty()) "No expenses logged this month"
                        else "Tap a ring segment or ticker pill",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (selectedItem != null) {
                    Surface(
                        color = selectedItem.category.color.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(99.dp)
                    ) {
                        Text(
                            text = "${(selectedItem.shareFraction * 100).toInt()}%",
                            style = MonoNumericTextStyle.copy(fontSize = sp(12f), fontWeight = FontWeight.Bold),
                            color = selectedItem.category.color,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(186.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .size(176.dp)
                        .pointerInput(activeSlices) {
                            detectTapGestures { offset ->
                                if (activeSlices.isEmpty()) return@detectTapGestures
                                val cx = size.width / 2f
                                val cy = size.height / 2f
                                val dx = offset.x - cx
                                val dy = offset.y - cy
                                val radius = hypot(dx, dy)
                                val outerR = size.width.coerceAtMost(size.height) / 2f
                                if (radius < outerR * 0.45f || radius > outerR) {
                                    selectedCategory = null
                                    return@detectTapGestures
                                }
                                var angle = (atan2(dy, dx) * 180.0 / PI).toFloat() + 90f
                                if (angle < 0f) angle += 360f
                                var cursor = 0f
                                for (item in activeSlices) {
                                    val sweep = item.shareFraction * 360f
                                    if (angle in cursor..(cursor + sweep)) {
                                        selectedCategory = if (selectedCategory == item.category) null else item.category
                                        break
                                    }
                                    cursor += sweep
                                }
                            }
                        }
                ) {
                    val strokePx = 22.dp.toPx()
                    val diameter = size.minDimension - strokePx
                    val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                    val arcSize = Size(diameter, diameter)

                    drawArc(trackColor, 0f, 360f, false, topLeft, arcSize, style = Stroke(strokePx))

                    if (activeSlices.isNotEmpty()) {
                        val gapAngle = if (activeSlices.size > 1) 2.5f else 0f
                        var startAngle = -90f
                        for (slice in activeSlices) {
                            val rawSweep = slice.shareFraction * 360f * animatedProgress
                            val drawSweep = (rawSweep - gapAngle).coerceAtLeast(1.5f)
                            val isSelected = selectedCategory == slice.category
                            val isDimmed = selectedCategory != null && !isSelected
                            drawArc(
                                color = if (isDimmed) slice.category.color.copy(alpha = 0.25f) else slice.category.color,
                                startAngle = startAngle,
                                sweepAngle = drawSweep,
                                useCenter = false,
                                topLeft = topLeft,
                                size = arcSize,
                                style = Stroke(width = if (isSelected) strokePx + 5.dp.toPx() else strokePx)
                            )
                            startAngle += rawSweep
                        }
                    } else {
                        drawArc(
                            primaryColor.copy(alpha = 0.2f), -90f, 110f, false, topLeft, arcSize,
                            style = Stroke(strokePx, cap = StrokeCap.Round)
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = selectedItem?.category?.shortName ?: "Outflow",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = MoneyFormatters.formatMoney(
                            selectedItem?.spentCents ?: totalSpentCents,
                            currencySymbol,
                            hidden = hideAmounts
                        ),
                        style = MonoNumericTextStyle.copy(fontSize = sp(18f), fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            if (activeSlices.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    activeSlices.forEach { item ->
                        val isSelected = selectedCategory == item.category
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .clickable { selectedCategory = if (isSelected) null else item.category },
                            color = if (isSelected) item.category.color.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(99.dp),
                            border = if (isSelected) BorderStroke(1.dp, item.category.color) else null
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(item.category.color))
                                Text(item.category.shortName, style = MaterialTheme.typography.labelMedium)
                                Text(
                                    MoneyFormatters.formatMoney(item.spentCents, currencySymbol, hidden = hideAmounts),
                                    style = MonoNumericTextStyle.copy(fontSize = sp(11f), fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DailyExpenseTrendChartCard(
    dailyPoints: List<DailySpendPoint>,
    dailyTargetCents: Long,
    currencySymbol: String,
    hideAmounts: Boolean,
    monthTitle: String,
    monthTransactions: List<ExpenseEntity> = emptyList(),
    modifier: Modifier = Modifier
) {
    var selectedDay by remember(dailyPoints) { mutableIntStateOf(-1) }
    val selectedPoint = dailyPoints.firstOrNull { it.dayOfMonth == selectedDay }
    val selectedDayTransactions = remember(monthTransactions, selectedDay) {
        if (selectedDay <= 0) emptyList()
        else monthTransactions.filter { DateMonthUtils.dayOfMonthFromMillis(it.dateMillis) == selectedDay }
    }
    val maxDaySpent = remember(dailyPoints, dailyTargetCents) {
        maxOf(dailyPoints.maxOfOrNull { it.spentCents } ?: 0L, dailyTargetCents * 2L, 100_00L)
    }

    val lineColor = MaterialTheme.colorScheme.primary
    val overColor = MaterialTheme.colorScheme.error
    val targetLineColor = MaterialTheme.colorScheme.outline
    val gridColor = MaterialTheme.colorScheme.outlineVariant

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("daily_trend_chart_card"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Daily Expense Trend", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = selectedPoint?.let {
                            "Day ${it.dayOfMonth}: ${MoneyFormatters.formatMoneyExact(it.spentCents, currencySymbol, hideAmounts)} (${it.transactionCount} txn)"
                        } ?: "Pace cap: ${MoneyFormatters.formatMoney(dailyTargetCents, currencySymbol, hidden = hideAmounts)}/day",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (selectedPoint != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(99.dp)
                ) {
                    Text(
                        text = monthTitle.substringBefore(" ").uppercase(),
                        style = MonoNumericTextStyle.copy(fontSize = sp(11f), fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(148.dp)
                    .pointerInput(dailyPoints) {
                        detectTapGestures { offset ->
                            if (dailyPoints.isEmpty()) return@detectTapGestures
                            val slotW = size.width / dailyPoints.size.toFloat()
                            val idx = (offset.x / slotW).toInt().coerceIn(0, dailyPoints.lastIndex)
                            val day = dailyPoints[idx].dayOfMonth
                            selectedDay = if (selectedDay == day) -1 else day
                        }
                    }
            ) {
                val count = dailyPoints.size.coerceAtLeast(1)
                val stepX = if (count > 1) size.width / (count - 1).toFloat() else size.width
                val chartH = size.height - 8.dp.toPx()

                // Horizontal grid lines
                for (i in 1..3) {
                    val y = chartH * (i / 4f)
                    drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 0.8.dp.toPx())
                }

                // Target pace dashed line
                val targetRatio = (dailyTargetCents.toFloat() / maxDaySpent.toFloat()).coerceIn(0f, 1f)
                val targetY = chartH * (1f - targetRatio)
                drawLine(
                    color = targetLineColor,
                    start = Offset(0f, targetY),
                    end = Offset(size.width, targetY),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                )

                // Area + stock ticker line
                val linePath = Path()
                val fillPath = Path()
                val points = dailyPoints.mapIndexed { idx, pt ->
                    val x = idx * stepX
                    val y = chartH * (1f - (pt.spentCents.toFloat() / maxDaySpent.toFloat()).coerceIn(0f, 1f))
                    Offset(x, y)
                }

                if (points.isNotEmpty()) {
                    linePath.moveTo(points.first().x, points.first().y)
                    fillPath.moveTo(points.first().x, chartH)
                    fillPath.lineTo(points.first().x, points.first().y)
                    for (i in 1 until points.size) {
                        linePath.lineTo(points[i].x, points[i].y)
                        fillPath.lineTo(points[i].x, points[i].y)
                    }
                    fillPath.lineTo(points.last().x, chartH)
                    fillPath.close()

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(lineColor.copy(alpha = 0.28f), lineColor.copy(alpha = 0.02f)),
                            startY = 0f,
                            endY = chartH
                        )
                    )
                    drawPath(
                        path = linePath,
                        color = lineColor,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    points.forEachIndexed { idx, offset ->
                        val pt = dailyPoints[idx]
                        if (pt.spentCents > 0L || pt.dayOfMonth == selectedDay) {
                            val dotColor = if (pt.spentCents > dailyTargetCents) overColor else lineColor
                            drawCircle(
                                color = dotColor,
                                radius = if (pt.dayOfMonth == selectedDay) 5.dp.toPx() else 3.dp.toPx(),
                                center = offset
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("D1", style = MonoNumericTextStyle.copy(fontSize = sp(11f)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("D10", style = MonoNumericTextStyle.copy(fontSize = sp(11f)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("D20", style = MonoNumericTextStyle.copy(fontSize = sp(11f)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("D${dailyPoints.size}", style = MonoNumericTextStyle.copy(fontSize = sp(11f)), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (selectedPoint != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("selected_trend_day_details"),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Day ${selectedPoint.dayOfMonth} · ${monthTitle.substringBefore(" ")}",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${selectedDayTransactions.size} txn",
                                style = MonoNumericTextStyle.copy(fontSize = sp(11f)),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Expenses", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        MoneyFormatters.formatMoneyExact(selectedPoint.spentCents, currencySymbol, hideAmounts),
                                        style = MonoNumericTextStyle.copy(fontSize = sp(13f), fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Income", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        MoneyFormatters.formatMoneyExact(selectedPoint.incomeCents, currencySymbol, hideAmounts),
                                        style = MonoNumericTextStyle.copy(fontSize = sp(13f), fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                        if (selectedDayTransactions.isEmpty()) {
                            Text(
                                "No expenses or income recorded for this day. Tap another point to inspect.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            selectedDayTransactions.take(6).forEach { tx ->
                                val isInc = TransactionType.fromRaw(tx.transactionType) == TransactionType.INCOME
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(tx.merchant, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "${ExpenseCategory.fromRaw(tx.category).shortName} · ${PaymentMethod.fromRaw(tx.paymentMethod).label}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "${if (isInc) "+" else "-"}${MoneyFormatters.formatMoneyExact(tx.amountCents, currencySymbol, hideAmounts)}",
                                        style = MonoNumericTextStyle.copy(fontSize = sp(12f), fontWeight = FontWeight.SemiBold),
                                        color = if (isInc) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IncomeVsExpenseChartCard(
    title: String,
    points: List<MonthlyCashflowPoint>,
    currencySymbol: String,
    hideAmounts: Boolean,
    modifier: Modifier = Modifier
) {
    val maxVal = remember(points) {
        maxOf(
            points.maxOfOrNull { maxOf(it.incomeCents, it.expenseCents) } ?: 0L,
            100_00L
        )
    }
    val bullColor = MaterialTheme.colorScheme.primary
    val bearColor = MaterialTheme.colorScheme.error
    val trackBg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("income_vs_expense_chart_card"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(bullColor))
                        Text("In", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(bearColor))
                        Text("Out", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(136.dp)
            ) {
                val count = points.size.coerceAtLeast(1)
                val slotW = size.width / count
                val barW = (slotW * 0.28f).coerceIn(4.dp.toPx(), 16.dp.toPx())
                val gap = 3.dp.toPx()
                val chartH = size.height

                points.forEachIndexed { idx, pt ->
                    val centerX = idx * slotW + slotW / 2f
                    val inLeft = centerX - barW - gap / 2f
                    val outLeft = centerX + gap / 2f

                    drawRoundRect(trackBg, Offset(inLeft, 0f), Size(barW, chartH), CornerRadius(4.dp.toPx()))
                    drawRoundRect(trackBg, Offset(outLeft, 0f), Size(barW, chartH), CornerRadius(4.dp.toPx()))

                    if (pt.incomeCents > 0L) {
                        val h = chartH * (pt.incomeCents.toFloat() / maxVal.toFloat()).coerceIn(0.05f, 1f)
                        drawRoundRect(bullColor, Offset(inLeft, chartH - h), Size(barW, h), CornerRadius(4.dp.toPx()))
                    }
                    if (pt.expenseCents > 0L) {
                        val h = chartH * (pt.expenseCents.toFloat() / maxVal.toFloat()).coerceIn(0.05f, 1f)
                        drawRoundRect(bearColor, Offset(outLeft, chartH - h), Size(barW, h), CornerRadius(4.dp.toPx()))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                points.forEach { pt ->
                    Text(
                        text = pt.shortLabel,
                        style = MonoNumericTextStyle.copy(fontSize = sp(10f)),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            val latest = points.lastOrNull()
            if (latest != null) {
                Spacer(modifier = Modifier.height(8.dp))
                val net = latest.incomeCents - latest.expenseCents
                Text(
                    text = "${latest.shortLabel} Net: ${MoneyFormatters.formatMoney(net, currencySymbol, includeSign = true, hidden = hideAmounts)}",
                    style = MonoNumericTextStyle.copy(fontSize = sp(12f), fontWeight = FontWeight.SemiBold),
                    color = if (net >= 0L) bullColor else bearColor
                )
            }
        }
    }
}

@Composable
fun CategoryBudgetProgressRow(
    item: CategoryBreakdownItem,
    currencySymbol: String,
    hideAmounts: Boolean,
    showLastMonthDelta: Boolean = false,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val utilization = item.budgetUtilization.coerceAtLeast(0f)
    val animatedFill by animateFloatAsState(
        targetValue = utilization.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "budget_bar"
    )
    val statusColor = when {
        utilization > 1f -> MaterialTheme.colorScheme.error
        utilization >= 0.8f -> MaterialTheme.colorScheme.tertiary
        else -> item.category.color
    }
    val remaining = item.effectiveBudgetCents - item.spentCents

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(item.category.color.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(item.category.icon, contentDescription = item.category.displayName, tint = item.category.color, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.category.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (item.rolloverCents > 0L) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "+${MoneyFormatters.formatCompact(item.rolloverCents, currencySymbol, hideAmounts)} rollover",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = "${MoneyFormatters.formatMoney(item.spentCents, currencySymbol, hidden = hideAmounts)} / ${MoneyFormatters.formatMoney(item.effectiveBudgetCents, currencySymbol, hidden = hideAmounts)}",
                    style = MonoNumericTextStyle.copy(fontSize = sp(12f), fontWeight = FontWeight.SemiBold)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(99.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedFill)
                        .height(8.dp)
                        .clip(RoundedCornerShape(99.dp))
                        .background(statusColor)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val leftText = if (remaining >= 0) "${MoneyFormatters.formatMoney(remaining, currencySymbol, hidden = hideAmounts)} left"
                else "Over by ${MoneyFormatters.formatMoney(-remaining, currencySymbol, hidden = hideAmounts)}"
                Text(
                    text = leftText,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (remaining >= 0) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                )

                if (showLastMonthDelta && item.lastMonthSpentCents > 0L) {
                    val diff = item.spentCents - item.lastMonthSpentCents
                    val pct = ((diff.toFloat() / item.lastMonthSpentCents.toFloat()) * 100f).toInt()
                    val arrow = if (diff >= 0) "▲ +$pct%" else "▼ $pct%"
                    Text(
                        text = "$arrow vs last mo",
                        style = MonoNumericTextStyle.copy(fontSize = sp(11f), fontWeight = FontWeight.Medium),
                        color = if (diff > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text(
                        text = "${(utilization * 100).toInt()}%",
                        style = MonoNumericTextStyle.copy(fontSize = sp(11f), fontWeight = FontWeight.Medium),
                        color = statusColor
                    )
                }
            }
        }
    }
}

private fun sp(v: Float) = TextUnit(v, TextUnitType.Sp)
