package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.data.local.ExpenseEntity
import com.example.data.local.SplitEntryEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.parser.DateMonthUtils
import com.example.ui.components.EmptyLedgerHero
import com.example.ui.components.ExpenseRowCard
import com.example.ui.components.MonthSwitcherHeader
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.MoneyUiState
import com.example.ui.theme.MonoNumericTextStyle

@Composable
fun ExpensesScreen(
    state: MoneyUiState,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onJumpCurrentMonth: () -> Unit,
    onToggleHideAmounts: () -> Unit,
    onLockNow: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleType: (TransactionType?) -> Unit,
    onToggleCategory: (ExpenseCategory?) -> Unit,
    onTogglePaymentMethod: (PaymentMethod?) -> Unit,
    onToggleWalletFilter: (Long?) -> Unit,
    onToggleSettleSplit: (SplitEntryEntity) -> Unit,
    onEditExpense: (ExpenseEntity) -> Unit,
    onDuplicateExpense: (ExpenseEntity) -> Unit,
    onQuickFill: (ExpenseEntity) -> Unit,
    onAddExpenseClick: () -> Unit,
    onOpenImporter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCurrentMonth = state.selectedYearMonth == DateMonthUtils.currentYearMonth()
    val hasPin = !state.activeAccount?.pinHash.isNullOrBlank()
    val walletMap = remember(state.wallets) { state.wallets.associateBy { it.id } }
    val groupedByDate = remember(state.filteredTransactions) {
        state.filteredTransactions.groupBy { DateMonthUtils.formatFullDate(it.dateMillis) }
    }
    val pendingSplits = remember(state.splitsByTransactionId) {
        state.splitsByTransactionId.values.flatten().filter { !it.isSettled }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("expenses_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            MonthSwitcherHeader(
                monthTitle = state.monthTitle,
                isCurrentMonth = isCurrentMonth,
                hideAmounts = state.hideAmounts,
                hasPinLock = hasPin,
                onToggleHideAmounts = onToggleHideAmounts,
                onLockNow = onLockNow,
                onPreviousMonth = onPreviousMonth,
                onNextMonth = onNextMonth,
                onJumpCurrent = onJumpCurrentMonth
            )
        }

        if (state.quickFillSuggestions.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Quick-Fill Frequent Entries",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .testTag("quick_fill_chips"),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.quickFillSuggestions.forEachIndexed { idx, sug ->
                            val tmpl = sug.templateExpense
                            AssistChip(
                                onClick = { onQuickFill(tmpl) },
                                leadingIcon = {
                                    Icon(Icons.Rounded.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                },
                                label = {
                                    Text("${tmpl.merchant} · ${MoneyFormatters.formatMoney(tmpl.amountCents, state.currencySymbol, hidden = state.hideAmounts)}")
                                },
                                modifier = Modifier.testTag("quick_fill_chip_$idx")
                            )
                        }
                    }
                }
            }
        }

        if (pendingSplits.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("pending_splits_card"),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.Group, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                            Text("Split Settle-Up (${pendingSplits.size} pending)", style = MaterialTheme.typography.titleSmall)
                        }
                        pendingSplits.take(4).forEach { sp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onToggleSettleSplit(sp) }
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${sp.friendName} owes ${MoneyFormatters.formatMoneyExact(sp.shareCents, state.currencySymbol, state.hideAmounts)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                FilterChip(
                                    selected = false,
                                    onClick = { onToggleSettleSplit(sp) },
                                    label = { Text("Mark Paid") }
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = state.filters.searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search merchant, category, or note…") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (state.filters.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("expense_search_input")
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = state.filters.selectedType == null,
                        onClick = { onToggleType(null) },
                        label = { Text("All Types") }
                    )
                    TransactionType.entries.forEach { t ->
                        FilterChip(
                            selected = state.filters.selectedType == t,
                            onClick = { onToggleType(t) },
                            label = { Text(t.label) }
                        )
                    }
                    PaymentMethod.entries.forEach { m ->
                        FilterChip(
                            selected = state.filters.selectedPaymentMethod == m,
                            onClick = { onTogglePaymentMethod(m) },
                            label = { Text(m.label) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = state.filters.selectedCategory == null,
                        onClick = { onToggleCategory(null) },
                        label = { Text("All Categories") }
                    )
                    ExpenseCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = state.filters.selectedCategory == cat,
                            onClick = { onToggleCategory(cat) },
                            label = { Text(cat.shortName) }
                        )
                    }
                }

                if (state.wallets.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.wallets.forEach { w ->
                            FilterChip(
                                selected = state.filters.selectedWalletId == w.id,
                                onClick = { onToggleWalletFilter(w.id) },
                                label = { Text(w.name) }
                            )
                        }
                    }
                }
            }
        }

        if (state.monthTransactions.isEmpty()) {
            item {
                EmptyLedgerHero(
                    onAddExpense = onAddExpenseClick,
                    onGoToImport = onOpenImporter
                )
            }
        } else if (state.filteredTransactions.isEmpty()) {
            item {
                Surface(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No matching transactions", style = MaterialTheme.typography.titleMedium)
                        Text("Try clearing a filter chip above.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            groupedByDate.forEach { (dateLabel, itemsForDay) ->
                val dayOutflow = itemsForDay
                    .filter { TransactionType.fromRaw(it.transactionType) == TransactionType.EXPENSE }
                    .sumOf { it.amountCents }
                item(key = "header_$dateLabel") {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(dateLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "Out ${MoneyFormatters.formatMoneyExact(dayOutflow, state.currencySymbol, state.hideAmounts)}",
                            style = MonoNumericTextStyle.copy(fontSize = TextUnit(12f, TextUnitType.Sp), fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                items(itemsForDay, key = { it.id }) { txn ->
                    ExpenseRowCard(
                        expense = txn,
                        currencySymbol = state.currencySymbol,
                        baseCurrencyCode = state.currencyCode,
                        hideAmounts = state.hideAmounts,
                        splits = state.splitsByTransactionId[txn.id].orEmpty(),
                        walletName = walletMap[txn.walletId]?.name,
                        onClick = { onEditExpense(txn) },
                        onDuplicate = { onDuplicateExpense(txn) }
                    )
                }
            }
        }
    }
}
