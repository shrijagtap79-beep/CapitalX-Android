package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Receipt
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ExpenseEntity
import com.example.data.local.SplitEntryEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseSource
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.model.currencySymbolFor
import com.example.data.parser.DateMonthUtils
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.TickerItem
import com.example.ui.theme.MonoNumericTextStyle

@Composable
fun MarketTickerTape(
    items: List<TickerItem>,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) return
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("market_ticker_tape"),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 38.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items.forEach { item ->
                val trendColor = when {
                    item.trend > 0 -> MaterialTheme.colorScheme.primary
                    item.trend < 0 -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                val arrow = when {
                    item.trend > 0 -> "▲"
                    item.trend < 0 -> "▼"
                    else -> "■"
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.label,
                        style = MonoNumericTextStyle.copy(
                            fontSize = TextUnit(10f, TextUnitType.Sp),
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                    Text(
                        text = "$arrow ${item.valueText}",
                        style = MonoNumericTextStyle.copy(
                            fontSize = TextUnit(11f, TextUnitType.Sp),
                            fontWeight = FontWeight.Bold
                        ),
                        color = trendColor,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun MonthSwitcherHeader(
    monthTitle: String,
    isCurrentMonth: Boolean,
    hideAmounts: Boolean,
    hasPinLock: Boolean,
    onToggleHideAmounts: () -> Unit,
    onLockNow: () -> Unit,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onJumpCurrent: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "CAPITALX",
                    style = MonoNumericTextStyle.copy(fontSize = TextUnit(11f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "LIVE",
                        style = MonoNumericTextStyle.copy(fontSize = TextUnit(9f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
            }
            Text(
                text = monthTitle,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(
                onClick = onToggleHideAmounts,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("toggle_hide_amounts_button")
            ) {
                Icon(
                    imageVector = if (hideAmounts) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                    contentDescription = if (hideAmounts) "Show amounts" else "Hide amounts"
                )
            }
            if (hasPinLock) {
                IconButton(
                    onClick = onLockNow,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("lock_app_button")
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = "Lock app")
                }
            }
            Surface(
                shape = RoundedCornerShape(99.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onPreviousMonth,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("previous_month_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous month")
                    }
                    if (!isCurrentMonth) {
                        Text(
                            text = "Now",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onJumpCurrent)
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("jump_current_month_button")
                        )
                    }
                    IconButton(
                        onClick = onNextMonth,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("next_month_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next month")
                    }
                }
            }
        }
    }
}

@Composable
fun ExpenseRowCard(
    expense: ExpenseEntity,
    currencySymbol: String,
    baseCurrencyCode: String,
    hideAmounts: Boolean,
    splits: List<SplitEntryEntity>,
    walletName: String?,
    onClick: () -> Unit,
    onDuplicate: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val category = ExpenseCategory.fromRaw(expense.category)
    val source = ExpenseSource.fromRaw(expense.source)
    val txnType = TransactionType.fromRaw(expense.transactionType)
    val method = PaymentMethod.fromRaw(expense.paymentMethod)
    val isIncome = txnType == TransactionType.INCOME
    val pendingSplits = splits.count { !it.isSettled }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("expense_row_${expense.id}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (isIncome) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                        else category.color.copy(alpha = 0.14f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = category.icon,
                    contentDescription = category.displayName,
                    tint = if (isIncome) MaterialTheme.colorScheme.primary else category.color,
                    modifier = Modifier.size(21.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = expense.merchant,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (!expense.receiptUri.isNullOrBlank()) {
                        Icon(
                            Icons.Rounded.Receipt,
                            contentDescription = "Receipt attached",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = expense.customCategoryName?.takeIf { it.isNotBlank() } ?: category.shortName,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isIncome) MaterialTheme.colorScheme.primary else category.color
                    )
                    Text("·", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = method.label + (walletName?.let { " ($it)" } ?: ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (source != ExpenseSource.MANUAL) {
                        Icon(
                            imageVector = when (source) {
                                ExpenseSource.RECURRING -> Icons.Rounded.Repeat
                                ExpenseSource.IMPORTED -> Icons.Rounded.FileUpload
                                else -> Icons.Rounded.AutoAwesome
                            },
                            contentDescription = source.label,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    if (expense.goalId != null && expense.goalId > 0L) {
                        Icon(
                            Icons.Rounded.Flag,
                            contentDescription = "Paid from savings goal",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
                if (splits.isNotEmpty()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(Icons.Rounded.Group, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(12.dp))
                        Text(
                            text = if (pendingSplits > 0) "$pendingSplits split pending · tap to settle" else "All splits settled",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (pendingSplits > 0) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                val sign = if (isIncome) "+" else "-"
                Text(
                    text = "$sign${MoneyFormatters.formatMoneyExact(expense.amountCents, currencySymbol, hideAmounts)}",
                    style = MonoNumericTextStyle.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = TextUnit(14f, TextUnitType.Sp)
                    ),
                    color = if (isIncome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                if (!expense.originalCurrencyCode.equals(baseCurrencyCode, ignoreCase = true) && expense.originalAmountCents > 0L) {
                    Text(
                        text = MoneyFormatters.formatMoneyExact(
                            expense.originalAmountCents,
                            currencySymbolFor(expense.originalCurrencyCode),
                            hideAmounts
                        ),
                        style = MonoNumericTextStyle.copy(fontSize = TextUnit(10f, TextUnitType.Sp)),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (onDuplicate != null) {
                IconButton(
                    onClick = onDuplicate,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("duplicate_expense_${expense.id}")
                ) {
                    Icon(
                        Icons.Rounded.ContentCopy,
                        contentDescription = "Duplicate for today",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyLedgerHero(
    onAddExpense: () -> Unit,
    onGoToImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("empty_ledger_hero"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_budget_empty),
                contentDescription = "Capitalx market chart artwork",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(136.dp)
                    .clip(MaterialTheme.shapes.medium),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Your Capitalx Ledger Is Ready",
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Log income or expenses, paste a Bank/UPI SMS alert, or import a sample CSV to start tracking.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onGoToImport,
                    modifier = Modifier.weight(1f).height(48.dp).testTag("empty_import_sample_button")
                ) {
                    Icon(Icons.Rounded.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import", maxLines = 1)
                }
                Button(
                    onClick = onAddExpense,
                    modifier = Modifier.weight(1f).height(48.dp).testTag("empty_add_expense_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Txn", maxLines = 1)
                }
            }
        }
    }
}
