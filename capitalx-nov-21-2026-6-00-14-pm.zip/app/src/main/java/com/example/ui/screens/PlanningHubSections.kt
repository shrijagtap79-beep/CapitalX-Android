package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.border
import com.example.data.local.BillItemEntity
import com.example.data.local.ChallengeEntity
import com.example.data.local.GoalEntity
import com.example.data.local.LendingEntity
import com.example.data.local.SubscriptionEntity
import com.example.data.model.BillType
import com.example.data.model.LendingDirection
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.RepeatChargeSuggestion
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.MoneyUiState
import com.example.ui.theme.MonoNumericTextStyle
import kotlin.math.roundToInt

@Composable
fun BillCalendarSection(
    state: MoneyUiState,
    onAddBill: () -> Unit,
    onMarkBillPaid: (BillItemEntity, Long) -> Unit,
    onDeleteBill: (Long) -> Unit
) {
    val daysInMonth = DateMonthUtils.daysInMonth(state.selectedYearMonth)
    val todayDay = if (state.selectedYearMonth == DateMonthUtils.currentYearMonth()) {
        DateMonthUtils.dayOfMonthFromMillis(System.currentTimeMillis())
    } else -1
    val defaultWalletId = state.wallets.firstOrNull()?.id ?: 0L
    val billsByDay = state.bills.groupBy { it.dueDayOfMonth }

    Surface(
        modifier = Modifier.fillMaxWidth().testTag("bill_calendar_card"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text("Bill Calendar · ${state.monthTitle}", style = MaterialTheme.typography.titleMedium)
                        Text("EMIs, rent & credit card due dates", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                IconButton(onClick = onAddBill, modifier = Modifier.testTag("add_bill_button")) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add bill due date")
                }
            }

            // Compact 7-column calendar grid highlighting due days
            val weeks = (1..daysInMonth).toList().chunked(7)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                weeks.forEach { week ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        week.forEach { day ->
                            val dayBills = billsByDay[day].orEmpty()
                            val hasUnpaid = dayBills.any { it.lastPaidYearMonth != state.selectedYearMonth }
                            val allPaid = dayBills.isNotEmpty() && !hasUnpaid
                            val isOverdue = hasUnpaid && todayDay > 0 && day < todayDay
                            val bg = when {
                                isOverdue -> MaterialTheme.colorScheme.errorContainer
                                hasUnpaid -> MaterialTheme.colorScheme.tertiaryContainer
                                allPaid -> MaterialTheme.colorScheme.primaryContainer
                                day == todayDay -> MaterialTheme.colorScheme.secondaryContainer
                                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (dayBills.isNotEmpty()) "$day•" else "$day",
                                    style = MonoNumericTextStyle.copy(
                                        fontSize = TextUnit(11f, TextUnitType.Sp),
                                        fontWeight = if (dayBills.isNotEmpty() || day == todayDay) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                        repeat(7 - week.size) { Spacer(modifier = Modifier.weight(1f)) }
                    }
                }
            }

            if (state.bills.isEmpty()) {
                Text(
                    "No bills scheduled yet. Tap + to add EMIs, rent, or credit card dues.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                state.bills.forEach { bill ->
                    val isPaid = bill.lastPaidYearMonth == state.selectedYearMonth
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${bill.title} (${BillType.fromRaw(bill.billType).label})", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Due day ${bill.dueDayOfMonth} · ${MoneyFormatters.formatMoneyExact(bill.amountCents, state.currencySymbol, state.hideAmounts)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (isPaid) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    "Paid",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        } else {
                            FilledTonalButton(
                                onClick = { onMarkBillPaid(bill, defaultWalletId) },
                                modifier = Modifier.height(36.dp)
                            ) { Text("Mark Paid") }
                        }
                        IconButton(onClick = { onDeleteBill(bill.id) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete bill", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriptionsAndDetectorSection(
    state: MoneyUiState,
    onAddSubscription: () -> Unit,
    onAcceptSuggestion: (RepeatChargeSuggestion) -> Unit,
    onAdvanceRenewal: (SubscriptionEntity) -> Unit,
    onToggleReminder: (SubscriptionEntity) -> Unit,
    onDeleteSubscription: (Long) -> Unit
) {
    val yearlyTotalCents = state.subscriptions.filter { it.isActive }.sumOf { sub ->
        if (sub.billingCycle.equals("YEARLY", ignoreCase = true)) sub.amountCents else sub.amountCents * 12L
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (state.repeatChargeSuggestions.isNotEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("repeat_charge_detector_card"),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.secondaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Repeat-Charge Detector", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(
                        "Repeated charges detected in your ledger. Add them as subscriptions to track renewals:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    state.repeatChargeSuggestions.forEach { sug ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(sug.merchant, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${sug.occurrences}x · ~${MoneyFormatters.formatMoneyExact(sug.averageAmountCents, state.currencySymbol, state.hideAmounts)}/mo",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(onClick = { onAcceptSuggestion(sug) }, modifier = Modifier.height(36.dp)) {
                                Text("Add Sub")
                            }
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().testTag("subscriptions_card"),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Subscriptions", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Yearly run-rate: ${MoneyFormatters.formatMoneyExact(yearlyTotalCents, state.currencySymbol, state.hideAmounts)}/yr",
                            style = MonoNumericTextStyle.copy(fontSize = TextUnit(12f, TextUnitType.Sp), fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onAddSubscription, modifier = Modifier.testTag("add_subscription_button")) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add subscription")
                    }
                }

                if (state.subscriptions.isEmpty()) {
                    Text(
                        "No subscriptions added yet. Add services to track renewal dates and yearly cost.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    state.subscriptions.forEach { sub ->
                        val yearly = if (sub.billingCycle == "YEARLY") sub.amountCents else sub.amountCents * 12L
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(sub.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${MoneyFormatters.formatMoneyExact(sub.amountCents, state.currencySymbol, state.hideAmounts)} (${sub.billingCycle.lowercase()}) · ${MoneyFormatters.formatMoney(yearly, state.currencySymbol, hidden = state.hideAmounts)}/yr",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "Renews ${DateMonthUtils.formatFullDate(sub.nextRenewalMillis)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.clickable { onAdvanceRenewal(sub) }
                                )
                            }
                            IconButton(onClick = { onToggleReminder(sub) }) {
                                Icon(
                                    if (sub.reminderEnabled) Icons.Rounded.NotificationsActive else Icons.Rounded.NotificationsOff,
                                    contentDescription = "Toggle renewal reminder",
                                    tint = if (sub.reminderEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onDeleteSubscription(sub.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete subscription", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GoalsLendingChallengesSection(
    state: MoneyUiState,
    onAddGoal: () -> Unit,
    onContributeGoal: (GoalEntity) -> Unit,
    onDeleteGoal: (Long) -> Unit,
    onAddLending: () -> Unit,
    onSettleLending: (LendingEntity) -> Unit,
    onDeleteLending: (Long) -> Unit,
    onAddChallenge: () -> Unit,
    onToggleChallengeDay: (ChallengeEntity, String) -> Unit,
    onDeleteChallenge: (Long) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Goals
        Surface(
            modifier = Modifier.fillMaxWidth().testTag("goals_card"),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.Savings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Savings Goals", style = MaterialTheme.typography.titleMedium)
                    }
                    IconButton(onClick = onAddGoal, modifier = Modifier.testTag("add_goal_button")) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add goal")
                    }
                }
                if (state.goals.isEmpty()) {
                    Text("No savings goals yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val now = System.currentTimeMillis()
                    state.goals.forEach { g ->
                        val progress = (g.savedCents.toFloat() / g.targetCents.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
                        val paceHint = g.targetDateMillis?.let { targetMs ->
                            if (g.savedCents < g.targetCents && targetMs > now) {
                                val monthsLeft = ((targetMs - now) / (30.4 * 86_400_000.0)).roundToInt().coerceAtLeast(1)
                                val perMonthCents = (g.targetCents - g.savedCents) / monthsLeft
                                "Save ${MoneyFormatters.formatMoney(perMonthCents, state.currencySymbol, hidden = state.hideAmounts)}/mo for $monthsLeft mo"
                            } else null
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(g.name, style = MaterialTheme.typography.titleSmall)
                                    if (paceHint != null) {
                                        Text(paceHint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                Text(
                                    "${MoneyFormatters.formatMoney(g.savedCents, state.currencySymbol, hidden = state.hideAmounts)} / ${MoneyFormatters.formatMoney(g.targetCents, state.currencySymbol, hidden = state.hideAmounts)}",
                                    style = MonoNumericTextStyle.copy(fontSize = TextUnit(12f, TextUnitType.Sp), fontWeight = FontWeight.SemiBold)
                                )
                            }
                            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(99.dp)))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                TextButton(onClick = { onDeleteGoal(g.id) }) { Text("Remove") }
                                FilledTonalButton(onClick = { onContributeGoal(g) }, modifier = Modifier.height(36.dp)) { Text("+ Contribute") }
                            }
                        }
                    }
                }
            }
        }

        // Lending
        Surface(
            modifier = Modifier.fillMaxWidth().testTag("lending_card"),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Lending (Owe & Owed)", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onAddLending, modifier = Modifier.testTag("add_lending_button")) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add lending record")
                    }
                }
                if (state.lendingRecords.isEmpty()) {
                    Text("Track money you owe or money owed to you.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    state.lendingRecords.forEach { rec ->
                        val dir = LendingDirection.fromRaw(rec.direction)
                        val remaining = (rec.totalCents - rec.paidCents).coerceAtLeast(0L)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${rec.personName} · ${dir.label}", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = if (rec.isSettled) "Settled" else "Remaining ${MoneyFormatters.formatMoneyExact(remaining, state.currencySymbol, state.hideAmounts)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (rec.isSettled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                                )
                            }
                            if (!rec.isSettled) {
                                OutlinedButton(onClick = { onSettleLending(rec) }, modifier = Modifier.height(36.dp)) { Text("Settle") }
                            } else {
                                Icon(Icons.Rounded.CheckCircle, contentDescription = "Settled", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { onDeleteLending(rec.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete lending", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // Savings Challenges
        Surface(
            modifier = Modifier.fillMaxWidth().testTag("challenges_card"),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.EmojiEvents, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                        Text("Savings Challenges", style = MaterialTheme.typography.titleMedium)
                    }
                    IconButton(onClick = onAddChallenge, modifier = Modifier.testTag("add_challenge_button")) {
                        Icon(Icons.Rounded.Add, contentDescription = "Start challenge")
                    }
                }
                if (state.challengeSummaries.isEmpty()) {
                    Text("Start a daily saver or no-spend challenge to build streaks.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val todayKey = DateMonthUtils.todayKey()
                    state.challengeSummaries.forEach { summary ->
                        val ch = summary.challenge
                        val isNoSpend = ch.kind.equals("NOSPEND", ignoreCase = true)
                        val doneToday = summary.cells.firstOrNull { it.dateKey == todayKey }?.isDone == true
                        val pct = (summary.completedCount.toFloat() / ch.targetDays.coerceAtLeast(1)).coerceIn(0f, 1f)

                        Surface(
                            modifier = Modifier.fillMaxWidth().testTag("challenge_item_${ch.id}"),
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(ch.title, style = MaterialTheme.typography.titleSmall)
                                            Surface(
                                                color = if (isNoSpend) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = if (isNoSpend) "NO-SPEND" else "SAVE",
                                                    style = MonoNumericTextStyle.copy(fontSize = TextUnit(9f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        val meta = buildString {
                                            append("${summary.completedCount}/${ch.targetDays}d · Streak ${summary.streak}d (Best ${summary.bestStreak}d)")
                                            if (!isNoSpend && ch.dailySaveCents > 0L) {
                                                append(" · Saved ${MoneyFormatters.formatMoney(summary.savedCents, state.currencySymbol, hidden = state.hideAmounts)}")
                                            }
                                            summary.linkedGoalName?.let { append(" · → $it") }
                                        }
                                        Text(meta, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (!isNoSpend && !summary.notStarted && !summary.isEnded) {
                                        Button(
                                            onClick = { onToggleChallengeDay(ch, todayKey) },
                                            modifier = Modifier.height(36.dp).testTag("challenge_today_btn_${ch.id}")
                                        ) {
                                            Text(if (doneToday) "Undo Today" else "Done Today")
                                        }
                                    }
                                    IconButton(onClick = { onDeleteChallenge(ch.id) }) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete challenge", modifier = Modifier.size(18.dp))
                                    }
                                }

                                LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(99.dp)))

                                // Interactive 7-column day cell grid
                                summary.cells.chunked(7).forEach { week ->
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        week.forEach { cell ->
                                            val bg = when {
                                                cell.isDone -> MaterialTheme.colorScheme.primaryContainer
                                                cell.isFuture -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f)
                                                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                                            }
                                            val cellModifier = Modifier
                                                .weight(1f)
                                                .height(30.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(bg)
                                                .then(
                                                    if (cell.isToday) Modifier.border(1.dp, MaterialTheme.colorScheme.tertiary, RoundedCornerShape(6.dp))
                                                    else Modifier
                                                )
                                                .then(
                                                    if (!isNoSpend && !cell.isFuture) Modifier.clickable { onToggleChallengeDay(ch, cell.dateKey) }
                                                    else Modifier
                                                )
                                            Box(modifier = cellModifier, contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = if (cell.isDone) "${cell.dayNumber}✓" else "${cell.dayNumber}",
                                                    style = MonoNumericTextStyle.copy(
                                                        fontSize = TextUnit(10f, TextUnitType.Sp),
                                                        fontWeight = if (cell.isDone || cell.isToday) FontWeight.Bold else FontWeight.Normal
                                                    ),
                                                    color = when {
                                                        cell.isDone -> MaterialTheme.colorScheme.onPrimaryContainer
                                                        cell.isFuture -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                                                        else -> MaterialTheme.colorScheme.onSurface
                                                    }
                                                )
                                            }
                                        }
                                        repeat(7 - week.size) { Spacer(modifier = Modifier.weight(1f)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
