package com.example.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.ThemeMode

private val LightColorScheme = lightColorScheme(
    primary = BullGreenLight,
    onPrimary = Color.White,
    primaryContainer = BullGreenSoft,
    onPrimaryContainer = Color(0xFF0E3522),
    secondary = BullGreenBright,
    onSecondary = Color.White,
    secondaryContainer = BullMist,
    onSecondaryContainer = Color(0xFF173D2B),
    tertiary = TickerGoldLight,
    onTertiary = Color.White,
    tertiaryContainer = TickerGoldSoft,
    onTertiaryContainer = Color(0xFF5A3D0C),
    error = BearRedLight,
    onError = Color.White,
    errorContainer = BearRedSoft,
    onErrorContainer = Color(0xFF6B1E1E),
    background = CanvasLight,
    onBackground = TextPrimaryLight,
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextSecondaryLight,
    outline = OutlineLight,
    outlineVariant = OutlineHairlineLight
)

private val DarkColorScheme = darkColorScheme(
    primary = BullGreenDark,
    onPrimary = Color(0xFF04140C),
    primaryContainer = BullContainerDark,
    onPrimaryContainer = Color(0xFFBDFCE0),
    secondary = Color(0xFF0FB86A),
    onSecondary = Color(0xFF04140C),
    secondaryContainer = SurfaceVariantDark,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = TickerGoldDark,
    onTertiary = Color(0xFF2B1700),
    tertiaryContainer = TickerGoldContainerDark,
    onTertiaryContainer = Color(0xFFFFE0A6),
    error = BearRedDark,
    onError = Color(0xFF2C060E),
    errorContainer = BearContainerDark,
    onErrorContainer = Color(0xFFFFBCC8),
    background = CanvasDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = OutlineDark,
    outlineVariant = OutlineHairlineDark
)

val LocalIsDarkTheme = staticCompositionLocalOf { true }

val ClearLedgerShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun CapitalxTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    CompositionLocalProvider(LocalIsDarkTheme provides isDark) {
        MaterialTheme(
            colorScheme = if (isDark) DarkColorScheme else LightColorScheme,
            typography = ClearLedgerTypography,
            shapes = ClearLedgerShapes,
            content = content
        )
    }
}

@Composable
fun TradingGlassBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalIsDarkTheme.current
    val bgColor = MaterialTheme.colorScheme.background
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        if (isDark) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Subtle radial glows matching CapitalX v9.5 Trading Glass
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(GlassEmeraldGlow, Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.04f),
                        radius = size.maxDimension * 0.45f
                    ),
                    center = Offset(size.width * 0.85f, size.height * 0.04f),
                    radius = size.maxDimension * 0.45f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(GlassBlueGlow, Color.Transparent),
                        center = Offset(size.width * 0.05f, size.height * 0.16f),
                        radius = size.maxDimension * 0.42f
                    ),
                    center = Offset(size.width * 0.05f, size.height * 0.16f),
                    radius = size.maxDimension * 0.42f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(GlassRedGlow, Color.Transparent),
                        center = Offset(size.width * 0.65f, size.height * 0.96f),
                        radius = size.maxDimension * 0.4f
                    ),
                    center = Offset(size.width * 0.65f, size.height * 0.96f),
                    radius = size.maxDimension * 0.4f
                )
                // Faint terminal grid lines
                val step = 44.dp.toPx()
                val gridStroke = Color(0x07FFFFFF)
                var x = step
                while (x < size.width) {
                    drawLine(gridStroke, Offset(x, 0f), Offset(x, size.height * 0.7f), strokeWidth = 1f)
                    x += step
                }
                var y = step
                while (y < size.height * 0.7f) {
                    drawLine(gridStroke, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += step
                }
            }
        }
        content()
    }
}
