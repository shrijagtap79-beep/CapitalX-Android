package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.data.local.AutoAddRuleEntity
import com.example.data.local.BillItemEntity
import com.example.data.local.ChallengeEntity
import com.example.data.local.GoalEntity
import com.example.data.local.LendingEntity
import com.example.data.local.SubscriptionEntity
import com.example.data.local.WalletEntity
import com.example.data.local.WalletTransferEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.WalletType
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.RepeatChargeSuggestion
import com.example.ui.components.CategoryBudgetProgressRow
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.MoneyUiState
import com.example.ui.theme.MonoNumericTextStyle

enum class HubTab(val label: String) {
    WALLETS("Wallets"),
    BUDGETS_BILLS("Budgets"),
    AUTOMATE("Automate"),
    GOALS_MORE("Goals+")
}

@Composable
fun PlanningHubScreen(
    state: MoneyUiState,
    initialTab: HubTab = HubTab.WALLETS,
    onAddWallet: () -> Unit,
    onAddMoneyToWallet: (WalletEntity) -> Unit,
    onSetRealBalance: (WalletEntity) -> Unit,
    onOpenTransferWallets: () -> Unit,
    onDeleteTransfer: (WalletTransferEntity) -> Unit,
    onOpenAddAutoAdd: () -> Unit,
    onToggleAutoAdd: (AutoAddRuleEntity) -> Unit,
    onDeleteAutoAdd: (Long) -> Unit,
    onEditCategoryBudget: (ExpenseCategory, Long, Boolean) -> Unit,
    onAddBill: () -> Unit,
    onMarkBillPaid: (BillItemEntity, Long) -> Unit,
    onDeleteBill: (Long) -> Unit,
    onAddSubscription: () -> Unit,
    onAcceptRepeatSuggestion: (RepeatChargeSuggestion) -> Unit,
    onAdvanceSubRenewal: (SubscriptionEntity) -> Unit,
    onToggleSubReminder: (SubscriptionEntity) -> Unit,
    onDeleteSub: (Long) -> Unit,
    onImporterTextChange: (String) -> Unit,
    onLoadTemplate: () -> Unit,
    onParseSample: () -> Unit,
    onToggleDraftSelected: (Int) -> Unit,
    onCommitImport: () -> Unit,
    onClearImporter: () -> Unit,
    onOpenAddRule: () -> Unit,
    onToggleRule: (Long, Boolean) -> Unit,
    onDeleteRule: (Long) -> Unit,
    onReRunRules: () -> Unit,
    onOpenAddRecurring: () -> Unit,
    onToggleRecurring: (Long, Boolean) -> Unit,
    onDeleteRecurring: (Long) -> Unit,
    onSyncRecurringNow: () -> Unit,
    onAddGoal: () -> Unit,
    onContributeGoal: (GoalEntity) -> Unit,
    onDeleteGoal: (Long) -> Unit,
    onAddLending: () -> Unit,
    onSettleLending: (LendingEntity) -> Unit,
    onDeleteLending: (Long) -> Unit,
    onAddChallenge: () -> Unit,
    onToggleChallengeDay: (ChallengeEntity, String) -> Unit,
    onDeleteChallenge: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(initialTab) { mutableStateOf(initialTab) }
    val context = LocalContext.current
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val content = try {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (_: Exception) { null }
            if (!content.isNullOrBlank()) {
                onImporterTextChange(content)
                onParseSample()
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("planning_hub_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Wealth & Planning Hub", style = MaterialTheme.typography.headlineSmall)
        }

        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                HubTab.entries.forEachIndexed { idx, tab ->
                    SegmentedButton(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        shape = SegmentedButtonDefaults.itemShape(idx, HubTab.entries.size)
                    ) { Text(tab.label, maxLines = 1) }
                }
            }
        }

        when (selectedTab) {
            HubTab.WALLETS -> {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().testTag("wallets_overview_card"),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(18.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Total Wallet Liquidity", style = MaterialTheme.typography.labelMedium)
                                Text(
                                    text = MoneyFormatters.formatMoneyExact(state.totalWalletBalanceCents, state.currencySymbol, state.hideAmounts),
                                    style = MonoNumericTextStyle.copy(fontSize = TextUnit(24f, TextUnitType.Sp), fontWeight = FontWeight.Bold)
                                )
                            }
                            FilledTonalButton(onClick = onAddWallet, modifier = Modifier.testTag("add_wallet_button")) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Wallet")
                            }
                        }
                    }
                }

                item {
                    val walletById = remember(state.wallets) { state.wallets.associateBy { it.id } }
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        state.walletAnalytics.forEach { item ->
                            val wt = WalletType.fromRaw(item.wallet.walletType)
                            val isNegative = item.wallet.balanceCents < 0L
                            Surface(
                                modifier = Modifier.fillMaxWidth().testTag("wallet_card_${item.wallet.id}"),
                                shape = MaterialTheme.shapes.medium,
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (isNegative) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant
                                )
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Icon(wt.icon, contentDescription = wt.label, tint = MaterialTheme.colorScheme.primary)
                                            Column {
                                                Text(item.wallet.name, style = MaterialTheme.typography.titleSmall)
                                                Text("${wt.label} · ${item.txnCount} txns", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                        Text(
                                            text = MoneyFormatters.formatMoneyExact(item.wallet.balanceCents, state.currencySymbol, state.hideAmounts),
                                            style = MonoNumericTextStyle.copy(fontSize = TextUnit(15f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                            color = if (isNegative) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Text(
                                        text = "In ${MoneyFormatters.formatCompact(item.inflowCents, state.currencySymbol, state.hideAmounts)} · Out ${MoneyFormatters.formatCompact(item.outflowCents, state.currencySymbol, state.hideAmounts)}",
                                        style = MonoNumericTextStyle.copy(fontSize = TextUnit(11f, TextUnitType.Sp)),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { onSetRealBalance(item.wallet) },
                                            modifier = Modifier.weight(1f).height(40.dp).testTag("real_balance_button_${item.wallet.id}")
                                        ) {
                                            Icon(Icons.Rounded.TrackChanges, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Real Balance", maxLines = 1)
                                        }
                                        FilledTonalButton(
                                            onClick = { onAddMoneyToWallet(item.wallet) },
                                            modifier = Modifier.weight(1f).height(40.dp).testTag("add_money_button_${item.wallet.id}")
                                        ) {
                                            Text("+ Add Money", maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }

                        // Wallet-to-Wallet Transfers Card
                        Surface(
                            modifier = Modifier.fillMaxWidth().testTag("wallet_transfers_card"),
                            shape = MaterialTheme.shapes.large,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Text("Wallet Transfers", style = MaterialTheme.typography.titleMedium)
                                    }
                                    FilledTonalButton(
                                        onClick = onOpenTransferWallets,
                                        enabled = state.wallets.size >= 2,
                                        modifier = Modifier.height(38.dp).testTag("open_transfer_button")
                                    ) { Text("⇄ Transfer") }
                                }
                                if (state.wallets.size < 2) {
                                    Text("Create at least 2 wallets to transfer funds.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else if (state.transfers.isEmpty()) {
                                    Text("No wallet transfers yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    state.transfers.take(8).forEach { tr ->
                                        val fromName = walletById[tr.fromWalletId]?.name ?: "Wallet"
                                        val toName = walletById[tr.toWalletId]?.name ?: "Wallet"
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("$fromName → $toName", style = MaterialTheme.typography.titleSmall)
                                                Text(
                                                    text = "${DateMonthUtils.formatFullDate(tr.dateMillis)}${if (tr.note.isNotBlank()) " · ${tr.note}" else ""}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Text(
                                                text = MoneyFormatters.formatMoneyExact(tr.amountCents, state.currencySymbol, state.hideAmounts),
                                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(13f, TextUnitType.Sp), fontWeight = FontWeight.Bold)
                                            )
                                            IconButton(
                                                onClick = { onDeleteTransfer(tr) },
                                                modifier = Modifier.testTag("delete_transfer_${tr.id}")
                                            ) {
                                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Revert transfer", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Auto-Add Money Schedules Card
                        Surface(
                            modifier = Modifier.fillMaxWidth().testTag("auto_add_schedules_card"),
                            shape = MaterialTheme.shapes.large,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Rounded.Repeat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Text("Auto-Add Schedules", style = MaterialTheme.typography.titleMedium)
                                    }
                                    IconButton(
                                        onClick = onOpenAddAutoAdd,
                                        enabled = state.wallets.isNotEmpty(),
                                        modifier = Modifier.testTag("open_auto_add_button")
                                    ) {
                                        Icon(Icons.Rounded.Add, contentDescription = "Add auto-add schedule")
                                    }
                                }
                                if (state.autoAddSchedules.isEmpty()) {
                                    Text(
                                        "Automatically top up Cash/UPI/Bank on a daily, weekly, or monthly cadence.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    state.autoAddSchedules.forEach { rule ->
                                        val wName = walletById[rule.walletId]?.name ?: "Wallet"
                                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    "$wName · ${MoneyFormatters.formatMoneyExact(rule.amountCents, state.currencySymbol, state.hideAmounts)}",
                                                    style = MaterialTheme.typography.titleSmall
                                                )
                                                Text(
                                                    "${rule.frequency.lowercase().replaceFirstChar { it.uppercase() }} · Next ${rule.nextDateKey}${if (rule.note.isNotBlank()) " · ${rule.note}" else ""}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Switch(checked = rule.isActive, onCheckedChange = { onToggleAutoAdd(rule) })
                                            IconButton(onClick = { onDeleteAutoAdd(rule.id) }) {
                                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete schedule", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HubTab.BUDGETS_BILLS -> {
                item {
                    BillCalendarSection(
                        state = state,
                        onAddBill = onAddBill,
                        onMarkBillPaid = onMarkBillPaid,
                        onDeleteBill = onDeleteBill
                    )
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().testTag("rollover_budgets_card"),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Category Budgets & Rollover", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Tap any category to set limit and toggle unspent amount rollover.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            state.categoryBreakdowns.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CategoryBudgetProgressRow(
                                        item = item,
                                        currencySymbol = state.currencySymbol,
                                        hideAmounts = state.hideAmounts,
                                        showLastMonthDelta = true,
                                        onClick = { onEditCategoryBudget(item.category, item.baseBudgetCents, item.rolloverEnabled) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { onEditCategoryBudget(item.category, item.baseBudgetCents, item.rolloverEnabled) }) {
                                        Icon(Icons.Rounded.Edit, contentDescription = "Edit budget", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HubTab.AUTOMATE -> {
                item {
                    SubscriptionsAndDetectorSection(
                        state = state,
                        onAddSubscription = onAddSubscription,
                        onAcceptSuggestion = onAcceptRepeatSuggestion,
                        onAdvanceRenewal = onAdvanceSubRenewal,
                        onToggleReminder = onToggleSubReminder,
                        onDeleteSubscription = onDeleteSub
                    )
                }

                // Sample / CSV / SMS Batch Importer
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().testTag("sample_importer_card"),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Sample / CSV / SMS Batch Importer", style = MaterialTheme.typography.titleMedium)
                                if (state.importer.rawText.isNotEmpty()) {
                                    TextButton(onClick = onClearImporter) { Text("Clear") }
                                }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { filePicker.launch(arrayOf("text/*", "text/csv")) },
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Icon(Icons.Rounded.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Open File")
                                }
                                OutlinedButton(onClick = onLoadTemplate, modifier = Modifier.weight(1f).height(44.dp)) {
                                    Text("Sample Format")
                                }
                            }
                            OutlinedTextField(
                                value = state.importer.rawText,
                                onValueChange = onImporterTextChange,
                                placeholder = { Text("Paste CSV rows, Bank/UPI SMS, or lines…") },
                                minLines = 3,
                                maxLines = 6,
                                modifier = Modifier.fillMaxWidth().testTag("sample_text_input")
                            )
                            Button(
                                onClick = onParseSample,
                                enabled = state.importer.rawText.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("parse_sample_button")
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Parse & Auto-Match")
                            }
                            if (state.importer.drafts.isNotEmpty()) {
                                val selectedCount = state.importer.drafts.count { it.isSelected }
                                state.importer.drafts.forEach { d ->
                                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = d.isSelected, onCheckedChange = { onToggleDraftSelected(d.id) })
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(d.merchant, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("${d.transactionType.label} · ${d.category.shortName}", style = MaterialTheme.typography.labelSmall, color = d.category.color)
                                        }
                                        Text(
                                            MoneyFormatters.formatMoneyExact(d.amountCents, state.currencySymbol, state.hideAmounts),
                                            style = MonoNumericTextStyle.copy(fontSize = TextUnit(12f, TextUnitType.Sp), fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                                Button(
                                    onClick = onCommitImport,
                                    enabled = selectedCount > 0,
                                    modifier = Modifier.fillMaxWidth().height(46.dp).testTag("commit_import_button")
                                ) {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Import $selectedCount Item(s)")
                                }
                            }
                        }
                    }
                }

                // Auto-Add & Categorization Rules + Recurring
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().testTag("auto_rules_card"),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Auto-Add & Category Rules", style = MaterialTheme.typography.titleMedium)
                                }
                                IconButton(onClick = onOpenAddRule) { Icon(Icons.Rounded.Add, contentDescription = "Add rule") }
                            }
                            OutlinedButton(onClick = onReRunRules, modifier = Modifier.fillMaxWidth().height(44.dp)) {
                                Text("Re-run Rules on Uncategorized")
                            }
                            state.autoRules.take(12).forEach { r ->
                                val cat = ExpenseCategory.fromRaw(r.category)
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(cat.color))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("\"${r.keyword}\" → ${cat.shortName}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                    Switch(checked = r.isEnabled, onCheckedChange = { onToggleRule(r.id, it) })
                                    if (!r.isBuiltIn) {
                                        IconButton(onClick = { onDeleteRule(r.id) }) { Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete rule", modifier = Modifier.size(18.dp)) }
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().testTag("recurring_expenses_card"),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Rounded.Repeat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Monthly Recurring Rules", style = MaterialTheme.typography.titleMedium)
                                }
                                IconButton(onClick = onOpenAddRecurring) { Icon(Icons.Rounded.Add, contentDescription = "Add recurring") }
                            }
                            state.recurringExpenses.forEach { rec ->
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(rec.merchant, style = MaterialTheme.typography.titleSmall)
                                        Text("Day ${rec.dayOfMonth} · ${MoneyFormatters.formatMoneyExact(rec.amountCents, state.currencySymbol, state.hideAmounts)}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Switch(checked = rec.isActive, onCheckedChange = { onToggleRecurring(rec.id, it) })
                                    IconButton(onClick = { onDeleteRecurring(rec.id) }) { Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete recurring", modifier = Modifier.size(18.dp)) }
                                }
                            }
                            if (state.recurringExpenses.isNotEmpty()) {
                                OutlinedButton(onClick = onSyncRecurringNow, modifier = Modifier.fillMaxWidth().height(44.dp)) {
                                    Icon(Icons.Rounded.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sync Recurring for ${state.monthTitle}")
                                }
                            }
                        }
                    }
                }
            }

            HubTab.GOALS_MORE -> {
                item {
                    GoalsLendingChallengesSection(
                        state = state,
                        onAddGoal = onAddGoal,
                        onContributeGoal = onContributeGoal,
                        onDeleteGoal = onDeleteGoal,
                        onAddLending = onAddLending,
                        onSettleLending = onSettleLending,
                        onDeleteLending = onDeleteLending,
                        onAddChallenge = onAddChallenge,
                        onToggleChallengeDay = onToggleChallengeDay,
                        onDeleteChallenge = onDeleteChallenge
                    )
                }
            }
        }
    }
}
