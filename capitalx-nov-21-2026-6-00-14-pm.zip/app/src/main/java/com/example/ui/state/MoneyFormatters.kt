package com.example.ui.state

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

object MoneyFormatters {
    fun formatMoney(
        cents: Long,
        symbol: String = "$",
        includeSign: Boolean = false,
        hidden: Boolean = false
    ): String {
        if (hidden) return "$symbol ••••"
        val absDollars = abs(cents) / 100.0
        val formatter = NumberFormat.getNumberInstance(Locale.US).apply {
            minimumFractionDigits = if (abs(cents) % 100L == 0L && abs(cents) >= 100_000L) 0 else 2
            maximumFractionDigits = 2
        }
        val formatted = formatter.format(absDollars)
        val prefix = when {
            cents < 0L -> "-$symbol"
            includeSign && cents > 0L -> "+$symbol"
            else -> symbol
        }
        return "$prefix$formatted"
    }

    fun formatMoneyExact(cents: Long, symbol: String = "$", hidden: Boolean = false): String {
        if (hidden) return "$symbol ••••"
        val absDollars = abs(cents) / 100.0
        val formatter = NumberFormat.getNumberInstance(Locale.US).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        val sign = if (cents < 0L) "-" else ""
        return "$sign$symbol${formatter.format(absDollars)}"
    }

    fun formatCompact(cents: Long, symbol: String = "$", hidden: Boolean = false): String {
        if (hidden) return "$symbol •••"
        val dollars = abs(cents) / 100.0
        return when {
            dollars >= 1_000_000 -> "$symbol${String.format(Locale.US, "%.1fM", dollars / 1_000_000)}"
            dollars >= 1_000 -> "$symbol${String.format(Locale.US, "%.1fk", dollars / 1_000)}"
            else -> "$symbol${dollars.toInt()}"
        }
    }
}
