package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.data.local.ExpenseEntity
import com.example.data.model.DashboardWidget
import com.example.data.parser.DateMonthUtils
import com.example.ui.components.CategoryBudgetProgressRow
import com.example.ui.components.CategoryDonutChartCard
import com.example.ui.components.DailyExpenseTrendChartCard
import com.example.ui.components.EmptyLedgerHero
import com.example.ui.components.ExpenseRowCard
import com.example.ui.components.IncomeVsExpenseChartCard
import com.example.ui.components.MarketTickerTape
import com.example.ui.components.MonthSwitcherHeader
import com.example.ui.state.MoneyFormatters
import com.example.ui.state.MoneyUiState
import com.example.ui.theme.MonoNumericTextStyle
import kotlin.math.abs

@Composable
fun OverviewScreen(
    state: MoneyUiState,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onJumpCurrentMonth: () -> Unit,
    onToggleHideAmounts: () -> Unit,
    onLockNow: () -> Unit,
    onCustomizeWidgets: () -> Unit,
    onAddExpenseClick: () -> Unit,
    onOpenImporter: () -> Unit,
    onOpenAllExpenses: () -> Unit,
    onOpenBudgets: () -> Unit,
    onOpenWalletsTab: () -> Unit = {},
    onOpenGoalsTab: () -> Unit = {},
    onOpenSettingsBackup: () -> Unit,
    onEditExpense: (ExpenseEntity) -> Unit,
    onDuplicateExpense: ((ExpenseEntity) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isCurrentMonth = state.selectedYearMonth == DateMonthUtils.currentYearMonth()
    val hasPin = !state.activeAccount?.pinHash.isNullOrBlank()
    val walletMap = state.wallets.associateBy { it.id }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("overview_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            MonthSwitcherHeader(
                monthTitle = state.monthTitle,
                isCurrentMonth = isCurrentMonth,
                hideAmounts = state.hideAmounts,
                hasPinLock = hasPin,
                onToggleHideAmounts = onToggleHideAmounts,
                onLockNow = onLockNow,
                onPreviousMonth = onPreviousMonth,
                onNextMonth = onNextMonth,
                onJumpCurrent = onJumpCurrentMonth
            )
        }

        if (state.tickerItems.isNotEmpty()) {
            item {
                MarketTickerTape(items = state.tickerItems)
            }
        }

        // Budget Alerts at 80% and over 100%
        if (state.budgetAlertLevel > 0) {
            item {
                val isOver = state.budgetAlertLevel >= 2
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("budget_alert_banner"),
                    shape = MaterialTheme.shapes.medium,
                    color = if (isOver) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.tertiaryContainer,
                    border = BorderStroke(1.dp, if (isOver) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Warning,
                            contentDescription = "Budget Alert",
                            tint = if (isOver) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isOver) "OVER 100% BUDGET ALERT" else "80% BUDGET THRESHOLD ALERT",
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(11f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                color = if (isOver) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            Text(
                                text = if (isOver) "Spending exceeded monthly budget by ${MoneyFormatters.formatMoney(-state.remainingCents, state.currencySymbol, hidden = state.hideAmounts)}."
                                else "You've used ${((state.totalSpentCents.toFloat() / state.totalBudgetCents) * 100).toInt()}% of this month's budget.",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isOver) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }
            }
        }

        // Pace Projection Warning (CapitalX v9.5)
        if (state.paceOverBudgetWarning && state.budgetAlertLevel < 2) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("pace_warning_banner"),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.72f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.TrendingUp, contentDescription = "Pace projection alert", tint = MaterialTheme.colorScheme.tertiary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "PACE PROJECTION WARNING",
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(11f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            Text(
                                text = "At this pace, month-end spend projects to ${MoneyFormatters.formatMoney(state.projectedMonthEndCents, state.currencySymbol, hidden = state.hideAmounts)} vs ${MoneyFormatters.formatMoney(state.totalBudgetCents, state.currencySymbol, hidden = state.hideAmounts)} cap.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }
            }
        }

        // Overdue Lending Alert (CapitalX v9.5)
        if (state.overdueLendingCount > 0) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("overdue_lending_banner"),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary),
                    onClick = onOpenGoalsTab
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.Schedule, contentDescription = "Overdue lending", tint = MaterialTheme.colorScheme.tertiary)
                        Text(
                            text = "${state.overdueLendingCount} overdue lending record(s) past due date.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Text("Review", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Negative Wallet Alert (CapitalX v9.5)
        if (state.negativeWallets.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("negative_wallet_banner"),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.errorContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                    onClick = onOpenWalletsTab
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = "Negative wallet balance", tint = MaterialTheme.colorScheme.error)
                        val names = state.negativeWallets.joinToString(", ") {
                            "${it.name} (${MoneyFormatters.formatMoneyExact(it.balanceCents, state.currencySymbol, state.hideAmounts)})"
                        }
                        Text(
                            text = "Negative wallet balance: $names",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        Text("Fix", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        // Weekly backup nudge
        if (state.showWeeklyBackupNudge) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("weekly_backup_nudge"),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    onClick = onOpenSettingsBackup
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "Weekly Backup Nudge: Export an encrypted or JSON backup in Vault.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Text("Backup", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Hero Portfolio / Budget Ticker Card
        item {
            HeroMarketBudgetCard(state = state, onOpenBudgets = onOpenBudgets, onOpenImporter = onOpenImporter)
        }

        // Customizable KPI Widget Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Market Widgets", style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = onCustomizeWidgets, modifier = Modifier.testTag("customize_widgets_button")) {
                        Icon(Icons.Rounded.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Customize")
                    }
                }

                val activeList = DashboardWidget.entries.filter { state.visibleWidgets.contains(it) }
                activeList.chunked(2).forEach { pair ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { widget ->
                            DashboardWidgetCard(
                                widget = widget,
                                state = state,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        if (state.monthTransactions.isEmpty()) {
            item {
                EmptyLedgerHero(
                    onAddExpense = onAddExpenseClick,
                    onGoToImport = onOpenImporter
                )
            }
        }

        // Daily Expense Trend Chart
        item {
            DailyExpenseTrendChartCard(
                dailyPoints = state.dailyPoints,
                dailyTargetCents = state.dailyTargetCents,
                currencySymbol = state.currencySymbol,
                hideAmounts = state.hideAmounts,
                monthTitle = state.monthTitle,
                monthTransactions = state.monthTransactions
            )
        }

        // Income vs Expenses Chart (Last 6 Months)
        item {
            IncomeVsExpenseChartCard(
                title = "Income vs Expenses (6M)",
                points = state.last6MonthsCashflow,
                currencySymbol = state.currencySymbol,
                hideAmounts = state.hideAmounts
            )
        }

        // Sector Allocation Donut
        item {
            CategoryDonutChartCard(
                breakdowns = state.categoryBreakdowns,
                totalSpentCents = state.totalSpentCents,
                currencySymbol = state.currencySymbol,
                hideAmounts = state.hideAmounts
            )
        }

        // Coming Up Next 30 Days
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("coming_up_card"),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Coming Up · Next 30 Days", style = MaterialTheme.typography.titleMedium)
                    }
                    if (state.comingUp30Days.isEmpty()) {
                        Text(
                            text = "No upcoming subscriptions or bills due in the next 30 days.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        state.comingUp30Days.take(6).forEach { up ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(up.title, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = "${up.subtitle} · in ${up.daysLeft}d",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (up.daysLeft <= 3) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = MoneyFormatters.formatMoneyExact(up.amountCents, state.currencySymbol, state.hideAmounts),
                                    style = MonoNumericTextStyle.copy(fontSize = TextUnit(13f, TextUnitType.Sp), fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Top Categories + Category vs Last Month
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Top Categories", style = MaterialTheme.typography.titleMedium)
                            Text("With rollover & vs last month delta", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = onOpenBudgets) { Text("Budgets") }
                    }
                    state.categoryBreakdowns.take(5).forEach { item ->
                        CategoryBudgetProgressRow(
                            item = item,
                            currencySymbol = state.currencySymbol,
                            hideAmounts = state.hideAmounts,
                            showLastMonthDelta = true,
                            onClick = onOpenBudgets
                        )
                    }
                }
            }
        }

        if (state.monthTransactions.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Tape", style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = onOpenAllExpenses) { Text("All (${state.monthTransactions.size})") }
                }
            }
            items(state.monthTransactions.take(5), key = { it.id }) { txn ->
                ExpenseRowCard(
                    expense = txn,
                    currencySymbol = state.currencySymbol,
                    baseCurrencyCode = state.currencyCode,
                    hideAmounts = state.hideAmounts,
                    splits = state.splitsByTransactionId[txn.id].orEmpty(),
                    walletName = walletMap[txn.walletId]?.name,
                    onClick = { onEditExpense(txn) },
                    onDuplicate = onDuplicateExpense?.let { fn -> { fn(txn) } }
                )
            }
        }
    }
}

@Composable
private fun HeroMarketBudgetCard(
    state: MoneyUiState,
    onOpenBudgets: () -> Unit,
    onOpenImporter: () -> Unit
) {
    val utilization = (state.totalSpentCents.toFloat() / state.totalBudgetCents.toFloat()).coerceAtLeast(0f)
    val animatedFill by animateFloatAsState(
        targetValue = utilization.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "hero_fill"
    )
    val isOver = state.remainingCents < 0L
    val deltaFromLastMonth = state.totalSpentCents - state.previousMonthSpentCents
    val deltaPct = if (state.previousMonthSpentCents > 0L) {
        ((deltaFromLastMonth.toFloat() / state.previousMonthSpentCents.toFloat()) * 100f).toInt()
    } else 0

    Surface(
        modifier = Modifier.fillMaxWidth().testTag("hero_budget_card"),
        shape = MaterialTheme.shapes.extraLarge,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.secondaryContainer
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            text = if (isOver) "BUDGET DEFICIT" else "BUDGET LIQUIDITY",
                            style = MonoNumericTextStyle.copy(fontSize = TextUnit(11f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Text(
                            text = MoneyFormatters.formatMoney(abs(state.remainingCents), state.currencySymbol, hidden = state.hideAmounts),
                            style = MonoNumericTextStyle.copy(fontSize = TextUnit(30f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                            color = if (isOver) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        if (state.previousMonthSpentCents > 0L) {
                            val badgeColor = if (deltaFromLastMonth > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            Text(
                                text = "${if (deltaFromLastMonth >= 0) "▲ +" else "▼ "}$deltaPct% spend vs last mo",
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(11f, TextUnitType.Sp), fontWeight = FontWeight.SemiBold),
                                color = badgeColor
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(12.dp),
                        onClick = onOpenBudgets
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), horizontalAlignment = Alignment.End) {
                            Text("Today's Spend", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = MoneyFormatters.formatMoneyExact(state.todaySpentCents, state.currencySymbol, state.hideAmounts),
                                style = MonoNumericTextStyle.copy(fontSize = TextUnit(13f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(99.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.45f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedFill)
                            .height(10.dp)
                            .clip(RoundedCornerShape(99.dp))
                            .background(
                                when {
                                    utilization > 1f -> MaterialTheme.colorScheme.error
                                    utilization >= 0.8f -> MaterialTheme.colorScheme.tertiary
                                    else -> MaterialTheme.colorScheme.primary
                                }
                            )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Out ${MoneyFormatters.formatMoney(state.totalSpentCents, state.currencySymbol, hidden = state.hideAmounts)} / ${MoneyFormatters.formatCompact(state.totalBudgetCents, state.currencySymbol, state.hideAmounts)}",
                        style = MonoNumericTextStyle.copy(fontSize = TextUnit(12f, TextUnitType.Sp)),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    FilledTonalButton(onClick = onOpenImporter, modifier = Modifier.height(40.dp)) {
                        Text("Import SMS/CSV")
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardWidgetCard(
    widget: DashboardWidget,
    state: MoneyUiState,
    modifier: Modifier = Modifier
) {
    val (valueText, subText, accentColor) = when (widget) {
        DashboardWidget.SAFE_TO_SPEND -> Triple(
            MoneyFormatters.formatMoney(state.safeToSpendTodayCents, state.currencySymbol, hidden = state.hideAmounts),
            "Per day remaining",
            MaterialTheme.colorScheme.primary
        )
        DashboardWidget.MONTH_END_FORECAST -> Triple(
            MoneyFormatters.formatMoney(state.projectedMonthEndCents, state.currencySymbol, hidden = state.hideAmounts),
            if (state.projectedMonthEndCents > state.totalBudgetCents) "Above budget pace" else "Within budget pace",
            if (state.projectedMonthEndCents > state.totalBudgetCents) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
        )
        DashboardWidget.NET_THIS_MONTH -> Triple(
            MoneyFormatters.formatMoney(state.netThisMonthCents, state.currencySymbol, includeSign = true, hidden = state.hideAmounts),
            "In ${MoneyFormatters.formatCompact(state.totalIncomeCents, state.currencySymbol, state.hideAmounts)} · Out ${MoneyFormatters.formatCompact(state.totalSpentCents, state.currencySymbol, state.hideAmounts)}",
            if (state.netThisMonthCents >= 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
        DashboardWidget.BUDGET_USED -> {
            val pct = ((state.totalSpentCents.toFloat() / state.totalBudgetCents.toFloat()) * 100f).toInt()
            Triple(
                "$pct%",
                "${state.monthTransactions.size} txns this month",
                when {
                    pct > 100 -> MaterialTheme.colorScheme.error
                    pct >= 80 -> MaterialTheme.colorScheme.tertiary
                    else -> MaterialTheme.colorScheme.primary
                }
            )
        }
    }

    Surface(
        modifier = modifier.testTag("widget_${widget.key}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = widget.label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = valueText,
                style = MonoNumericTextStyle.copy(fontSize = TextUnit(17f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                color = accentColor
            )
            Text(
                text = subText,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
