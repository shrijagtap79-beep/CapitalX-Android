package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.CandlestickChart
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import com.example.data.local.LocalAccountEntity
import com.example.ui.theme.MonoNumericTextStyle
import kotlinx.coroutines.delay

private enum class AuthTab(val label: String) {
    LOGIN("Log In"),
    SIGN_UP("Sign Up"),
    FORGOT("Forgot")
}

@Composable
fun LocalAuthScreen(
    knownUsernames: List<String>,
    authError: String?,
    onClearError: () -> Unit,
    onLogin: (username: String, password: String) -> Unit,
    onSignUp: (displayName: String, username: String, password: String) -> Unit,
    onForgotPasswordReset: (username: String, newPassword: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var tab by remember(knownUsernames) {
        mutableStateOf(if (knownUsernames.isEmpty()) AuthTab.SIGN_UP else AuthTab.LOGIN)
    }
    var displayName by remember { mutableStateOf("") }
    var username by remember(knownUsernames) { mutableStateOf(knownUsernames.firstOrNull().orEmpty()) }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showConfirmPassword by remember { mutableStateOf(false) }
    var confirmResetDialog by remember { mutableStateOf(false) }

    val needsConfirm = tab == AuthTab.SIGN_UP || tab == AuthTab.FORGOT
    val passwordsMatch = !needsConfirm || password == confirmPassword

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 460.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Icon(
                    imageVector = Icons.Rounded.CandlestickChart,
                    contentDescription = "Capitalx terminal",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(14.dp).size(36.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "CAPITALX",
                    style = MonoNumericTextStyle.copy(fontSize = TextUnit(24f, TextUnitType.Sp), fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Offline Personal Wealth & Budget Terminal",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                AuthTab.entries.forEachIndexed { idx, t ->
                    SegmentedButton(
                        selected = tab == t,
                        onClick = {
                            tab = t
                            confirmPassword = ""
                            onClearError()
                        },
                        shape = SegmentedButtonDefaults.itemShape(idx, AuthTab.entries.size)
                    ) { Text(t.label) }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (knownUsernames.isNotEmpty() && tab != AuthTab.SIGN_UP) {
                        Text("Local Accounts", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            knownUsernames.forEach { user ->
                                FilterChip(
                                    selected = username.equals(user, ignoreCase = true),
                                    onClick = { username = user; onClearError() },
                                    label = { Text(user) }
                                )
                            }
                        }
                    }

                    if (tab == AuthTab.SIGN_UP) {
                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it; onClearError() },
                            label = { Text("Display Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("auth_display_name_input")
                        )
                    }

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it; onClearError() },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("auth_username_input")
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; onClearError() },
                        label = {
                            Text(if (tab == AuthTab.FORGOT) "New Password (min 6 chars)" else "Password (min 6 chars)")
                        },
                        singleLine = true,
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(
                                onClick = { showPassword = !showPassword },
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("auth_password_visibility_toggle")
                            ) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (showPassword) "Hide password" else "Show password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("auth_password_input")
                    )

                    if (needsConfirm) {
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it; onClearError() },
                            label = { Text("Confirm Password") },
                            singleLine = true,
                            isError = confirmPassword.isNotEmpty() && !passwordsMatch,
                            visualTransformation = if (showConfirmPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(
                                    onClick = { showConfirmPassword = !showConfirmPassword },
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("auth_confirm_visibility_toggle")
                                ) {
                                    Icon(
                                        imageVector = if (showConfirmPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                        contentDescription = if (showConfirmPassword) "Hide confirm password" else "Show confirm password"
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("auth_confirm_password_input")
                        )
                        if (confirmPassword.isNotEmpty() && !passwordsMatch) {
                            Text(
                                text = "Passwords do not match.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    if (tab == AuthTab.FORGOT) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Rounded.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Text(
                                    text = "Warning: Resetting a forgotten local password permanently deletes all transactions, wallets, goals, and budgets for that account.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }

                    if (!authError.isNullOrBlank()) {
                        Text(
                            text = authError,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Button(
                        onClick = {
                            when (tab) {
                                AuthTab.LOGIN -> onLogin(username, password)
                                AuthTab.SIGN_UP -> onSignUp(displayName, username, password)
                                AuthTab.FORGOT -> confirmResetDialog = true
                            }
                        },
                        enabled = username.trim().length >= 3 && password.length >= 6 &&
                            passwordsMatch &&
                            (tab != AuthTab.SIGN_UP || displayName.isNotBlank()),
                        colors = if (tab == AuthTab.FORGOT) {
                            ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        } else ButtonDefaults.buttonColors(),
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("auth_submit_button")
                    ) {
                        Text(
                            when (tab) {
                                AuthTab.LOGIN -> "Unlock Ledger"
                                AuthTab.SIGN_UP -> "Create Local Account"
                                AuthTab.FORGOT -> "Reset Password & Wipe Data"
                            }
                        )
                    }
                }
            }
        }
    }

    if (confirmResetDialog) {
        AlertDialog(
            onDismissRequest = { confirmResetDialog = false },
            title = { Text("Delete Account Data & Reset?") },
            text = {
                Text(
                    "All transactions, wallets, splits, goals, lending records, and budgets for \"$username\" will be permanently erased before setting your new password."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmResetDialog = false
                        onForgotPasswordReset(username, password)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Yes, Delete & Reset") }
            },
            dismissButton = {
                TextButton(onClick = { confirmResetDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun PinLockScreen(
    account: LocalAccountEntity,
    pinError: String?,
    onVerifyPin: (String) -> Unit,
    onForgotPinWithPassword: (String) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pinInput by remember { mutableStateOf("") }
    var showForgotPin by remember { mutableStateOf(false) }
    var forgotPasswordInput by remember { mutableStateOf("") }
    var showForgotPwText by remember { mutableStateOf(false) }
    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }

    val lockoutRemainingSec = ((account.pinLockoutUntilMillis - nowMillis) / 1000L).coerceAtLeast(0L)
    LaunchedEffect(account.pinLockoutUntilMillis) {
        while (System.currentTimeMillis() < account.pinLockoutUntilMillis) {
            nowMillis = System.currentTimeMillis()
            delay(500L)
        }
        nowMillis = System.currentTimeMillis()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = "Locked", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                }
                Text("Capitalx Locked", style = MaterialTheme.typography.headlineSmall)
                Text(
                    text = "Signed in as ${account.displayName} (@${account.username})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Masked PIN dot indicators (4 to 8 digits)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("pin_dots_display")
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 14.dp, horizontal = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(8) { idx ->
                                val filled = idx < pinInput.length
                                Box(
                                    modifier = Modifier
                                        .size(if (filled) 12.dp else 9.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                filled -> MaterialTheme.colorScheme.primary
                                                idx < 4 -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
                                                else -> MaterialTheme.colorScheme.outlineVariant
                                            }
                                        )
                                )
                            }
                        }
                        Text(
                            text = if (pinInput.isEmpty()) "Enter 4–8 digit PIN" else "${pinInput.length} / 8 digits",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // On-screen 0–9 Numeric Keypad
                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("CLEAR", "0", "BACK")
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    rows.forEach { rowKeys ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowKeys.forEach { key ->
                                FilledTonalButton(
                                    onClick = {
                                        when (key) {
                                            "CLEAR" -> pinInput = ""
                                            "BACK" -> if (pinInput.isNotEmpty()) pinInput = pinInput.dropLast(1)
                                            else -> if (pinInput.length < 8) pinInput += key
                                        }
                                    },
                                    enabled = lockoutRemainingSec == 0L,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(52.dp)
                                        .testTag("pin_key_${key.lowercase()}")
                                ) {
                                    when (key) {
                                        "CLEAR" -> Text("Clear", style = MaterialTheme.typography.labelLarge)
                                        "BACK" -> Icon(
                                            Icons.AutoMirrored.Rounded.Backspace,
                                            contentDescription = "Delete digit",
                                            modifier = Modifier.size(20.dp)
                                        )
                                        else -> Text(
                                            key,
                                            style = MonoNumericTextStyle.copy(
                                                fontSize = TextUnit(18f, TextUnitType.Sp),
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (lockoutRemainingSec > 0L) {
                    Text(
                        text = "Too many wrong attempts. Try again in ${lockoutRemainingSec}s.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                } else if (!pinError.isNullOrBlank()) {
                    Text(pinError, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }

                Button(
                    onClick = { onVerifyPin(pinInput); pinInput = "" },
                    enabled = lockoutRemainingSec == 0L && pinInput.length in 4..8,
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("pin_unlock_button")
                ) { Text("Unlock Capitalx") }

                TextButton(
                    onClick = { showForgotPin = !showForgotPin },
                    modifier = Modifier.testTag("forgot_pin_toggle_button")
                ) {
                    Text(if (showForgotPin) "Hide Forgot PIN" else "Forgot PIN?")
                }

                if (showForgotPin) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "Verify your account password to clear the PIN without deleting your data.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = forgotPasswordInput,
                                onValueChange = { forgotPasswordInput = it },
                                label = { Text("Account Password") },
                                singleLine = true,
                                visualTransformation = if (showForgotPwText) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(
                                        onClick = { showForgotPwText = !showForgotPwText },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(
                                            if (showForgotPwText) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                            contentDescription = if (showForgotPwText) "Hide password" else "Show password"
                                        )
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                modifier = Modifier.fillMaxWidth().testTag("forgot_pin_password_input")
                            )
                            Button(
                                onClick = {
                                    onForgotPinWithPassword(forgotPasswordInput)
                                    forgotPasswordInput = ""
                                },
                                enabled = forgotPasswordInput.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("forgot_pin_verify_button")
                            ) { Text("Verify Password & Reset PIN") }
                        }
                    }
                }

                OutlinedButton(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text("Switch Account / Log Out") }

                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    "Your PIN stays on this device.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
