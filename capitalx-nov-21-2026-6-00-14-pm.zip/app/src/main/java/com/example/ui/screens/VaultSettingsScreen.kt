package com.example.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CurrencyExchange
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Password
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.SupportedCurrencies
import com.example.data.model.ThemeMode
import com.example.data.parser.DateMonthUtils
import com.example.data.security.CryptoAndAuth
import com.example.ui.components.BackupPasswordDialog
import com.example.ui.components.SetPinDialog
import com.example.ui.state.MoneyUiState
import kotlinx.coroutines.launch

@Composable
fun VaultSettingsScreen(
    state: MoneyUiState,
    onLogout: () -> Unit,
    onChangePassword: (currentPassword: String, newPassword: String, onDone: (Result<Unit>) -> Unit) -> Unit,
    onToggleHideAmounts: () -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetPin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onLockNow: () -> Unit,
    onSelectBaseCurrency: (String) -> Unit,
    onRefreshRates: () -> Unit,
    onSetNotificationsEnabled: (Boolean) -> Unit,
    onExportBackupPayload: suspend (password: String?) -> String?,
    onRestoreBackupPayload: (rawPayload: String, password: String?) -> Unit,
    onRestoreAutoRecovery: () -> Unit,
    onMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showSetPinDialog by remember { mutableStateOf(false) }
    var showEncryptExportPwdDialog by remember { mutableStateOf(false) }
    var pendingEncryptedExportPassword by remember { mutableStateOf<String?>(null) }
    var pendingRestorePayload by remember { mutableStateOf<String?>(null) }

    var currentPwd by remember { mutableStateOf("") }
    var newPwd by remember { mutableStateOf("") }
    var confirmNewPwd by remember { mutableStateOf("") }
    var showCurrentPwd by remember { mutableStateOf(false) }
    var showNewPwd by remember { mutableStateOf(false) }
    var showConfirmNewPwd by remember { mutableStateOf(false) }
    var pwdFeedback by remember { mutableStateOf<String?>(null) }
    var pwdFeedbackIsError by remember { mutableStateOf(false) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        onSetNotificationsEnabled(granted)
        if (!granted) onMessage("Notification permission denied")
    }

    val createJsonBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val json = onExportBackupPayload(null) ?: return@launch
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) }
                onMessage("JSON backup exported")
            }
        }
    }

    val createEncryptedBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val pwd = pendingEncryptedExportPassword
        pendingEncryptedExportPassword = null
        if (uri != null && !pwd.isNullOrBlank()) {
            scope.launch {
                val enc = onExportBackupPayload(pwd) ?: return@launch
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(enc) }
                onMessage("Encrypted backup saved")
            }
        }
    }

    val openRestoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val content = try {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (_: Exception) { null }
            if (content.isNullOrBlank()) {
                onMessage("Empty or unreadable backup file")
            } else if (CryptoAndAuth.isEncryptedBackup(content)) {
                pendingRestorePayload = content
            } else {
                onRestoreBackupPayload(content, null)
            }
        }
    }

    val hasPin = !state.activeAccount?.pinHash.isNullOrBlank()

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("vault_settings_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Vault & Settings", style = MaterialTheme.typography.headlineSmall)
        }

        // Account Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(state.activeAccount?.displayName ?: "Local Account", style = MaterialTheme.typography.titleMedium)
                        Text("@${state.activeAccount?.username ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(onClick = onLogout, modifier = Modifier.testTag("logout_button")) {
                        Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Log Out")
                    }
                }
            }
        }

        // Security & PIN
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("security_settings_card"),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Security & Privacy", style = MaterialTheme.typography.titleMedium)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.VisibilityOff, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("Hide amounts", style = MaterialTheme.typography.bodyMedium)
                        }
                        Switch(checked = state.hideAmounts, onCheckedChange = { onToggleHideAmounts() })
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showSetPinDialog = true },
                            modifier = Modifier.weight(1f).height(46.dp).testTag("configure_pin_button")
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (hasPin) "Change PIN" else "Set 4-8 PIN")
                        }
                        if (hasPin) {
                            OutlinedButton(onClick = onLockNow, modifier = Modifier.height(46.dp)) { Text("Lock") }
                            OutlinedButton(onClick = onDisablePin, modifier = Modifier.height(46.dp)) { Text("Off") }
                        }
                    }
                }
            }
        }

        // Change Account Password
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("change_password_card"),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Password, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Change Account Password", style = MaterialTheme.typography.titleMedium)
                    }
                    OutlinedTextField(
                        value = currentPwd,
                        onValueChange = { currentPwd = it; pwdFeedback = null },
                        label = { Text("Current password") },
                        singleLine = true,
                        visualTransformation = if (showCurrentPwd) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showCurrentPwd = !showCurrentPwd }) {
                                Icon(
                                    imageVector = if (showCurrentPwd) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (showCurrentPwd) "Hide password" else "Show password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("current_password_input")
                    )
                    OutlinedTextField(
                        value = newPwd,
                        onValueChange = { newPwd = it; pwdFeedback = null },
                        label = { Text("New password (min 6 chars)") },
                        singleLine = true,
                        visualTransformation = if (showNewPwd) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showNewPwd = !showNewPwd }) {
                                Icon(
                                    imageVector = if (showNewPwd) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (showNewPwd) "Hide password" else "Show password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("new_password_input")
                    )
                    OutlinedTextField(
                        value = confirmNewPwd,
                        onValueChange = { confirmNewPwd = it; pwdFeedback = null },
                        label = { Text("Confirm new password") },
                        singleLine = true,
                        visualTransformation = if (showConfirmNewPwd) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showConfirmNewPwd = !showConfirmNewPwd }) {
                                Icon(
                                    imageVector = if (showConfirmNewPwd) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (showConfirmNewPwd) "Hide password" else "Show password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("confirm_new_password_input")
                    )
                    pwdFeedback?.let { msg ->
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (pwdFeedbackIsError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                    Button(
                        onClick = {
                            when {
                                currentPwd.isEmpty() -> {
                                    pwdFeedback = "Enter your current password."
                                    pwdFeedbackIsError = true
                                }
                                newPwd.length < 6 -> {
                                    pwdFeedback = "New password must be at least 6 characters."
                                    pwdFeedbackIsError = true
                                }
                                newPwd != confirmNewPwd -> {
                                    pwdFeedback = "New passwords do not match."
                                    pwdFeedbackIsError = true
                                }
                                else -> {
                                    onChangePassword(currentPwd, newPwd) { res ->
                                        res.fold(
                                            onSuccess = {
                                                currentPwd = ""
                                                newPwd = ""
                                                confirmNewPwd = ""
                                                pwdFeedback = "Password updated successfully."
                                                pwdFeedbackIsError = false
                                            },
                                            onFailure = { err ->
                                                pwdFeedback = err.message ?: "Could not update password."
                                                pwdFeedbackIsError = true
                                            }
                                        )
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("update_password_button")
                    ) {
                        Text("Update Password")
                    }
                }
            }
        }

        // Appearance & Reminders
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Theme & Reminders", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = state.themeMode == mode,
                                onClick = { onSetThemeMode(mode) },
                                label = { Text(mode.label) }
                            )
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                            Column {
                                Text("Renewal & Budget Alerts", style = MaterialTheme.typography.bodyMedium)
                                Text("Local notifications for 80%/100% & bills", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(
                            checked = state.notificationsEnabled,
                            onCheckedChange = { enable ->
                                if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onSetNotificationsEnabled(enable)
                                }
                            }
                        )
                    }
                }
            }
        }

        // Base Currency & Live Rates
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("currency_rates_card"),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.CurrencyExchange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column {
                                Text("Base Currency & FX Rates", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    if (state.ratesUpdatedAtMillis > 0L) "Cached live · ${DateMonthUtils.formatShortDate(state.ratesUpdatedAtMillis)}"
                                    else "Offline baseline rates cached",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        OutlinedButton(onClick = onRefreshRates, modifier = Modifier.height(36.dp)) { Text("Refresh") }
                    }

                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SupportedCurrencies.forEach { cur ->
                            FilterChip(
                                selected = state.currencyCode == cur.code,
                                onClick = { onSelectBaseCurrency(cur.code) },
                                label = { Text("${cur.symbol} ${cur.code}") }
                            )
                        }
                    }
                }
            }
        }

        // Backup, Encrypted Backup & Auto Recovery
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("backup_restore_card"),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text("Backup & Auto-Recovery", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (state.lastBackupMillis > 0L) "Last manual backup: ${DateMonthUtils.formatFullDate(state.lastBackupMillis)}"
                                else "No manual backup exported yet",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showEncryptExportPwdDialog = true },
                            modifier = Modifier.weight(1f).height(46.dp).testTag("export_encrypted_backup_button")
                        ) { Text("Encrypted (.capx)") }
                        OutlinedButton(
                            onClick = { createJsonBackupLauncher.launch("capitalx_backup_${DateMonthUtils.todayKey()}.json") },
                            modifier = Modifier.weight(1f).height(46.dp).testTag("export_json_backup_button")
                        ) { Text("JSON Backup") }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { openRestoreLauncher.launch(arrayOf("*/*")) },
                            modifier = Modifier.weight(1f).height(46.dp).testTag("restore_file_button")
                        ) {
                            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restore File")
                        }
                        OutlinedButton(
                            onClick = onRestoreAutoRecovery,
                            modifier = Modifier.weight(1f).height(46.dp).testTag("restore_auto_recovery_button")
                        ) { Text("Auto-Recovery") }
                    }
                }
            }
        }
    }

    if (showSetPinDialog) {
        SetPinDialog(
            onDismiss = { showSetPinDialog = false },
            onConfirm = { pin ->
                onSetPin(pin)
                showSetPinDialog = false
            }
        )
    }

    if (showEncryptExportPwdDialog) {
        BackupPasswordDialog(
            title = "Encrypt Backup File",
            subtitle = "Set a password to AES-256 encrypt your Capitalx backup file.",
            confirmLabel = "Choose Save Location",
            onDismiss = { showEncryptExportPwdDialog = false },
            onConfirm = { pwd ->
                pendingEncryptedExportPassword = pwd
                showEncryptExportPwdDialog = false
                createEncryptedBackupLauncher.launch("capitalx_vault_${DateMonthUtils.todayKey()}.capx")
            }
        )
    }

    pendingRestorePayload?.let { encryptedPayload ->
        BackupPasswordDialog(
            title = "Decrypt Backup File",
            subtitle = "Enter the password used to protect this Capitalx backup.",
            confirmLabel = "Decrypt & Restore",
            onDismiss = { pendingRestorePayload = null },
            onConfirm = { pwd ->
                pendingRestorePayload = null
                onRestoreBackupPayload(encryptedPayload, pwd)
            }
        )
    }
}
