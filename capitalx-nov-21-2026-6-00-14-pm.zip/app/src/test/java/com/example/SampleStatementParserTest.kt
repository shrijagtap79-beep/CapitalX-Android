package com.example

import com.example.data.local.AutoRuleEntity
import com.example.data.local.ExpenseEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.network.ExchangeRateService
import com.example.data.parser.DateMonthUtils
import com.example.data.parser.SampleStatementParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SampleStatementParserTest {

    private val sampleRules = listOf(
        AutoRuleEntity(id = 1, accountId = 1L, keyword = "starbucks", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
        AutoRuleEntity(id = 2, accountId = 1L, keyword = "whole foods", category = ExpenseCategory.GROCERIES.name, isBuiltIn = true),
        AutoRuleEntity(id = 3, accountId = 1L, keyword = "uber", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
        AutoRuleEntity(id = 4, accountId = 1L, keyword = "netflix", category = ExpenseCategory.ENTERTAINMENT.name, isBuiltIn = true)
    )

    @Test
    fun parsesCsvSmsAndPlainLinesWithAutoCategorization() {
        val raw = """
            Date,Merchant,Amount,Note
            2026-11-02,Whole Foods Market,68.40,Weekly groceries
            Spent $18.50 at Uber Trip on 2026-11-05
            Your card was charged $15.99 at Netflix on 2026-11-11
            Starbucks 6.75
        """.trimIndent()

        val drafts = SampleStatementParser.parseSampleText(raw, "2026-11", sampleRules)
        assertEquals(4, drafts.size)

        assertEquals("Whole Foods Market", drafts[0].merchant)
        assertEquals(6840L, drafts[0].amountCents)
        assertEquals(ExpenseCategory.GROCERIES, drafts[0].category)

        assertEquals("Uber Trip", drafts[1].merchant)
        assertEquals(1850L, drafts[1].amountCents)
        assertEquals(ExpenseCategory.TRANSPORT, drafts[1].category)

        assertEquals("Netflix", drafts[2].merchant)
        assertEquals(1599L, drafts[2].amountCents)
        assertEquals(ExpenseCategory.ENTERTAINMENT, drafts[2].category)

        assertEquals("Starbucks", drafts[3].merchant)
        assertEquals(675L, drafts[3].amountCents)
        assertEquals(ExpenseCategory.FOOD_DINING, drafts[3].category)
        assertTrue(drafts.all { it.yearMonth == "2026-11" })
    }

    @Test
    fun parsesSingleBankAndUpiSmsForFormAutofill() {
        val upiDebit = "Debited INR 450.00 via UPI at Starbucks ref 98212"
        val debitPreview = SampleStatementParser.parseSingleBankOrUpiSms(upiDebit, "USD", sampleRules)
        assertNotNull(debitPreview)
        assertEquals("INR", debitPreview!!.currencyCode)
        assertEquals(45000L, debitPreview.amountCents)
        assertEquals(TransactionType.EXPENSE, debitPreview.transactionType)
        assertEquals(PaymentMethod.UPI, debitPreview.paymentMethod)
        assertEquals(ExpenseCategory.FOOD_DINING, debitPreview.category)

        val salaryCredit = "Credited USD 2500.00 from Acme Payroll via NEFT"
        val creditPreview = SampleStatementParser.parseSingleBankOrUpiSms(salaryCredit, "USD", sampleRules)
        assertNotNull(creditPreview)
        assertEquals(250000L, creditPreview!!.amountCents)
        assertEquals(TransactionType.INCOME, creditPreview.transactionType)
        assertEquals(PaymentMethod.BANK_TRANSFER, creditPreview.paymentMethod)
        assertEquals(ExpenseCategory.SALARY_INCOME, creditPreview.category)
    }

    @Test
    fun detectsRepeatChargesAcrossMonths() {
        val d1 = DateMonthUtils.millisForDayInMonth("2026-09", 5)
        val d2 = DateMonthUtils.millisForDayInMonth("2026-10", 5)
        val expenses = listOf(
            ExpenseEntity(
                id = 1,
                accountId = 1L,
                merchant = "Spotify Duo",
                amountCents = 1499L,
                category = ExpenseCategory.ENTERTAINMENT.name,
                dateMillis = d1,
                yearMonth = "2026-09"
            ),
            ExpenseEntity(
                id = 2,
                accountId = 1L,
                merchant = "Spotify Duo",
                amountCents = 1499L,
                category = ExpenseCategory.ENTERTAINMENT.name,
                dateMillis = d2,
                yearMonth = "2026-10"
            )
        )
        val suggestions = SampleStatementParser.detectRepeatCharges(expenses, emptyList())
        assertEquals(1, suggestions.size)
        assertEquals("Spotify Duo", suggestions.first().merchant)
        assertEquals(1499L, suggestions.first().averageAmountCents)
    }

    @Test
    fun convertsForeignCurrencyCentsUsingOfflineRates() {
        val converted = ExchangeRateService.convertCents(
            amountCents = 100_00L,
            fromCurrency = "USD",
            toCurrency = "EUR",
            usdRates = mapOf("USD" to 1.0, "EUR" to 0.92)
        )
        assertEquals(92_00L, converted)
    }

    @Test
    fun dateMonthUtilsChallengeAndScheduleHelpersWork() {
        assertEquals("2026-11-06", DateMonthUtils.advanceDateKey("2026-11-05", "DAILY"))
        assertEquals("2026-11-12", DateMonthUtils.advanceDateKey("2026-11-05", "WEEKLY"))
        assertEquals("2026-12-05", DateMonthUtils.advanceDateKey("2026-11-05", "MONTHLY", anchorDay = 5))

        val days = DateMonthUtils.daysInChallenge("2026-11-28", 5)
        assertEquals(listOf("2026-11-28", "2026-11-29", "2026-11-30", "2026-12-01", "2026-12-02"), days)

        // 2026-11-01 is a Sunday (index 0)
        val sunMillis = DateMonthUtils.millisForIsoDate("2026-11-01")
        assertEquals(0, DateMonthUtils.dayOfWeekIndex(sunMillis))
    }

    @Test
    fun classifiesExtendedV95MerchantKeywords() {
        val extendedRules = sampleRules + listOf(
            AutoRuleEntity(id = 5, accountId = 1L, keyword = "swiggy", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
            AutoRuleEntity(id = 6, accountId = 1L, keyword = "vada pav", category = ExpenseCategory.FOOD_DINING.name, isBuiltIn = true),
            AutoRuleEntity(id = 7, accountId = 1L, keyword = "rapido", category = ExpenseCategory.TRANSPORT.name, isBuiltIn = true),
            AutoRuleEntity(id = 8, accountId = 1L, keyword = "hotstar", category = ExpenseCategory.ENTERTAINMENT.name, isBuiltIn = true),
            AutoRuleEntity(id = 9, accountId = 1L, keyword = "freelance", category = ExpenseCategory.SALARY_INCOME.name, isBuiltIn = true)
        )
        assertEquals(ExpenseCategory.FOOD_DINING, SampleStatementParser.classifyMerchant("Swiggy Order", extendedRules).first)
        assertEquals(ExpenseCategory.FOOD_DINING, SampleStatementParser.classifyMerchant("Jumbo Vada Pav", extendedRules).first)
        assertEquals(ExpenseCategory.TRANSPORT, SampleStatementParser.classifyMerchant("Rapido Bike Ride", extendedRules).first)
        assertEquals(ExpenseCategory.ENTERTAINMENT, SampleStatementParser.classifyMerchant("Disney+ Hotstar", extendedRules).first)
        assertEquals(ExpenseCategory.SALARY_INCOME, SampleStatementParser.classifyMerchant("Freelance Client", extendedRules).first)
    }
}
