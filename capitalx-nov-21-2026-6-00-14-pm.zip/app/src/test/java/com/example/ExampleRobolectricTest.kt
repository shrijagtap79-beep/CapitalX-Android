package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ClearLedgerDatabase
import com.example.data.local.Expense
import com.example.data.local.ExpenseDatabase
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.TransactionType
import com.example.data.parser.DateMonthUtils
import com.example.data.repository.MoneyRepository
import com.example.data.security.CryptoAndAuth
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Capitalx", appName)
    }

    @Test
    fun `password hashing and encrypted backup round trip`() {
        val salt = CryptoAndAuth.generateSaltBase64()
        val hash = CryptoAndAuth.hashSecret("secret123", salt)
        assertTrue(CryptoAndAuth.verifySecret("secret123", salt, hash))
        assertFalse(CryptoAndAuth.verifySecret("wrongpass", salt, hash))

        val payloadJson = "{\"account\":\"Capitalx\",\"balance\":42000}"
        val encrypted = CryptoAndAuth.encryptBackup(payloadJson, "vaultPass99")
        assertTrue(CryptoAndAuth.isEncryptedBackup(encrypted))
        val decrypted = CryptoAndAuth.decryptBackup(encrypted, "vaultPass99")
        assertEquals(payloadJson, decrypted)
    }

    @Test
    fun `repository supports password change, pin reset, transfers, auto-add, and json v3 restore`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, ClearLedgerDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = MoneyRepository(context, db)
            val signUp = repo.signUpAccount("Trader", "trader1", "pass1234")
            assertTrue(signUp.isSuccess)
            val accId = signUp.getOrThrow().id

            // Change password & verify PIN reset via new password
            repo.setAppPin(accId, "2580")
            assertTrue(repo.changeAccountPassword(accId, "wrong", "newpass9").isFailure)
            assertTrue(repo.changeAccountPassword(accId, "pass1234", "newpass9").isSuccess)
            assertTrue(repo.verifyPasswordAndResetPin(accId, "newpass9").isSuccess)
            val refreshedAcc = repo.observeAccount(accId).first()
            assertNull(refreshedAcc?.pinHash)

            // Wallet balance, transfer & revert
            val wallets = repo.observeWallets(accId).first()
            assertTrue(wallets.size >= 2)
            val w1 = wallets[0]
            val w2 = wallets[1]
            repo.setWalletRealBalance(w1.id, 100_00L)
            val transferRes = repo.transferBetweenWallets(accId, w1.id, w2.id, 25_00L, System.currentTimeMillis(), "Topup")
            assertTrue(transferRes.isSuccess)
            var updatedWallets = repo.observeWallets(accId).first().associateBy { it.id }
            assertEquals(75_00L, updatedWallets[w1.id]?.balanceCents)
            assertEquals(25_00L, updatedWallets[w2.id]?.balanceCents)

            val transfers = repo.observeTransfers(accId).first()
            assertEquals(1, transfers.size)
            repo.deleteTransfer(transfers.first())
            updatedWallets = repo.observeWallets(accId).first().associateBy { it.id }
            assertEquals(100_00L, updatedWallets[w1.id]?.balanceCents)
            assertEquals(0L, updatedWallets[w2.id]?.balanceCents)

            // Auto-add rule sync creates transaction & increments wallet
            val addedCount = repo.addAutoAddRule(accId, w2.id, 10_00L, "DAILY", DateMonthUtils.todayKey(), "Allowance")
            assertEquals(1, addedCount)
            updatedWallets = repo.observeWallets(accId).first().associateBy { it.id }
            assertEquals(10_00L, updatedWallets[w2.id]?.balanceCents)

            // Goal-funded transaction + JSON v3 backup & restore round-trip
            repo.addGoal(accId, "Laptop", 500_00L, null)
            val goal = repo.observeGoals(accId).first().first()
            repo.contributeToGoal(goal.id, 100_00L, null)
            val txnRes = repo.addTransaction(
                accountId = accId,
                merchant = "Apple Store",
                baseAmountCents = 40_00L,
                originalAmountCents = 40_00L,
                originalCurrencyCode = "USD",
                transactionType = TransactionType.EXPENSE,
                selectedCategory = ExpenseCategory.SHOPPING,
                customCategoryName = null,
                dateMillis = System.currentTimeMillis(),
                paymentMethod = PaymentMethod.CARD,
                walletId = w1.id,
                note = "Sleeve",
                receiptUri = null,
                splits = emptyList(),
                repeatMonthly = false,
                goalId = goal.id
            )
            assertTrue(txnRes.isSuccess)
            val goalAfter = repo.observeGoals(accId).first().first()
            assertEquals(60_00L, goalAfter.savedCents)

            val backupJson = repo.exportAccountBackupJson(accId)
            val restoreRes = repo.restoreAccountBackupJson(accId, backupJson)
            assertTrue(restoreRes.isSuccess)
            assertNotNull(repo.observeAutoAddRules(accId).first().firstOrNull())
        } finally {
            db.close()
        }
    }

    @Test
    fun `expense entity, dao, and ExpenseDatabase CRUD round trip`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val expenseDb = Room.inMemoryDatabaseBuilder(context, ExpenseDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val ledgerDb = Room.inMemoryDatabaseBuilder(context, ClearLedgerDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = expenseDb.expenseDao()
            val now = 1_760_000_000_000L
            val insertedId = dao.insertExpense(
                Expense(
                    amount = 42.50,
                    date = now,
                    category = "Food",
                    description = "Lunch"
                )
            )
            assertTrue(insertedId > 0L)
            val all = dao.observeAllExpenses().first()
            assertEquals(1, all.size)
            assertEquals("Lunch", all.first().description)
            assertEquals(42.50, all.first().amount, 0.001)

            val byCategory = dao.observeExpensesByCategory("Food").first()
            assertEquals(1, byCategory.size)
            assertTrue(dao.observeExpensesByCategory("Travel").first().isEmpty())

            val updated = all.first().copy(amount = 48.00, description = "Team Lunch")
            dao.updateExpense(updated)
            assertEquals("Team Lunch", dao.getById(insertedId)?.description)
            assertEquals(48.00, dao.getById(insertedId)?.amount ?: 0.0, 0.001)

            dao.deleteExpense(updated)
            assertTrue(dao.observeAllExpenses().first().isEmpty())

            val repo = MoneyRepository(context, ledgerDb)
            val repoId = repo.addExpenseItem(
                amount = 19.99,
                date = now,
                category = "Utilities",
                description = "Cloud Storage"
            )
            val repoItems = repo.observeExpenseItems().first()
            assertEquals(1, repoItems.size)
            assertEquals(repoId, repoItems.first().id)
            assertEquals("Utilities", repo.observeExpenseItemsByCategory("Utilities").first().first().category)

            repo.updateExpenseItem(repoItems.first().copy(amount = 24.99))
            assertEquals(24.99, repo.observeExpenseItems().first().first().amount, 0.001)

            repo.deleteExpenseItem(repo.observeExpenseItems().first().first())
            assertTrue(repo.observeExpenseItems().first().isEmpty())
        } finally {
            expenseDb.close()
            ledgerDb.close()
        }
    }
}
